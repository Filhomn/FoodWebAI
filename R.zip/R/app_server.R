#' The application server-side
#'
#' @param input,output,session Internal parameters for {shiny}.
#'     DO NOT REMOVE.
#' @import shiny
#' @noRd
app_server <- function(input, output, session) {
  observeEvent(input$help1, {
    toggle('help1_panel')
  })
  observeEvent(input$help1_1, {
    toggle('help1_panel')
  })

  observeEvent(input$help2, {
    toggle('help2_panel')
  })

  observeEvent(input$help3, {
    toggle('help2_panel')
  })
  observeEvent(input$help4, {
    toggle('help2_panel')
  })

  observeEvent(input$help2_2, {
    toggle('help2_panel')
  })


  observeEvent(input$close_1, {
    hide('controls31')
  })


  output$downloadZipBtn <-  downloadHandler(
    filename = function() {
      # Set the name of the downloaded file
      "example.zip"
    },
    content = function(file) {
      # Copy the zip file from the server to the user's local machine
      file.copy('example.zip', file)
    }
  )

  output$downloadZipBtn2 <-  downloadHandler(
    filename = function() {
      # Set the name of the downloaded file
      "example2.zip"
    },
    content = function(file) {
      # Copy the zip file from the server to the user's local machine
      file.copy('example2.zip', file)
    }
  )

  observeEvent(input$ch21, {
    toggle('controls31')

  })

  ######### GENERATIVE##############

  # model = "text-babbage-001"


  table_gen_1 <- reactiveVal(NULL)
  table_gen_2 <- reactiveVal(NULL)

  observeEvent(input$run1,{
    req(input$file1_1)
    gen_data <- read_csv(input$file1_1$datapath)
    colnames(gen_data)[1] <- "species"



    if (input$md1 == 'gpt-3.5-turbo-instruct') {

      classify_gen <- function(text) {
        prompt <- paste(
          "Please match the following with its predator:\n\n",
          paste(gen_data$species, collapse = ", "),
          "\n\nHere is the text to classify:\n\n",
          text,
          "\n\nPredator:"
        )
        response <- gpt3_single_completion(
          prompt_input = prompt,
          temperature = 0.1,
          max_tokens = 3,
          n = 1,
          model = "gpt-3.5-turbo-instruct"
        )
        category <- response[[1]]$gpt3
      }

      classify_gen3 <- function(text) {
        prompt <- paste(
          "Please match the following with its prey:\n\n",
          paste(gen_data$species, collapse = ", "),
          "\n\nHere is the text to classify:\n\n",
          text,
          "\n\nPrey:"
        )
        response <- gpt3_single_completion(
          prompt_input = prompt,
          temperature = 0.1,
          max_tokens = 3,
          n = 1,
          model = "gpt-3.5-turbo-instruct"
        )
        category2 <- response[[1]]$gpt3
      }

      classify_gen2 <- function(text) {
        prompt <- paste(
          "Classify the species as 1 (autotroph), 2 (herbivore), 3 (carnivores) and 4 (top predators)\n\n",
          paste(gen_data$species, collapse = ", "),
          "\n\nHere is the text to classify:\n\n",
          text,
          "\n\nTrophic Position:"
        )
        response <- gpt3_single_completion(
          prompt_input = prompt,
          temperature = 0.1,
          max_tokens = 2,
          n = 1,
          model = "gpt-3.5-turbo-instruct"
        )
        t_level <- response[[1]]$gpt3
      }
    }
    else {
      classify_gen <- function(text) {
        prompt <- paste(
          "Please match the following species with its predator from this list:\n\n",
          paste(gen_data$species, collapse = ", "),
          "\n\nSpecies to classify:\n\n",
          text,
          "\n\nRespond with only the predator name, nothing else. Predator:"
        )

        chat <- chat_openai(
          model = input$md1,
          system_prompt = NULL,
          api_args = list(temperature = 0.1, max_completion_tokens = 10)
        )

        category <- chat$chat(prompt)
        category
      }

      classify_gen3 <- function(text) {
        prompt <- paste(
          "Please match the following species with its prey from this list:\n\n",
          paste(gen_data$species, collapse = ", "),
          "\n\nSpecies to classify:\n\n",
          text,
          "\n\nRespond with only the predator name, nothing else. Prey:"
        )

        chat <- chat_openai(
          model = input$md1,
          system_prompt = NULL,
          api_args = list(temperature = 0.1, max_completion_tokens = 10)
        )

        category2 <- chat$chat(prompt)

      }


      classify_gen2 <- function(text) {
        prompt <- paste(
          "Classify the species as 1 (autotroph), 2 (herbivore), 3 (carnivore) or 4 (top predator).\n\n",
          "Species list:\n",
          paste(gen_data$species, collapse = ", "),
          "\n\nSpecies to classify:\n\n",
          text,
          "\n\nRespond with only one number. Trophic Position:"
        )

        chat <- chat_openai(
          model = input$md1,
          system_prompt = NULL,
          api_args = list(temperature = 0.4, max_completion_tokens = 4)
        )

        t_level <- chat$chat(prompt)
      }
    }



    gw = gen_data
    showModal(modalDialog(
      tagList(
        tags$p("The model is processing your species list."),
        tags$p(style = "color:#8b949e; font-size:15px;",
               "Processing time depends on the number of species and the selected model.")
      ),
      title    = "Classification in progress",
      footer   = NULL,
      easyClose = FALSE
    ))
    gw$category <- sapply(gw$species, classify_gen) %>% tolower()
    gw$category2 <- sapply(gw$species, classify_gen3) %>% tolower()
    gw = gw %>% gather("a", "category", 2:3)
    gw$species2 <- ifelse(gw$a == "category", gw$species, gw$category)
    gw$category2 <- ifelse(gw$a == "category", gw$category, gw$species)
    gw$species = gw$species2
    gw$category = gw$category2
    gw$category = trimws(gw$category)
    gw$species = trimws(gw$species)

    standardize_word <- function(word) {
      target_words <- c('none', gen_data$species)
      distances <- stringdistmatrix(word, target_words, method = 'jw')

      closest_match_index <- which.min(distances)
      closest_match_distance <- distances[closest_match_index]

      other_distances <- distances[-closest_match_index]
      if (closest_match_distance < 10 &&
          all(closest_match_distance < other_distances + 3)) {
        return(target_words[closest_match_index])
      } else {
        return(word)
      }
    }

    gw$category <- sapply(gw$category, standardize_word)
    gw$species <- sapply(gw$species, standardize_word)

    gw = gw %>% filter(category != "none")

    gw$weight = rep(1, length(gw$species))
    gw2 = data.frame(name = unique(c(gw$species, gw$category)))
    gw2$name = trimws(gw2$name)
    gw2$t_level <- trimws(sapply(gw2$name, classify_gen2))
    gw2$size = rep(20, length(gw2$name))
    gw2$value = rep(1, length(gw2$name))
    removeModal()

    table_gen_1(data.frame(
      from = gw$species,
      to = gw$category,
      weight = gw$weight
    ))
    table_gen_2(
      data.frame(
        name = gw2$name,
        value = gw2$value,
        size = gw2$size,
        t_level = gw2$t_level
      )
    )



    output$my_chart3 <- renderEcharts4r({
      les <- list(nodes = table_gen_2(), edges = table_gen_1())
      les$nodes$t_level = as.numeric(les$nodes$t_level)
      les$nodes = les$nodes %>% na.exclude()

      a <- e_charts() |>
        e_graph(
          emphasis = list(focus = 'adjacency', label = list(show = TRUE)),
          roam = TRUE,
          zoom = input$ch20_1,
          scaleLimit = list(min = 0.5, max = 4),
          nodeScaleRatio = 0.35,
          right = '35%',
          lineStyle = list(color = "source", curveness = 0.310),
          draggable = FALSE
        ) |>
        e_graph_nodes(
          nodes = les$nodes,
          name = "name",
          value = "value",
          size = 'size',
          category = 't_level',
          legend = F
        ) |>
        e_graph_edges(
          edges = les$edges,
          source = from,
          target = to,
          value = weight
        ) |>
        e_tooltip() |>
        e_theme(name = input$ch8_1) |>
        e_toolbox() |>
        e_toolbox_feature(feature = c("saveAsImage"))


      les$nodes$t_level = as.numeric(les$nodes$t_level)
      for (i in 1:length(levels(as.factor(les$nodes$name)))) {
        a$x$opts$series[[1]]$data[[i]]$y <- (les$nodes$t_level[i]) * -150
      }

      num_elements <- length(levels(as.factor(les$nodes$name)))
      pattern_spacing <- 100  # Adjust this as needed for your desired spacing
      element_spacing <- 70  # Adjust this as needed for your desired spacing
      x_positions <- numeric(num_elements)

      # Calculate x positions based on t_level
      for (i in 1:num_elements) {
        pattern <- ((i - 1) %/% 10) * pattern_spacing
        offset <- ((i - 1) %% 10) * element_spacing

        # Calculate centralization based on t_level (assuming t_level is a vector)
        t_level <- les$nodes$t_level[i]  # Replace with your actual data structure
        centralization_offset <- (t_level - 1) * (pattern_spacing + (9 * element_spacing)) / 2

        x_positions[i] <- pattern + offset + centralization_offset
      }

      # Avoid overlapping elements by adjusting x_positions
      min_spacing <- 40  # Adjust this as needed for minimum spacing
      for (i in 2:num_elements) {
        if (x_positions[i] - x_positions[i - 1] < min_spacing) {
          x_positions[i] <- x_positions[i - 1] + min_spacing
        }
      }

      # Assign the calculated x positions to your data
      for (i in 1:num_elements) {
        a$x$opts$series[[1]]$data[[i]]$x <- x_positions[i]
      }
      a$x$opts$series[[1]]$layout <- input$ch7_1
      a$x$opts$series[[1]]$draggable <- TRUE
      a$x$opts$series[[1]]$label <- list(
        show = TRUE,
        fontSize = input$fontsize3,
        position = "bottom",
        borderColor = 'transparent',
        borderWidth = 0
      )
      a$x$opts$series[[1]]$itemStyle <- list(borderWidth = 1, borderColor = 'black')
      a$x$opts$legend <- list(show = TRUE)
      a$x$opts$itemStyle = list(borderColor = 'transparent', borderWidth =
                                  0)

      for (i in 1:length(les$nodes$name)) {
        a$x$opts$series[[1]]$data[[i]]$symbolSize = as.numeric(a$x$opts$series[[1]]$data[[i]]$symbolSize) * input$ch10_1
      }

      a
    })


    output$editableTable5 <- renderRHandsontable({
      rhandsontable(table_gen_2(), rowHeaders = NULL)


    })

    output$editableTable6 <- renderRHandsontable({
      rhandsontable(
        table_gen_1(),
        stretchH = "all",
        rowHeaders = NULL,
        width = "100%",
        allowRowAdd = TRUE
      )
    })

    observeEvent(input$editableTable5, {
      table_gen_2(hot_to_r(input$editableTable5))
    })

    observeEvent(input$editableTable6, {
      table_gen_1(hot_to_r(input$editableTable6))
    })

    ff <- reactiveVal({
      rtr = table_gen_1()
      species <- unique(c(rtr$from, rtr$to))

      # Initialize the adjacency matrix with zeros
      adj_matrix <- matrix(0, nrow = length(species), ncol = length(species),
                           dimnames = list(species, species))

      # Fill the adjacency matrix with 1s where there is a connection
      for(i in 1:nrow(table_gen_1())) {
        adj_matrix[table_gen_1()$from[i], table_gen_1()$to[i]] <- 1
      }
      adj_matrix

    })


    output$dwntable1 <- downloadHandler(
      filename = function() {
        paste('csv-files-', Sys.Date(), '.zip', sep = '')
      },
      content = function(zipfile) {
        # Create a temporary directory to store the CSV files
        tmpdir <- tempdir()
        setwd(tmpdir)

        # Create some example CSV data frames
        df1 <- table_gen_1()
        df2 <- table_gen_2()
        df3 <- ff()



        Sys.sleep(3)


        # Write the data frames to CSV files
        write.csv(df2, file = "basic_estimates.csv", row.names = FALSE)
        write.csv(df1, file = "consumption.csv", row.names = FALSE)
        write.csv(df3, file = "matrix.csv", row.names = TRUE)
        # Zip the CSV files
        zip(zipfile,
            files = c("matrix.csv","basic_estimates.csv", "consumption.csv"))
      },
      contentType = "application/zip"
    )


  })




  ######END GENERATIVE ############





  ############# FREE ########
  table_data1 <- reactiveVal(data.frame(
    name_species = c('A', 'B', 'C'),
    trophic_level = c(1, 2, 3),
    biomass = c(10, 4, 7)
  ))

  table_data2 <- reactiveVal(data.frame(
    from_species = c('A', 'B', 'C', 'A'),
    to_species = c('B', 'C', 'A', 'C'),
    link_weight = c(1.3, 3.3, 5, 4)
  ))

  # Render the editable tables

  output$editableTable1 <- renderRHandsontable({
    rhandsontable(
      table_data1(),
      stretchH = "all",
      rowHeaders = NULL,
      width = "100%",
      allowRowAdd = TRUE
    )


  })

  output$editableTable2 <- renderRHandsontable({
    rhandsontable(
      table_data2(),
      stretchH = "all",
      rowHeaders = NULL,
      width = "100%",
      allowRowAdd = TRUE
    )
  })




  # Observe changes in the tables and update the reactive values
  observeEvent(input$editableTable1, {
    table_data1(hot_to_r(input$editableTable1))
  })

  observeEvent(input$editableTable2, {
    table_data2(hot_to_r(input$editableTable2))
  })

  observeEvent(input$addRowBtn1, {
    new_row1 <- data.frame(
      name_species = '',
      trophic_level = 0,
      biomass = 0
    )
    updated_table1 <- rbind(table_data1(), new_row1)
    table_data1(updated_table1)
  })

  observeEvent(input$addRowBtn2, {
    new_row2 <- data.frame(
      from_species = "",
      to_species = "",
      link_weight = 0
    )
    updated_table2 <- rbind(table_data2(), new_row2)
    table_data2(updated_table2)
  })

  # Create a reactive context to access 'table_data1' and 'table_data2' within the observer
  observe({
    les <- list(
      nodes = data.frame(
        name = table_data1()$name_species,
        value = table_data1()$biomass,
        trophic_level = table_data1()$trophic_level,
        group = floor(table_data1()$trophic_level)
      ),
      edges = data.frame(
        from = table_data2()$from_species,
        to = table_data2()$to_species,
        weight = table_data2()$link_weight
      )
    )
    les$nodes$symbol = rep(input$ch9, length(les$nodes$name))
    output$my_chart2 <- renderEcharts4r({
      les$nodes$size <- scales::rescale(les$nodes$value, to = c(10, 50))
      les$edges$weight <- scales::rescale(les$edges$weight, to = c(1, 6))

      a <- e_charts() |>
        e_graph(
          emphasis = list(focus = 'adjacency', label = list(show = TRUE)),
          roam = TRUE,
          zoom = input$ch20,

          right = '35%',
          lineStyle = list(color = "source", curveness = 0.310),
          draggable = FALSE
        ) |>
        e_graph_nodes(
          nodes = les$nodes,
          name = "name",
          # Column name for the node names
          value = "value",
          size = 'size',
          category = group,
          symbol = symbol,
          legend = TRUE
        ) |>
        e_graph_edges(
          edges = les$edges,
          source = from,
          target = to,
          value = weight
        ) |>
        e_tooltip() |>
        e_theme(name = input$ch8) |>
        e_toolbox() |>
        e_toolbox_feature(feature = c("saveAsImage"))

      for (i in 1:length(levels(as.factor(les$nodes$name)))) {
        a$x$opts$series[[1]]$data[[i]]$y <- les$nodes$trophic_level[i] * -150
      }

      for (i in 1:length(levels(as.factor(les$nodes$name)))) {
        pattern <- ((i - 1) %/% 10) * 50
        offset <- ((i - 1) %% 10) * 66
        a$x$opts$series[[1]]$data[[i]]$x <- pattern + offset
      }

      a$x$opts$series[[1]]$layout <- input$ch7
      a$x$opts$series[[1]]$draggable <- TRUE
      a$x$opts$series[[1]]$label <- list(
        show = TRUE,
        fontSize = input$fontsize2,
        position = "bottom",
        borderColor = 'transparent',
        borderWidth = 0
      )
      a$x$opts$series[[1]]$itemStyle <- list(borderWidth = 1, borderColor = 'black')
      a$x$opts$legend <- list(show = TRUE)
      a$x$opts$itemStyle = list(borderColor = 'transparent', borderWidth = 0)

      for (i in 1:length(les$nodes$name)) {
        a$x$opts$series[[1]]$data[[i]]$symbolSize = as.numeric(a$x$opts$series[[1]]$data[[i]]$symbolSize) * input$ch10
      }
      # Return the chart using echartOutput
      a

    })
  })
  ######################## End FREE ###################

  observe({
    if (is.null(input$file2) | is.null(input$file2)) {
      return()
    } else {
      var_example <- 2
    }
  })

  output$filesUploaded <- reactive({
    val <- !((is.null(input$file1) |
                is.null(input$file2)) &
               (is.null(input$file1R) | is.null(input$file2R)))
    print(val)
  })
  outputOptions(output, 'filesUploaded', suspendWhenHidden = FALSE)

  output$filesUploaded2 <- reactive({
    val <- !(is.null(input$file1_1))
    print(val)
  })
  outputOptions(output, 'filesUploaded2', suspendWhenHidden = FALSE)




  observeEvent(input$file1, {
    output$ui1 <- renderUI({
      echarts4rOutput('my_chart', height = "800%") %>% withSpinner(type = 6, color = "lightblue")
    })

  })

  observeEvent(input$file1R, {
    output$ui1R <- renderUI({
      echarts4rOutput('my_chartR', height = "800%") %>% withSpinner(type = 6, color = "lightblue")
    })

  })

  output$ui2 <- renderUI({
    echarts4rOutput('my_chart2', height = "800%") %>% withSpinner(type = 6, color = "lightblue")
  })
  observeEvent(input$file1_1, {
    output$ui3 <- renderUI({
      echarts4rOutput('my_chart3', height = "800%") %>% withSpinner(type = 6, color = "lightblue")
    })
  })

  observe({
    if (input$ch1 == 'Trophic Position') {
      NULL
    } else {
      showNotification("Groups are being generated with A.I. It might take a minute...",
                       type = "message")
    }
  })

  table_data3 <- reactiveVal()
  table_data4 <- reactiveVal()


  observe ({
    if (input$ch5 == 'Ecopath') {
      req(input$file1, input$file2)
      # Read data from uploaded files

      basic_estimates <- read_csv(input$file1$datapath)
      #linha nova
      basic_estimates = basic_estimates %>% filter(!is.na(...1))
      consumption <- read_csv(input$file2$datapath)
      n = ncol(consumption)
      # Data processing code
      labels <- data.frame('to' = basic_estimates$...1, 'Name' = basic_estimates$`Group name`)
      data <- consumption %>% pivot_longer(cols = 3:n,
                                           names_to = 'to',
                                           values_to = 'weight')
      data <- data %>% select('from' = `Prey \\ predator`, to, weight)
      data$to <- as.numeric(data$to)
      data <- left_join(data, labels, by = 'to') %>%
        select('from', 'to' = Name, weight) %>%
        na.exclude()


      data2 <- basic_estimates %>% select(
        'name' = `Group name`,
        'value' = `Biomass (t/km²)`,
        'size' = `Biomass (t/km²)`,
        't_level' = `Trophic level`
      )
      data2$grp <- floor(data2$t_level)
      data2$category <- rep('', length(data2$name))







      if (input$ch1 == 'Trophic Position') {
        qw = data2$grp
        qw2 = data2$grp
        qw3 = data2$grp
        qw2_names = data2$grp
      } else {
        if (input$ch1 == 'Groups') {
          classify_category <- function(text) {
            prompt <- paste(
              "Please classify the following as one of the following categories:\n\n Bird, Detritus, Invertebrate, Mammal, Fish, Reptile, Primary producer, or Unidentified.\n\nHere is the text to classify:\n\n",
              text,
              "\n\nCategory:"
            )
            response <- gpt3_single_completion(
              prompt_input = prompt,
              temperature = 0.3,
              max_tokens = 3,
              n = 1,
              model = "gpt-3.5-turbo-instruct"
            )
            category <- response[[1]]$gpt3
          }

          qw = sapply(data2$name, classify_category) %>% tolower()

          standardize_word <- function(word) {
            target_words <- c(
              'bird',
              'detritus',
              'invertebrate',
              'mammal',
              'fish',
              'reptile',
              'primary producer',
              'unidentified'
            )
            distances <- stringdistmatrix(word, target_words, method = 'jw')

            closest_match_index <- which.min(distances)
            closest_match_distance <- distances[closest_match_index]

            other_distances <- distances[-closest_match_index]
            if (closest_match_distance < 10 &&
                all(closest_match_distance < other_distances + 3)) {
              return(target_words[closest_match_index])
            } else {
              return(word)
            }
          }

          qw <- sapply(qw, standardize_word)


          classification_list <- list(
            `mammal` = 'path://m439.56,144.813c-4.522,-39.83599 -45.271,-56.241 -45.271,-56.241s-11.198,32.337 -6.79001,63.26701c5.35101,37.51399 -41.853,77.83699 -141.994,77.83699c0,0 -192.82299,0 -231.951,0c-39.12,0 5.032,133.035 150.90901,138.85101c11.23599,0.44901 21.924,0.13699 32.155,-0.76199c18.55199,18.72699 46.42799,40.01898 86.75099,55.43399c15.27802,5.086 36.43298,-75.39301 -47.79102,-131.25302l2.634,-2.26898c28.08301,11.50998 47.63101,26.65198 60.86902,42.43198c51.55099,-34.32397 78.332,-82.633 90.68698,-98.26199c20.371,-25.77499 40.17001,-29.14799 70.172,-32.802c38.47202,-4.68799 52.06003,-32.80199 52.06003,-32.80199s-40.75,-25.77499 -72.44,-23.42999z',
            `fish` = 'path://m473.47198,266.47699l38.172,-98.60899c0.84399,-2.203 0.14102,-4.688 -1.71899,-6.10901c-1.875,-1.438 -4.453,-1.453 -6.34399,-0.063l-99.09402,73.09401c-21.32797,-2.51601 -44.39099,-53.46901 -145.92197,-78.75l29.672,-4.23401c4.73398,-0.672 8.89099,-3.43799 11.35898,-7.547c2.453,-4.09399 2.922,-9.078 1.297,-13.563l-14.922,-41.03099c-1.828,-5.01601 -6.047,-8.78101 -11.23398,-10.01601s-10.64102,0.219 -14.53101,3.875l-67.922,63.938c-109.89,2.40501 -192.281,90.85802 -192.281,119.015c3.734,23.60901 48.891,77.875 117.25,104.25c7.141,-9.96899 12.906,-19.59399 17.516,-28.76599c13.453,-26.828 17.23401,-49.875 17.23401,-65.73401c0,-6.39099 -0.625,-11.60901 -1.42201,-15.26599c-1.28099,-6.04701 2.563,-11.98401 8.60901,-13.26601c6.047,-1.297 11.98399,2.563 13.28099,8.59401c1.15601,5.453 1.89101,12.10898 1.89101,19.93799c0,19.34399 -4.578,45.81299 -19.60899,75.76599c-4.21901,8.422 -9.313,17.125 -15.328,26.01602c23.5,6.40598 49.203,9.297 76.48399,6.70297l20.25,39.453c2.047,4 5.688,6.93802 10.03101,8.09402c4.34399,1.14099 8.96899,0.40598 12.75,-2.06302l15.453,-10.10901c4.26599,-2.78098 6.90601,-7.422 7.172,-12.48398c0.23401,-5.06302 -1.93799,-9.953 -5.89099,-13.14102l-20.70302,-16.672c104.59401,-24.93799 127.95302,-77.078 149.51601,-79.625l99.09402,73.09402c1.89099,1.39099 4.46899,1.375 6.34399,-0.04703c1.85898,-1.422 2.56302,-3.922 1.71899,-6.10898l-38.17203,-98.62601zm-397.04698,7.46802c-9.26601,0 -16.781,-7.53101 -16.781,-16.78101c0,-9.26599 7.516,-16.78099 16.781,-16.78099s16.781,7.51601 16.781,16.78099c0,9.25 -7.516,16.78101 -16.781,16.78101z',
            `primary producer` = 'path://m176.692,9.90914c-0.87,0.86836 -3.327,-0.0956 -4.576,0.40346c-2.81999,1.1269 -5.842,1.8909 -8.265,4.3034c-20.717,20.623 -41.459,41.2699 -62.139,61.9286c-3.0002,2.9966 -3.9965,7.6413 -4.5023,11.431c-0.0134,0.1008 -0.1204,0.2555 -0.22141,0.2689c-1.3557,0.1806 -2.9412,0.0434 -4.2065,0.6052c-2.4825,1.1021 -5.276,2.0682 -7.4537,4.2361c-20.6083,20.5152 -41.1976,41.04221 -61.7701,61.59219c-2.2604,2.25801 -3.7738,5.73901 -4.1328,8.60701c-0.1319,1.05499 -0.4115,2.89 -0.6642,3.89999c-0.2363,0.94501 0.191,1.918 0.2214,2.89101c0.1537,4.914 3.2081,9.625 6.9372,12.978c0.0496,-0.03999 0.0981,0.03 0.1476,0c6.4839,6.297 19.171,6.55499 25.7559,0c20.7163,-20.623 41.4586,-41.27 62.1389,-61.929c2.07301,-2.07 2.481,-4.607 3.543,-6.993c0.131,-0.29601 0.635,-0.916 0.664,-1.21001c0.123,-1.271 -0.678,-3.60699 0.59,-3.766c1.036,-0.129 2.134,0.098 3.174,0c0.293,-0.027 0.884,-0.545 1.18,-0.672c2.552,-1.093 4.988,-1.601 7.159,-3.766c20.554,-20.4966 41.086,-40.9426 61.62199,-61.4575c4.86101,-4.8555 6.382,-14.7692 3.543,-20.4411c-0.88699,-1.7725 -1.53299,-4.4598 -3.321,-5.7155c-2.914,-3.3266 -6.255,-5.373 -10.11099,-6.6568c-1.597,-0.53202 -3.90901,0.3973 -5.313,-0.53796zm31.069,3.89996c-0.51801,0.518 -0.04001,2.073 0.44299,2.5551c0.59401,-0.5393 0.58701,-0.5364 1.181,-1.0758c-0.81,-0.7552 -0.814,-0.7241 -1.62399,-1.4793zm169.59099,32.8134c-0.06598,-0.0933 -0.11899,-0.0515 -0.36899,0.269c-3.02399,3.873 -9.27301,5.6305 -11.36499,9.9516c-1.98001,4.0902 -0.08902,8.8709 0,13.3137c0.00299,0.1385 0.81699,-0.2187 1.328,-0.3362c-0.51602,0.18629 -1.11301,0.3808 -1.328,0.5379c-3.617,2.6444 -5.68402,4.5582 -6.93701,8.40511c-1.36801,4.1998 0.77399,8.4589 3.98499,11.4981c-0.31699,-0.3409 -0.62997,-0.6944 -0.88599,-0.94131c-0.49301,0.43291 -1.34601,-0.6554 -1.845,-0.8742c-1.21301,-0.5321 -3.10199,-1.4683 -4.42801,-1.6137c-5.552,-0.60889 -9.94699,0.65411 -13.79999,4.0344c-3.28201,2.8788 -4.74899,8.2416 -3.39499,12.1031c0.34698,0.99 1.077,2.506 1.91898,3.429c0.26801,0.294 0.81201,0.498 0.81201,0.875c0,0.095 -0.08801,0.122 -0.14801,0.201c0.20001,0.176 0.38901,0.362 0.591,0.538c-2.646,-2.051 -5.42599,-2.995 -10.03699,-3.295c-7.96402,0.499 -13.34702,5.38499 -13.948,12.238c-0.15201,1.732 0.00998,4.018 1.03299,5.514c0.733,1.072 1.496,2.102 2.435,3.093c-0.12,-0.11301 -0.24799,-0.222 -0.36899,-0.33601c-0.09,0.079 -0.05701,0.122 -0.147,0.202c-1.733,-0.76 -3.16699,-2.015 -5.01901,-2.421c-5.72198,-1.255 -10.884,0.435 -14.83298,3.89999c-1.06702,0.936 -1.51401,2.143 -2.28802,3.16c-0.54099,0.71201 -1.09598,1.92001 -1.25497,2.757c-0.43503,2.293 -0.36301,5.334 0.81198,7.397c0.32602,0.57201 2.10501,2.868 1.771,3.16c0.14502,0.127 0.517,0.407 0.88602,0.672c-3.617,-2.745 -7.92502,-3.875 -12.767,-3.026c-1.30402,0.229 -2.67902,0.509 -3.76401,1.144c-1.521,0.88901 -2.845,1.83101 -4.207,3.02501c-0.70499,0.61899 -1.08899,1.38399 -1.69699,1.95c-0.02502,-0.017 -0.039,-0.06601 -0.07401,-0.067c-5.03302,-0.13 -10.09302,-0.026 -15.129,0c-0.06702,0 -0.10001,0.026 -0.147,0.067c-3.694,3.21399 -7.377,6.46899 -11.07001,9.683c-0.048,0.04199 -0.129,0.00999 -0.14799,0.067c-0.138,0.425 -0.09601,0.46199 0.14799,0.673c2.472,2.142 4.87799,4.271 7.38,6.38799c0.043,0.03601 0.17801,0.037 0.22101,0c2.71298,-2.32799 5.34598,-4.71999 8.04398,-7.06099c0.048,-0.041 0.08002,-0.06601 0.14801,-0.067c3.05099,-0.026 6.17401,0.049 9.22501,0c0.29999,0.388 0.306,0.711 0.59,1.20999c0.69299,1.21701 1.367,2.61601 2.509,3.63101c4.267,3.79599 8.56,7.58099 12.841,11.364c4.14899,3.666 8.30899,7.308 12.47299,10.95999c1.35602,1.19 3.702,2.52701 5.534,2.757c0.25101,0.032 0.439,0.276 0.66501,0.40401c-0.05899,2.72299 1.31201,5.66699 0,8.136c-1.62201,3.05099 -5.508,4.78799 -8.19202,7.19398c-0.04199,0.03801 -0.04199,0.097 0,0.13501c2.41202,2.168 4.95203,4.3 7.38,6.455c0.30099,0.267 0.05402,0.373 0.73801,0.202c0.065,-0.017 0.026,-0.093 0.07401,-0.13499c3.724,-3.293 9.14401,-5.617 11.21701,-9.884c1.974,-4.064 0.14697,-8.83101 0,-13.24701c-0.00201,-0.05199 -0.104,-0.013 -0.147,-0.06699c1.564,-1.35501 3.58499,-2.49901 4.944,-4.16901c3.72498,-4.57401 2.76498,-10.79001 -1.03302,-14.927c0.117,0.11501 0.25101,0.22101 0.36902,0.336c0.46298,-0.40599 2.853,1.20401 3.69,1.479c2.07098,0.68199 4.61499,0.89099 6.93698,0.74001c5.16501,-0.33601 9.51001,-3.69601 11.73401,-7.59801c1.11401,-1.95399 1.10699,-4.791 1.10699,-6.79199c0,-2.02 -1.40201,-4.62701 -3.026,-6.05101c0.20901,-0.183 0.21802,-0.117 0.36902,-0.202c1.76199,1.28101 3.89297,2.312 6.12598,2.42101c0.72302,0.03499 1.539,0.323 2.14001,-0.067c-0.091,0.07899 -0.13101,0.12199 -0.22202,0.20099c0.38501,0.33701 1.617,0.19501 1.99301,-0.13399c-0.09,-0.08 -0.05701,-0.05501 -0.14801,-0.13501c0.061,-0.05299 0.14801,-0.05899 0.14801,-0.134c0.436,0.664 2.43799,0.242 3.173,0c3.022,-0.99399 5.612,-2.76399 7.67599,-5.17799c2.53601,-2.966 2.944,-7.955 1.62299,-11.431c-0.46698,-1.23 -1.491,-2.162 -2.435,-3.16c0.25803,-0.226 0.14102,-0.103 0.36902,-0.403c5.289,4.63901 15.87399,3.095 20.147,-2.15199c0.539,-0.662 1.582,-1.548 1.845,-2.354c0.16299,-0.499 0.56998,-1.031 0.73798,-1.546c1.349,-4.14201 0.53302,-8.19901 -2.28799,-11.498c0.14502,-0.127 0.19702,-0.183 0.29501,-0.269c0.267,0.182 0.48199,0.445 0.73801,0.605c4.96899,3.113 12.24799,2.254 16.89999,-0.807c1.53598,-1.01 2.37799,-2.945 3.69,-3.765c0.03299,0.044 0.017,0.133 0.07401,0.134c5.064,0.104 10.13699,0.026 15.20297,0c0.06702,0 0.173,-0.02499 0.22101,-0.06699c3.694,-3.214 7.30301,-6.469 10.996,-9.6828c0.048,-0.0416 0.203,-0.07761 0.22202,-0.13451c0.138,-0.42419 0.022,-0.394 -0.22202,-0.60509c-2.47198,-2.1428 -4.948,-4.3126 -7.60098,-6.4551c-2.71402,2.3805 -5.36002,4.8535 -8.11801,7.1947c-0.065,0.0552 -0.20502,-0.0008 -0.29501,0c-2.86499,0.0257 -5.69598,0.0412 -8.56097,0.0673c-0.12003,0.0011 -0.26501,-0.0545 -0.36902,0c-0.715,0.3764 -0.02301,1.3395 0,1.7485c0.035,0.627 0.008,1.254 0,1.882c-0.05399,-3.3802 -0.91501,-6.6101 -3.69,-9.077c-4.20801,-3.7413 -8.47198,-7.4325 -12.69299,-11.162c-0.03201,0.02821 -0.052,0.04111 -0.07401,0.06731c-4.138,-3.7835 -8.40799,-7.44141 -12.62,-11.162c-1.625,-1.4359 -3.599,-2.573 -5.608,-2.8913c0.08801,-2.67039 -1.29901,-5.585 0,-8.0017c1.63501,-3.0454 5.508,-4.721 8.19101,-7.1275c0.151,-0.1352 -0.22702,-0.4118 -0.29501,-0.4707c-2.35098,-2.037 -4.74799,-4.0688 -7.08499,-6.1189c-0.211,-0.185 -0.229,-0.3773 -0.29501,-0.4707zm-188.77899,109.8045c-0.668,-0.08 -1.213,-0.03799 -1.476,0.47c0.326,0.315 0.66701,0.367 1.034,0.47099c-3.01799,0.56401 -6.211,1.42 -7.45399,2.62201c0.084,0.16199 0.13699,0.174 0.22099,0.33699c-1.123,-0.85199 -3.996,0.43001 -5.092,1.27701c-1.79199,1.386 -4.866,1.8 -6.86301,2.959c-1.90999,1.10699 -4.21899,3.38499 -6.347,3.89999c-2.14,0.517 -5.33299,3.66701 -7.01099,5.177c-1.12801,1.01601 -2.25601,2.088 -3.395,3.093c-7.248,6.39799 -11.715,14.59599 -14.612,22.99699c-0.39801,1.155 -1.222,2.901 -1.328,4.03401c-0.355,3.76799 -0.29601,7.57999 -0.29601,11.364c0,3.55099 1.08101,8.409 2.51001,11.63199c0.38199,0.862 1.209,2.229 1.328,3.093c0.93799,6.80301 1.41399,13.608 0,20.442c-0.34901,1.686 -0.09401,3.817 -0.81201,5.379c-1.509,3.282 -1.883,8.032 -4.20599,11.02699c-2.095,2.70001 -2.633,6.517 -4.724,9.21201c-1.157,1.49301 -1.79401,3.586 -2.509,5.31201c-3.403,8.22598 -6.436,15.84399 -6.715,25.01401c-0.099,3.224 -0.626,7.41498 0.221,10.69098c1.913,7.39902 4.2,15.853 9.37201,21.853c7.92799,9.19601 17.12399,18.36401 17.786,30.52701c0.84,15.431 -6.959,27.24301 -11.07001,41.15201c-0.403,1.36499 -0.832,4.246 -0.88499,5.51401c-0.108,2.53699 -0.108,5.06 0,7.59799c0.006,0.15201 0.343,0.185 0.369,0.336c0.36099,2.095 -0.02501,4.362 0.51599,6.45499c2.295,8.875 5.85301,17.23502 11.218,25.01401c0.034,-0.02899 0.041,-0.10501 0.07401,-0.13501c0.565,1.02802 5.037,6.74902 5.534,7.26202c-6.52,0.11697 -13.035,0.134 -19.556,0.13498c-4.91901,0 -9.844,0.16 -14.76,0c-0.16499,-0.00598 -0.195,-0.189 -0.295,-0.33701c0.038,-0.05899 0.11,-0.08099 0.147,-0.13397c1.136,-1.647 3.122,-8.414 3.174,-10.22101c0.108,-3.78101 0.16,-7.58401 0,-11.36301c-0.045,-1.05701 -0.879,-2.867 -1.181,-4.035c-0.914,-3.53299 -1.99,-7.69901 -4.354,-10.55701c-3.045,-3.67899 -5.961,-7.603 -8.045,-11.63199c-0.834,-1.61301 -1.954,-3.13699 -2.361,-4.909c-0.359,-1.56201 -0.007,-3.39902 -0.29501,-4.97601c-0.16,-0.87698 -0.841,0.35901 -0.369,-1.008c1.069,-3.10098 0.825,-6.48401 2.066,-9.68298c5.09299,-13.12802 10.759,-28.39502 0.44299,-41.21802c-5.266,-6.54599 -12.3087,-10.229 -20.295,-11.633c-4.3168,-0.759 -9.2678,-0.59201 -13.3577,-2.28601c-4.9809,-2.064 -9.4058,-4.573 -13.579,-8.60699c-5.2144,-5.04099 -6.8571,-12.10098 -10.4057,-17.819c-2.763,-4.452 -7.4212,-7.92499 -11.4389,-11.16199c-1.5394,-1.23999 -3.7465,-3.297 -5.6826,-3.76501c-0.8945,-0.216 -1.7008,-1.14499 -2.5092,-1.61398c-1.667,-0.96701 -3.5378,-1.47601 -5.1659,-2.42102c-0.3896,-0.22598 -2.1388,-1.53497 -2.583,-1.27698c-2.4486,-2.142 -6.5017,-1.75 -9.0035,-3.564c-0.4682,-0.33902 -3.1351,-1.29102 -3.3948,-0.53802c-0.218,0.63202 2.509,3.06403 2.8782,3.56403c2.2093,2.98999 4.391,6.849 5.3873,10.21997c0.5578,1.888 1.3383,4.45602 1.476,6.18701c0.1118,1.40399 -0.6617,3.23901 0.369,4.23599c-0.5803,1.83301 -0.1035,4.11801 0,6.11902c0.131,2.53198 0.4149,6.17599 1.476,8.741c0.8669,2.095 0.7599,4.54199 1.6974,6.65698c3.0871,6.96301 7.1191,12.88 13.0625,18.625c7.9415,7.67801 18.5186,10.44601 26.3463,18.35703c6.8354,6.90799 4.1083,18.715 1.9926,26.896c-0.5237,2.02499 -0.9536,3.811 -1.3284,5.98499c-0.0556,0.32199 -0.6412,0.78702 -0.6642,1.008c-0.3561,3.44302 -0.3689,6.896 -0.369,10.35501c0,1.46799 0.4993,3.85999 1.1808,5.17801c1.1737,2.26898 2.6737,4.40598 3.8376,6.65698c0.8365,1.617 2.6826,2.888 4.2066,4.034c7.12431,5.35703 16.31651,5.603 23.68961,10.35501c3.0919,1.99301 6.596,5.237 8.339,8.60699c0.674,1.302 1.603,3.077 2.657,4.23599c-0.075,0.08701 -0.06499,0.25702 -0.14799,0.336c1.311,2.53403 1.238,5.81201 2.50999,8.27103c-15.1823,0.53098 -30.4164,0.284 -45.6084,0.336c-6.1662,0.022 -13.8257,6.90399 -14.3908,12.642c-0.1167,1.18399 -0.1066,2.37399 -0.1476,3.56299c-0.1062,3.07901 -0.1656,6.13199 -0.2214,9.21201c102.7862,0.08099 102.8182,0.05399 205.6052,0.13501c0.06401,-3.54501 0.382,-8.21902 0,-12.104c-0.222,-2.25302 -1.366,-4.18002 -2.657,-6.05099c-6.45799,-9.36603 -14.959,-7.733 -26.19901,-7.733c-11.793,0 -23.556,0.18799 -35.34999,0.13498c-0.158,-0.00098 -0.257,-0.228 -0.369,-0.33701c0.679,-0.86099 2.98199,-6.694 3.543,-7.59799c4.8,-7.73401 11.104,-15.987 19.409,-20.57599c7.024,-3.88 15.091,-6.59201 22.804,-9.077c4.42101,-1.42502 9.52,-2.85901 13.431,-5.379c3.17101,-2.04401 6.84001,-3.63901 9.89,-5.85001c17.29901,-12.543 32.74701,-30.811 33.578,-51.70801c0.01501,-0.36301 0.65701,-0.84399 0.664,-1.07599c0.26001,-7.771 -0.70401,-14.13501 -2.509,-21.11401c-0.38501,-1.48898 -0.30899,-3.30798 -1.03299,-4.707c-1.86099,-3.59799 -1.66501,-7.897 -3.32101,-11.63199c-0.776,-1.75 -0.651,-3.63699 -1.181,-5.51401c-0.21698,-0.76901 -0.573,0.198 -0.664,-0.80701c-0.40601,-4.51801 -0.603,-8.827 -0.51599,-13.64999c0.01999,-1.15698 0.48499,-3.168 0.95898,-4.23599c0.32501,-0.733 0.09601,-1.89801 0.36902,-2.689c1.27499,-3.698 1.746,-7.85602 3.026,-11.56601c0.38,-1.103 0.20401,-3.36099 0.29498,-4.37c0.72501,-8.05801 -0.04398,-16.69601 -2.65698,-24.27402c-1.02499,-2.97198 -2.02002,-9.37399 -4.354,-11.83499c-2.19299,-4.23999 -4.948,-8.879 -8.561,-12.37199c-0.53299,-0.51601 -3.33899,-3.87201 -4.354,-2.89101c0.42502,0.82001 0.336,3.06201 0.36902,3.429c0.05499,0.61 0.62598,1.621 0.664,2.084c0.31799,3.84401 0.25198,7.647 0.664,11.49901c0.02197,0.19699 0.10599,0.54399 0.14798,0.806c-0.23801,0.759 -0.46799,1.724 -0.517,2.287c-0.10199,1.185 -0.04498,2.377 -0.147,3.56299c-0.034,0.39401 -0.603,0.64601 -0.664,0.942c-1.05698,5.10899 -3.035,10.321 -6.716,14.59102c-4.836,5.60999 -10.59198,10.37 -15.79298,15.39798c-6.007,5.80701 -13.241,10.48102 -17.71201,17.68399c-2.35699,3.79703 -4.619,7.04102 -5.38699,11.49902c-0.01601,0.091 -0.66301,1.42798 -0.66501,1.479c-0.10699,3.02399 -0.15799,6.05499 0,9.077c0.05901,1.112 0.903,4.267 1.476,5.51398c3.10101,6.74301 7.96501,13.31403 10.11101,20.57602c0.461,1.55899 1.674,3.16599 1.993,4.707c1.147,5.54498 0.218,11.276 -1.55,16.40601c-2.37199,6.87997 -7.638,13.16299 -12.54599,18.96198c-9.15401,10.81601 -20.99001,21.17401 -28.339,33.01501c-2.658,4.28299 -5.745,8.10001 -7.38,12.84299c-0.411,1.19101 -1.403,2.77301 -1.10699,4.16901c-0.058,-0.186 -0.125,-0.36899 -0.369,-0.60498c-0.93199,0.901 -0.839,2.81 -1.40199,3.89999c-1.90201,3.67798 -2.412,8.97 -2.509,13.112c-0.043,1.81699 -0.312,4.26898 0.22099,6.186c-5.754,0.10898 -13.03,0.33099 -18.819,0.13498c-0.123,-0.005 -0.14499,-0.16098 -0.22099,-0.26898c0.013,-0.03 0.064,-0.03799 0.07401,-0.06802c0.86699,-2.79498 -0.14801,-5.823 -0.14801,-8.741c0,-6.01797 1.207,-11.681 2.509,-17.34799c0.22,-0.957 -0.067,-1.92801 0.295,-2.89099c2.034,-5.40601 3.35201,-12.47101 6.716,-17.34799c5.215,-7.56201 10.452,-15.453 15.793,-23.19901c1.601,-2.32101 4.166,-6.01401 4.871,-8.741c0.16299,-0.629 0.439,-1.88 0.812,-2.42001c1.881,-2.728 2.23801,-6.14099 3.321,-9.28c8.202,-23.78699 -9.58699,-37.81299 -12.694,-58.83499c-1.19299,-8.07602 0.826,-16.48901 5.314,-22.99701c3.46101,-5.01901 7.48601,-10.28299 9.74101,-15.73401c0.53099,-1.28299 0.521,-2.71399 1.03299,-4.034c0.43201,-1.112 1.15001,-3.28699 1.181,-4.371c0.25101,-8.84698 -0.22299,-20.28099 -5.38699,-27.76999c-5.744,-8.32899 -12.435,-15.937 -15.27701,-25.552c-2.207,-7.46899 -2.47899,-16.89 -1.32799,-24.677c0.23099,-1.563 0.87999,-3.554 1.03299,-5.17799c0.162,-1.72501 2.82901,-8.87201 2.436,-10.22c0.033,-0.03801 0.03999,-0.097 0.073,-0.13501c0.168,0.08101 0.12801,0.054 0.29601,0.13501c1.44899,-1.40201 1.82899,-3.82401 2.87799,-5.51401c2.15701,-3.476 4.30301,-7.026 6.19901,-10.69099c-0.64,-0.04401 -1.972,0.26801 -3.026,0.403c0.27299,-0.142 0.561,-0.161 0.812,-0.403c-0.58699,-0.02901 -1.325,-0.257 -1.993,-0.336zm301.02802,73.29199c-0.07101,0.033 0.04398,0.14301 0,0.20201c-2.07901,2.77199 -4.22702,5.521 -6.34702,8.26999c-0.04498,0.058 -0.07001,0.12001 -0.147,0.13501c-15.56198,2.948 -31.15298,5.86 -46.715,8.808c-2.16199,0.41 -5.17801,1.394 -6.79001,2.69c-6.285,5.052 -9.198,9.83099 -7.74899,17.21298c0.371,1.888 0.68301,3.83801 1.10699,5.716c0.04102,0.18201 0.02802,0.38602 0.14801,0.53799c0.02798,0.035 0.427,0.09302 0.51599,0.134c-4.79999,-1.22198 -10.702,-0.45599 -15.42398,0.80701c-1.73401,0.46402 -7.01901,1.784 -8.11801,3.228c-0.30099,-0.172 -0.23999,-0.005 -0.29501,-0.26898c-0.38998,-1.884 -0.68298,-3.83801 -1.10699,-5.716c-0.203,-0.89999 -0.61301,-2.56302 -1.181,-3.42902c-0.92398,-1.40799 -1.78299,-3.11899 -3.099,-4.371c-4.522,-4.29898 -11.34198,-6.44 -17.78598,-5.24399c-15.61002,2.89499 -31.17203,5.80899 -46.789,8.67401c-1.621,0.297 -9.53702,-6.49402 -10.332,-5.51401c-2.311,2.849 -4.37601,5.82199 -6.56802,8.741c-0.15799,0.211 -0.53098,0.603 -0.29498,0.73999c4.681,2.72101 9.34601,5.439 14.09601,8.069c0.08899,0.04901 0.18997,-0.048 0.29498,-0.06699c17.38699,-3.228 34.78299,-6.48502 52.17599,-9.68301c1.927,-0.354 5.34302,1.11301 5.978,2.689c0.18402,0.45801 0.414,1.052 0.51602,1.48001c1.18399,4.923 2.38898,9.85001 3.46899,14.793c0.08701,0.397 -0.96899,2.16901 -1.181,2.55499c-0.043,0.07901 -0.04901,0.25 -0.147,0.26901c-9.147,1.77701 -18.29999,3.36301 -27.45401,5.10999c-0.078,0.01501 -0.177,0.07703 -0.22098,0.13501c-4.19202,5.47299 -8.32202,10.97699 -12.47202,16.474c-0.125,0.16501 -0.11301,0.42999 0.07401,0.53799c3.36099,1.94202 6.72101,3.87601 10.10999,5.78201c0.06601,0.03699 0.21902,0.04999 0.29501,0.06699c3.20499,-4.21399 6.409,-8.474 9.668,-12.64099c0.08301,-0.10599 0.22601,-0.10599 0.36899,-0.134c5.83801,-1.15698 11.70602,-2.36301 17.56403,-3.42999c0.099,-0.01801 0.15997,0.06699 0.22198,0.13501c0.17499,0.19498 0.23999,0.495 0.29501,0.73999c2.29099,10.14499 4.45898,20.30798 6.71597,30.45999c1.56201,7.03 3.17502,14.02701 4.79703,21.04602c0.58899,2.55298 3.66098,5.93698 6.56799,6.85797c1.16901,0.371 2.569,0.95401 3.83701,1.07602c0.28198,0.02701 1.39499,-0.37799 1.54999,0.06799c1.20999,3.47202 2.94501,6.91602 6.125,9.27899c0.73901,0.54901 1.61401,0.87201 2.362,1.41202c0.96899,0.69998 0.45499,5.181 1.62399,6.65698c0.59802,0.75601 2.07901,2.23602 2.28702,3.16c0.07898,0.349 -0.33902,0.88101 -0.44202,1.20999c-0.336,1.06403 -0.31198,2.63101 -0.29599,3.63101c0.02798,1.755 0.74399,4.71301 2.06699,6.186c0.44702,0.49799 1.34201,1.15799 1.62302,1.74899c0.27399,0.57501 -0.366,1.02402 -0.44299,1.54599c-0.17502,1.194 -0.31302,2.46701 -0.29501,3.63101c0.06601,4.09201 2.328,6.19202 4.797,8.94299c-0.60699,0.79901 -3.64398,1.10101 -4.64899,1.61401c-2.31,1.17999 -4.70602,2.69699 -6.79001,4.30301c-4.58701,3.53598 -8.23801,10.97198 -8.33899,16.07098c-0.01202,0.59201 0.017,1.17001 0.14798,1.74802c0.03601,0.15997 0.11102,0.31097 0.147,0.47098c-0.117,0.85901 0.14401,2.69202 0.29501,3.362c0.42899,-0.03299 0.45798,-0.035 0.88599,-0.06699c3.98401,-0.68399 7.91101,-1.47501 11.88202,-2.21899c-0.69101,-4.319 0.51797,-8.73203 4.72299,-11.633c0.70099,-0.48401 1.22501,-1.17401 1.992,-1.479c2.56299,-1.02002 4.90799,-1.60703 8.04498,-2.08502c0.099,-0.01498 0.27402,0.04901 0.29501,0.13501c0.944,3.86301 1.707,7.75601 2.58301,11.63199c6.38397,-1.14899 6.383,-1.13599 12.767,-2.28598c-0.84702,-3.91299 -1.73001,-7.84201 -2.509,-11.767c-0.017,-0.086 0.04999,-0.18002 0.147,-0.202c1.69299,-0.37701 3.37399,-0.67902 5.09299,-0.94101c0.746,-0.11401 2.612,-0.159 3.54199,0c6.22202,1.06299 9.84399,4.29099 11.36502,9.48099c6.38397,-1.14899 6.383,-1.13699 12.767,-2.28598c-1.12003,-7.17401 -8.27402,-14.95801 -16.38303,-17.21402c-1.32098,-0.367 -2.991,-0.48798 -4.28,-0.87399c-1.94699,-0.582 -3.58798,-0.28699 -5.60898,-0.40298c-0.405,-0.02402 -2.57202,-0.26001 -3.10001,0.13397c-1.133,0.84601 -1.733,2.22101 -2.65701,3.22803c-0.495,0.53998 -1.15198,0.85699 -1.771,1.20999c3.67102,-3.061 6.259,-6.565 5.60901,-11.16202c-0.245,-1.73499 -0.64801,-3.15399 -1.255,-4.707c-0.27301,-0.69998 -2.36301,-2.547 -2.36099,-3.09299c0.00299,-0.75101 0.504,-1.61099 0.664,-2.353c0.366,-1.69601 -0.01801,-3.88901 -0.517,-5.51401c-0.46201,-1.50699 -1.29102,-2.72299 -2.06601,-4.034c-0.202,-0.34201 -1.06,-0.68298 -1.03299,-1.14401c0.09799,-1.66699 0.80499,-3.396 0.81198,-5.10999c0.00702,-1.724 -1.03299,-3.20401 -1.40298,-4.841c-0.08099,-0.35999 1.896,-2.86801 2.21399,-3.698c0.87701,-2.28299 1.99402,-7.19501 0.73801,-9.48099c3.74899,-1.36801 7.27701,-5.53 7.74899,-8.742c0.14001,-0.952 0.14099,-1.854 -0.073,-2.82401c-1.526,-6.91101 -3.05099,-13.79901 -4.57599,-20.70999c-0.013,-0.06 -0.06,-0.14102 -0.07401,-0.202c-2.147,-9.509 -4.245,-18.99301 -6.642,-28.64401c-0.02301,0.004 -0.05002,-0.005 -0.07401,0c0.70599,-0.60101 -1.06799,-2.76801 -0.147,-2.95901c3.155,-0.65298 6.27701,-1.22098 9.44601,-1.81497c2.647,-0.496 5.31699,-1.013 7.97098,-1.48001c5.582,-0.98001 9.40601,8.276 14.90701,8.20401c0.07901,-0.00101 0.177,-0.07703 0.22101,-0.13501c2.28799,-2.97 4.543,-5.94901 6.78998,-8.94299c0.065,-0.086 0.11301,-0.405 0,-0.47c-6.20798,-3.61801 -12.46698,-7.16501 -18.745,-10.69202c-0.05899,-0.03299 -0.15198,-0.01199 -0.22098,0c-9.16702,1.68701 -18.34802,3.48401 -27.52802,5.11099c-0.133,0.02301 -0.306,-0.267 -0.36899,-0.336c-0.673,-0.75 -1.53702,-1.258 -2.36102,-1.81598c0.08401,-0.11002 0.24701,-0.207 0.22101,-0.336c-0.99799,-4.89401 -2.215,-9.77002 -3.24701,-14.659c-0.39297,-1.86002 1.04401,-4.38901 2.95203,-5.44601c0.31,-0.172 1.40698,-0.564 1.62399,-0.60501c17.22598,-3.29199 34.49899,-6.42099 51.733,-9.68298c0.85199,-0.16101 4.117,-5.06 4.871,-6.052c1.35699,-1.785 2.77499,-3.526 4.13199,-5.312c0.211,-0.27701 0.77399,-0.92101 0.88599,-1.27701c0.082,-0.261 -0.41599,-0.41299 -0.517,-0.47099c-3.21597,-1.858 -6.46597,-3.70401 -9.66699,-5.58101c-0.34601,-0.203 0.08099,-0.47899 -0.81198,-0.067z',
            `bird` = 'path://m438.16,457.97501c-10.96201,-0.40601 -20.79001,-5.285 -27.59399,-13.823c-2.26801,-2.84601 -5.29202,-4.47202 -8.694,-4.47202c-3.40201,0 -6.42599,1.62601 -8.694,4.47202c-6.80502,8.944 -17.38901,13.823 -28.729,13.823c-3.02402,0 -5.67001,-0.40601 -8.31601,-0.81302l-65.77301,-97.983c-7.18198,-10.56998 -17.00998,-17.48199 -28.34998,-20.32797l0,-44.72202l26.45999,0c32.508,0 62.74899,-19.922 77.491,-50.821c27.97299,-15.45 47.25101,-47.162 47.25101,-83.34599c0,-6.912 -4.914,-12.19701 -11.34,-12.19701l-37.80099,0l-102.061,0l0,-69.1166c0,-29.2728 -21.925,-52.8537 -49.14101,-52.8537c-27.21701,0 -49.14101,23.5809 -49.14101,52.8537l0,8.1313l-45.361,0c-6.42599,0 -11.34,5.2854 -11.34,12.197l0,4.0653c0,6.912 4.914,12.197 11.34,12.197c3.402,0 6.426,-1.626 8.316,-4.06499l37.045,0l0,89.44399c0,47.569 32.886,86.59901 75.601,92.69801l0,45.12799c-11.34,2.84601 -21.54599,10.16501 -28.34999,20.32901l-66.151,98.38898c-1.89,0.40701 -3.78,0.40701 -5.67,0.40701c-11.341,0 -21.925,-4.879 -28.729,-13.82401c-2.268,-2.84601 -5.292,-4.47198 -8.694,-4.47198c-3.4021,0 -6.4261,1.62598 -8.6941,4.47198c-6.8041,8.94501 -17.3883,13.82401 -28.7285,13.82401c-11.3402,0 -21.9243,-4.879 -28.7284,-13.82401c-4.1581,-5.285 -11.3402,-5.69199 -15.8763,-1.21899c-4.9141,4.47198 -5.2921,12.19699 -1.134,17.07501c11.3402,14.22998 27.9724,22.362 46.1167,22.362c13.9862,0 26.8384,-4.879 37.4226,-13.41702c10.584,8.944 23.436,13.41702 37.423,13.41702c13.98601,0 26.838,-4.879 37.422,-13.41702c10.58401,8.944 23.43701,13.41702 37.423,13.41702c13.608,0 26.838,-4.879 37.04401,-13.41702c10.58501,8.944 23.81499,14.23001 37.80101,14.23001c0.37799,0 0.37799,0 0.75598,0c13.98599,0 27.59399,-5.28601 38.17902,-14.23001c0,0 0.37799,0 0.37799,0.40601c0.37799,0.40701 0.75601,0.40701 1.134,0.814c1.134,0.81302 2.646,2.03201 3.78,2.845c0.37799,0.40701 1.134,0.814 1.51199,1.22c1.134,0.81302 2.646,1.62601 3.78,2.03302c0.37799,0.40698 1.134,0.40698 1.51199,0.81299c1.89001,0.81299 3.40201,1.62601 5.29202,2.44c0.37799,0 0.75598,0 0.75598,0.40601c1.51199,0.40698 3.02402,0.81299 4.914,1.22c0.75601,0 1.134,0.40598 1.89001,0.40598c1.51199,0.40701 2.646,0.40701 4.15799,0.81403c0.75601,0 1.134,0 1.89001,0.40598c1.88998,0.40701 4.15799,0.40701 6.04797,0.40701c13.98602,0 26.83902,-4.879 37.423,-13.41699c10.20602,8.53799 22.68002,13.41699 35.91,13.41699l0.37799,0c6.048,0 11.34003,-5.28601 11.34003,-11.79102c-0.75601,-7.31799 -5.67001,-13.00998 -12.09601,-13.00998zm-74.08899,-285.81601l0,0l0,28.459c0,5.692 -0.37802,10.978 -1.51202,16.263c-10.20599,7.72501 -22.67999,12.19701 -36.28799,12.19701c-31.75299,0 -57.83499,-24.80101 -63.12698,-56.91901l100.927,0zm-177.66301,28.459l0,-121.9696c0,-15.8561 11.71899,-28.4597 26.461,-28.4597c14.74199,0 26.45999,12.6036 26.45999,28.4597l0,93.5106c0,51.634 38.93501,93.51001 86.942,93.51001c1.134,0 2.26801,-12.19701 3.78,-12.19701c-11.341,10.16399 -26.08301,16.26299 -41.58099,16.26299l-37.80099,0c-35.53201,0 -64.261,-31.30598 -64.261,-69.11699zm102.43999,258.17c-10.96201,0 -21.54599,-5.285 -28.35098,-13.823l-0.75601,-0.81299c-2.26801,-2.84601 -5.29199,-4.47202 -8.694,-4.47202l0,0c-3.40199,0 -6.42599,1.62601 -8.694,4.47202c-6.804,8.53799 -17.388,13.823 -28.34999,13.823c-11.34001,0 -21.925,-4.879 -28.729,-13.823c-0.756,-0.81302 -1.134,-1.22 -1.89,-2.03302l45.739,-67.897c3.78,-5.69199 9.07201,-9.75699 15.12,-11.78998c0,0 0,0 0.37801,0c7.938,-2.03302 15.87601,2.84601 18.901,10.97699l30.996,84.97299c-1.51199,0 -3.02402,0.40601 -4.53601,0.40601c-1.134,0 -1.134,0 -1.134,0z',
            `reptile` = 'path://m399.78601,82.5471c-40.26001,26.6179 -32.591,77.63589 -57.51401,110.90889c-53.681,77.63602 -155.289,117.56302 -258.8152,128.65399c-21.0886,2.21802 -47.9287,19.96402 -57.5144,44.36401c19.1715,-6.655 49.8458,-2.21899 65.183,8.87201c0,13.30899 -38.3429,26.61798 -21.0886,51.01801c13.42001,8.87299 32.5912,8.87299 51.76321,2.21799c17.254,-13.30899 19.17099,-22.181 26.84,-39.927c82.437,19.96399 139.951,-2.21799 139.951,-2.21799c0,0 5.75198,26.61798 23.00598,39.927c19.17203,11.09097 44.095,8.87299 61.34903,0c17.254,-19.96301 -21.08902,-31.05402 -21.08902,-70.98102c0,-59.89099 15.33801,-102.036 57.51501,-146.39999c13.41998,26.618 51.763,22.18199 67.09998,-2.218c5.75101,-11.091 9.58603,-22.18201 9.58603,-35.491c0,-79.8542 -61.349,-104.2542 -86.272,-88.7269zm47.92899,77.63589c-7.66901,0 -13.41998,-6.65399 -13.41998,-15.52699c0,-8.873 5.75098,-15.52701 13.41998,-15.52701c7.668,0 13.42001,6.65401 13.42001,15.52701c0,8.873 -5.75201,15.52699 -13.42001,15.52699zm-159.12399,-2.218c-15.33701,-33.27299 -57.51401,-77.63609 -147.62001,-48.8c-99.69139,35.491 -97.77429,128.654 -82.43709,150.83601c0,0 -23.0058,11.091 -9.5857,33.27298c11.5028,15.52701 72.8518,4.436 126.5318,-15.52698c53.68001,-17.746 99.69099,-46.58202 124.614,-68.76401c23.00601,-19.964 13.42001,-55.45399 -11.50299,-51.01801z',
            `detritus` = 'path://m421.38,72.426c-46.56,-46.64 -108.52002,-72.356 -174.64401,-72.42c-135.93199,0 -246.61999,110.572 -246.73599,246.5c-0.064,65.916 25.548,127.90401 72.1,174.55998c46.568,46.62802 108.284,72.436 174.19601,72.436l0.57199,0l0,-0.02399c134.95601,0 246.53999,-110.59601 246.64,-246.51602c0.064,-65.91197 -25.58398,-127.89198 -72.12799,-174.53597zm-163.67999,304.7c-2.836,2.86401 -6.8,4.504 -10.87201,4.504c-4.088,-0.008 -8.064,-1.65601 -10.93199,-4.56c-2.84801,-2.82401 -4.48401,-6.79199 -4.48,-10.87601c0.008,-4.07199 1.664,-8.064 4.532,-10.92398c2.856,-2.84802 7.064,-4.48801 10.92,-4.48801c4.06,0 8.028,1.64801 10.85999,4.504c2.89603,2.92001 4.556,6.91599 4.548,10.93201c-0.004,4.03198 -1.672,8.00397 -4.57599,10.90799zm7.42398,-94.452c-1.76001,0.388 -3.01999,1.948 -3.02402,3.75198l-0.01999,18.12003c-0.008,8.48798 -6.916,15.40799 -15.43599,15.40799c-8.51201,-0.008 -15.412,-6.94 -15.40401,-15.436l0.036,-34.96399c0.00801,-8.48401 6.916,-15.08 15.416,-15.08l0.06801,0c29.48799,0 53.49998,-24.32001 53.532,-53.808c0.01199,-14.28801 -5.53601,-27.884 -15.64001,-38.024c-10.13998,-10.132 -23.56799,-15.78801 -37.88397,-15.804c-29.49202,0 -53.51201,23.95599 -53.54401,53.464c-0.008,8.49199 -6.924,15.38 -15.44,15.38c-4.12,0 -7.996,-1.62401 -10.89999,-4.54401c-2.916,-2.912 -4.508,-6.78799 -4.504,-10.90401c0.04399,-46.492 37.896,-84.32399 84.448,-84.32399c46.53198,0.048 84.34399,37.936 84.29999,84.46001c-0.03198,39.17198 -27.78,73.78796 -66.004,82.30399z',
            `unidentified` = 'path://m421.38,72.426c-46.56,-46.64 -108.52002,-72.356 -174.64401,-72.42c-135.93199,0 -246.61999,110.572 -246.73599,246.5c-0.064,65.916 25.548,127.90401 72.1,174.55998c46.568,46.62802 108.284,72.436 174.19601,72.436l0.57199,0l0,-0.02399c134.95601,0 246.53999,-110.59601 246.64,-246.51602c0.064,-65.91197 -25.58398,-127.89198 -72.12799,-174.53597zm-163.67999,304.7c-2.836,2.86401 -6.8,4.504 -10.87201,4.504c-4.088,-0.008 -8.064,-1.65601 -10.93199,-4.56c-2.84801,-2.82401 -4.48401,-6.79199 -4.48,-10.87601c0.008,-4.07199 1.664,-8.064 4.532,-10.92398c2.856,-2.84802 7.064,-4.48801 10.92,-4.48801c4.06,0 8.028,1.64801 10.85999,4.504c2.89603,2.92001 4.556,6.91599 4.548,10.93201c-0.004,4.03198 -1.672,8.00397 -4.57599,10.90799zm7.42398,-94.452c-1.76001,0.388 -3.01999,1.948 -3.02402,3.75198l-0.01999,18.12003c-0.008,8.48798 -6.916,15.40799 -15.43599,15.40799c-8.51201,-0.008 -15.412,-6.94 -15.40401,-15.436l0.036,-34.96399c0.00801,-8.48401 6.916,-15.08 15.416,-15.08l0.06801,0c29.48799,0 53.49998,-24.32001 53.532,-53.808c0.01199,-14.28801 -5.53601,-27.884 -15.64001,-38.024c-10.13998,-10.132 -23.56799,-15.78801 -37.88397,-15.804c-29.49202,0 -53.51201,23.95599 -53.54401,53.464c-0.008,8.49199 -6.924,15.38 -15.44,15.38c-4.12,0 -7.996,-1.62401 -10.89999,-4.54401c-2.916,-2.912 -4.508,-6.78799 -4.504,-10.90401c0.04399,-46.492 37.896,-84.32399 84.448,-84.32399c46.53198,0.048 84.34399,37.936 84.29999,84.46001c-0.03198,39.17198 -27.78,73.78796 -66.004,82.30399z',
            `invertebrate` = 'path://m76.6852,324.99301c0,-102.28601 54.3028,-144.78801 78.6318,-144.78801c13.90199,0 17.92799,94.744 177.425,94.744c34.42499,0 53.12399,-18.94901 58.47101,-18.94901c5.77197,0 15.72699,19.59299 15.72699,62.45499c0,115.19 -148.61499,120.32501 -172.09401,120.57101c-49.03499,0.53101 -47.85599,44.35999 -76.17899,44.35999c-14.53101,0 -81.9818,-74.33698 -81.9818,-158.39297zm110.0848,-163.73701c0,11.123 37.649,75.795 131.45699,75.795c36.89401,0 88.71301,-24.93599 88.71301,-59.53699c0,-15.67101 -3.38199,-25.73201 -7.974,-25.73201c-3.271,0 -20.177,9.474 -41.832,9.474c-67.35599,0 -71.93301,-56.84599 -76.00601,-56.84599c-38.78099,0 -94.35799,45.72299 -94.35799,56.84599zm220.17,-113.69279c0,-7.8448 -4.45099,-18.9488 -15.72699,-18.9488c-11.276,0 -14.24802,19.6878 -19.61102,27.4c-8.052,-1.6486 -16.76398,3.6571 -20.41299,12.4683c-0.534,1.3075 -1.022,2.72861 -2.013,3.5624c-1.336,1.118 -3.11301,0.7769 -4.733,0.56841c-11.52798,-1.4401 -31.862,7.5038 -31.862,12.8473c0,5.3436 1.62,37.8972 59.17902,37.8972c13.634,0 35.17999,-5.229 35.17999,-13.832c0,-4.794 0,-54.118 0,-61.9628z'
          )

          #Create a new column 'classified_column' based on the mapping from the classification list
          class = classification_list[match(qw, names(classification_list))]

          class <- data.frame(class)
          class = class %>% gather('name', 'path', 1:length(data2$category))
          qw2 = class$path


          # emojis
          classification_list2 <- list(
            `mammal` =  'path://m115.089,80.352c-19.93079,-0.4459 -42.68719,8.2031 -42.68719,20.219c0,21.361 35.9702,10.67 47.9692,32.03101c0.268,0.478 0.544,0.72 0.812,1.125c2.614,23.23399 11.959,52.28099 23.188,52.28099c11.233,0 20.60899,-29.073 23.218,-52.312c0.25999,-0.394 0.521,-0.631 0.782,-1.09399c11.998,-21.36101 48,-10.67001 48,-32.03101c0,-21.3614 -72,-32.042 -72,0c0,-14.0185 -13.78,-19.8722 -29.28201,-20.219zm360.93801,34.40601c-8.43701,0.501 -28.69101,20.521 -55.68802,28.531c-35.995,10.681 -83.96698,-21.361 -71.96799,0c11.064,19.69901 32.36801,48.42101 73.25,52.782c-3.27301,19.08 2.28201,42.03799 -25.28201,64.718c-24.09299,19.83398 -36.25198,13.96799 -95.96799,-21.40601c-35.996,-21.31799 -84.009,-42.687 -156,-42.687c-86.1498,0 -95.9692,52.61501 -95.9692,117.50002c0,28.41699 1.8916,54.46298 11.25,74.78098c0.0355,0.077 0.0893,0.142 0.125,0.21902c1.3751,2.961 2.9128,5.79498 4.625,8.5c0.6395,1.01099 1.40369,1.93298 2.0937,2.90598c1.2682,1.78802 2.553,3.564 4,5.21902c0.8195,0.93698 1.7453,1.79398 2.625,2.68698c1.4597,1.48199 2.9609,2.927 4.5938,4.28101c1.09019,0.905 2.26649,1.74799 3.4375,2.59399c1.7047,1.23199 3.492,2.397 5.375,3.5c1.2331,0.72299 2.4998,1.42801 3.8125,2.09399c2.0739,1.052 4.28239,2.00101 6.5625,2.90601c1.4617,0.58002 2.9191,1.17001 4.4692,1.68802c2.388,0.79797 4.958,1.47897 7.562,2.125c1.626,0.40198 3.193,0.84598 4.906,1.18698c3.011,0.60101 6.273,1.03201 9.563,1.43802c1.618,0.19897 3.125,0.474 4.812,0.625c5.08499,0.45499 10.41299,0.71799 16.157,0.71799c35.647,0.00101 127.55099,-0.31201 156,-0.31201c23.99701,0 62.888,-7.09998 95.96799,-31.71899c3.83301,-2.85199 7.38702,-5.92801 10.81302,-9.09399c1.272,-1.16501 2.49799,-2.358 3.71899,-3.56201c1.802,-1.798 3.53299,-3.65198 5.21799,-5.53098c22.86301,-25.108 35.854,-57.039 40.28201,-88.625c-0.02899,0.06299 -0.06601,0.12399 -0.09399,0.18698c6.84198,-39.457 2.97998,-77.679 -4.625,-99.937c29.62,-12.205 28.68698,-53.05499 28.68698,-71.125c0,-5.341 -1.5,-7.355 -4.31198,-7.188zm-374.90601,184.87499c9.118,0 16.5,7.802 16.5,17.43802c0,9.63599 -7.382,17.43698 -16.5,17.43698c-9.1191,0 -16.5317,-7.80099 -16.5317,-17.43698c0,-9.63602 7.4125,-17.43802 16.5317,-17.43802z',
            # Whale emoji: 🐋
            `fish` = 'path://m205.188,80.7812c-16.78,0.00011 -33.24001,30.4448 -36.84401,64.40681c-73.35699,19.08099 -110.96899,81.035 -111.09399,129.812c3.2441,3.03201 11.5988,8.65201 21.6875,15.18799c27.0765,17.539 68.1205,42.75803 67.59351,50.46802c-0.72301,10.58301 -28.394,-1.121 -38.687,-3.56201c-13.1782,-3.11301 -19.5259,-5.58798 -24.0002,-6.46899c-1.8088,-0.35599 -3.397,-0.51501 -4.875,-0.25c-10.4677,4.103 -6.9193,15.35199 -3.0313,21.78101c18.6673,33.35901 90.79449,59.59399 151.53149,59.59399c7.91901,0 15.81601,-0.73801 23.68701,-1.78101c19.91,12.02402 45.789,21.25 71.81299,21.25c22.51501,0 4.733,-18.909 -9.375,-39.31299c26.276,-11.57901 50.367,-27.004 70.125,-43.375c24.564,37.49298 63.78302,66.25 91.09302,66.25c18.97897,0 37.948,-17.92801 18.96899,-37.40601c-18.979,-19.453 -37.96899,-70.25 -37.96899,-95.81299c0,-12.78101 18.978,-79.40901 37.96899,-98.87401c18.96698,-19.466 0.00998,-40.46901 -18.96899,-40.46901c-25.48203,0 -61.345,31.856 -86,68.343c-3.70502,-3.093 -7.504,-6.166 -11.53101,-9.218c-35.54901,-74.81599 -123.078,-120.56269 -172.093,-120.5628zm-62.813,111.3128c13.757,0 24.938,11.42601 24.937,25.56201c0,14.123 -11.17999,25.56299 -24.937,25.56299c-13.77,0 -24.937,-11.452 -24.937,-25.56299c0,-14.136 11.16699,-25.56201 24.937,-25.56201z',
            # Fish emoji: 🐟
            `primary producer` = 'path://m159.25,40.6562c-24.94501,21.2956 -35.47,49.4967 -34.125,77.1558c0.126,2.633 0.598,5.228 0.937,7.844c0.26,1.989 0.339,3.99599 0.719,5.969c0.868,4.50999 2.04501,8.996 3.531,13.375c1.424,4.198 3.076,8.019 4.907,11.625c0.063,0.12399 0.09201,0.282 0.15601,0.40601c0.02699,0.05299 0.06599,0.10399 0.09399,0.157c0.931,1.797 1.92601,3.545 2.96901,5.218c0.043,0.071 0.08,0.14899 0.12399,0.21899c1.035,1.647 2.134,3.241 3.282,4.78101c2.071,2.78099 4.442,5.31499 6.90601,7.81299c0.392,0.39801 0.69099,0.858 1.09399,1.25c1.748,1.701 3.80101,3.26801 5.75,4.875c1.39801,1.15201 2.651,2.38301 4.15601,3.5c1.40199,1.039 3.065,2.01401 4.562,3.03101c2.30901,1.56799 4.55,3.179 7.09401,4.71899c2.69499,1.62901 5.74599,3.272 8.71899,4.90601c1.41,0.77499 2.651,1.562 4.125,2.34399c5.771,3.061 13.097,6.52701 19.90601,9.84401c4.381,2.133 7.946,4.026 12.782,6.343l0,-0.03101c0.383,0.18401 0.644,0.315 1.03099,0.5c-28.61899,25.597 -51.97299,49.418 -71,71.375c3.01901,-29.38699 3.09801,-46.612 -13.25,-64.53101c-18.298,-20.05299 -47.74369,-31.87599 -79.18779,-25.43799c-0.247,0.49699 -0.3609,1.002 -0.5937,1.5c-0.0053,-0.00401 -0.0259,0.00499 -0.0313,0c-0.1405,0.30099 -0.2083,0.605 -0.3437,0.90599c-1.3185,2.93201 -2.4697,5.858 -3.3125,8.813c-0.0777,0.271 -0.1136,0.541 -0.1875,0.813c-0.8244,3.04399 -1.4639,6.086 -1.8125,9.12399c-0.0024,0.021 0.0024,0.04201 0,0.063c-1.1121,9.782 0.1117,19.466 3.3438,28.53101c0.2314,0.653 0.5922,1.25999 0.8437,1.90599c0.9142,2.338 1.8339,4.66501 3,6.907c0.6007,1.159 1.366,2.245 2.0313,3.375c1.0156,1.72101 1.9671,3.478 3.125,5.125c1.8886,2.69 3.9429,5.25601 6.1874,7.71899c9.15591,10.026 18.8129,15.50201 31.25,18.90601c3.1098,0.85101 6.38181,1.55301 9.8748,2.18701c8.62,1.565 19.165,2.59 30.87501,3.65698c-58.5201,70.431 -72.36211,120.69302 -76.93721,147.53101c-1.2299,7.18802 9.3944,16.25702 17.375,17.375c7.99419,1.08099 24.28719,-4.84299 25.5312,-12.03198c2.92,-17.18402 10.168,-47.13202 30.812,-86.46802c32.181,33.46201 48.39801,50.207 83.157,52.5c34.87401,2.24802 70.96802,-11.142 90.90601,-41.34399c-0.01599,-0.034 -0.047,-0.06 -0.06299,-0.09399c-0.892,-1.939 -1.85202,-3.82101 -2.87402,-5.65601c-0.04498,-0.08099 -0.07999,-0.16901 -0.12598,-0.25c-1.05801,-1.88599 -2.186,-3.72501 -3.37402,-5.5c-0.017,-0.02399 -0.047,-0.03799 -0.06299,-0.06201c-1.19,-1.77399 -2.439,-3.526 -3.75,-5.18799c-0.01801,-0.02301 -0.04401,-0.039 -0.06299,-0.06201c-1.311,-1.65997 -2.668,-3.26498 -4.09302,-4.81299c-0.01999,-0.022 -0.043,-0.04099 -0.06299,-0.06299c-2.87701,-3.11801 -5.96402,-5.996 -9.25,-8.65601c-6.62201,-5.358 -14.03201,-9.78302 -21.90601,-13.25c-11.783,-5.18802 -24.65601,-8.241 -37.71899,-9.09399c-4.27,-0.27402 -8.304,-0.289 -12.15601,-0.06201c-1.62399,0.095 -3.12199,0.41101 -4.687,0.59399c-2.243,0.263 -4.541,0.43201 -6.688,0.875c-1.466,0.30099 -2.849,0.83401 -4.28101,1.21899c-2.01599,0.54102 -4.06099,1.01401 -6.03099,1.71802c-1.82401,0.65201 -3.632,1.52298 -5.438,2.31299c-1.612,0.70502 -3.231,1.311 -4.84399,2.125c-1.86101,0.94 -3.77301,2.103 -5.65601,3.18701c-1.513,0.871 -3.024,1.63199 -4.562,2.59399c-2.942,1.841 -5.996,3.952 -9.09401,6.125c-0.41199,0.289 -0.804,0.51801 -1.21899,0.81201c-5.35699,3.79999 -11.58501,8.65298 -17.75,13.40698c-2.229,1.71899 -4.037,2.97202 -6.40601,4.81201c0.017,-0.00101 0.04501,0.00198 0.06201,0c-0.61601,0.479 -1.061,0.79498 -1.68701,1.28101c16.718,-31.733 42.283,-69.54602 81.59401,-111.96802c30.33699,34.79501 47.01399,52.76001 82.718,56.68701c36.87799,4.01498 75.965,-8.423 99,-39.40601c0.082,-0.12299 0.19998,-0.22101 0.28198,-0.34399c-13.97998,-35.30101 -48.68597,-55.983 -85.71899,-60.06201c-4.474,-0.48999 -8.711,-0.679 -12.78101,-0.625c-1.57397,0.01901 -3.03699,0.24501 -4.56299,0.34401c-2.47198,0.162 -4.96899,0.257 -7.34399,0.62399c-1.668,0.257 -3.27301,0.73801 -4.90601,1.09401c-2.05301,0.45 -4.13901,0.83299 -6.15601,1.43799c-2.01401,0.60301 -4.03101,1.40001 -6.03101,2.15601c-1.59,0.601 -3.189,1.149 -4.78198,1.84399c-2.19699,0.959 -4.457,2.11301 -6.68701,3.25c-1.44098,0.73401 -2.88,1.44301 -4.34399,2.25c-2.325,1.283 -4.77699,2.72301 -7.187,4.18701c-1.30301,0.791 -2.63501,1.595 -3.96901,2.43799c-3.77699,2.388 -8.29599,5.483 -12.407,8.28101c25.15401,-25.59399 55.058,-52.614 91.157,-80.875c2.784,-2.18401 5.44,-4.649 7.125,-7.21899c1.58401,0.573 3.06302,1.07999 4.59399,1.625c4.979,1.77499 10.54602,3.82999 15.03101,5.28099c1.785,0.57701 3.46701,1.04201 5.18701,1.563c2.81598,0.854 5.67801,1.744 8.34399,2.437c0.61099,0.159 1.177,0.257 1.78101,0.407c7.68799,1.91 14.89099,3.175 21.90698,3.5c0.02002,0.00101 0.04202,-0.00099 0.06201,0c7.52399,0.34201 14.91901,-0.314 22.625,-2.157c3.854,-0.91899 7.79401,-2.12 11.875,-3.65599c4.16299,-1.57501 8.21399,-3.37401 12.125,-5.40601c27.32101,-14.17599 47.71201,-39.192 50.03101,-70.8438c-30.52802,-23.616 -70.73801,-25.9827 -104,-13.43739c-31.07901,11.7597 -41.742,31.7836 -58.75,68.9692c-3.24301,0.744 -6.621,2.767 -9.78101,5.093c-35.27399,25.85599 -65.123,50.22099 -91.09399,73.28099c25.95399,-43.84999 38.905,-66.912 27.25,-101.312c-11.97101,-35.3012 -43.576,-65.2006 -88.78101,-72.0938z',
            # Herb emoji: 🌿
            `bird` = 'path://m146.88901,185.386c-1.33301,20.91 21.23499,39.567 -8.552,37.453c-29.786,-2.114 -94.11541,-32.061 -93.29871,-44.68001c0.8168,-12.62 44.5357,-34.897 74.3227,-32.78299c29.786,2.101 28.87299,19.08699 27.52801,40.00999zm241.67899,203.13899c-2.42599,-0.405 -4.70801,0.19 -6.77399,1.202c-27.92502,2.93701 -38.73401,-23.85898 -38.73401,-23.85898c-5.27301,-4.25302 -11.78299,-25.42902 -19.08499,-15.379l2.246,17.74597c2.246,17.746 30.867,40.80701 30.867,40.80701l-14.59302,20.11301c-4.035,5.55701 -3.026,13.49301 2.246,17.746c5.27301,4.25299 12.80402,3.189 16.83899,-2.367l8.08301,-11.13901l-0.46799,3.15201c-1.04501,6.91101 3.423,13.392 9.98099,14.49301c6.55801,1.10098 12.707,-3.608 13.75201,-10.51901l5.64499,-37.50299c1.021,-6.91101 -3.44699,-13.392 -10.005,-14.49301zm-75.40298,7.88501c-2.354,-0.73401 -4.68402,-0.46802 -6.87,0.228c-28.04501,-1.03799 -35.35901,-29.112 -35.35901,-29.112c-4.685,-4.96201 -8.444,-26.87201 -16.96001,-17.935l-0.036,17.897c-0.036,17.89798 25.40298,44.79498 25.40298,44.79498l-17.01898,17.87201c-4.70801,4.936 -4.72,12.94901 -0.03601,17.89801c4.68399,4.961 12.28702,4.974 16.983,0.03799l9.42801,-9.89902l-0.87601,3.06403c-1.91,6.69498 1.69299,13.746 8.047,15.771c6.353,2.01199 13.05499,-1.785 14.965,-8.48102l10.353,-36.36499c1.94601,-6.70801 -1.65698,-13.758 -8.02298,-15.771zm147.11899,-288.88c-4.60001,-2.152 -9.104,-0.721 -12.61099,3.089c-0.64902,0.708 -50.745,79.817 -174.539,62.578c-4.08401,-0.57001 37.70099,151.48399 38.422,151.408c1.48901,-0.177 36.87299,-4.65802 73.745,-32.315c33.84702,-25.37802 75.47601,-75.83 81.63699,-172.11501c0.336,-5.291 -2.05399,-10.48 -6.65399,-12.645zm-6.38901,182.00101c-2.45099,-4.25299 -7.08698,-7.08801 -11.759,-5.96201c-15.53,3.73401 -38.39798,6.87299 -54.40799,5.73401c-76.35199,-5.41702 -112.43298,-52.26201 -112.80499,-52.65501c-3.30301,-3.569 5.59698,146.21901 9.80099,146.52299c110.42599,7.84702 166.492,-76.28699 168.83401,-79.86899c2.66699,-4.12601 2.79898,-9.505 0.33698,-13.771zm-118.798,-26.479c-4.45599,69.742 15.80603,124.815 -50.37299,120.10599c-66.179,-4.69598 -121.849,-62.27399 -117.39301,-132.02899c4.45601,-69.756 172.23401,-57.81999 167.76599,11.923zm-15.96298,-83.59c-4.23901,66.26199 -47.10501,117.16998 -109.96901,112.702c-62.87599,-4.46799 -110.41479,-61.79401 -106.175,-128.05501c4.24001,-66.2618 58.036,-106.87949 120.91199,-102.41139c48.054,3.4048 98.968,59.2744 95.23201,117.7644zm-175.2,-43.326c0,-13.981 10.75499,-25.315 24.02199,-25.315c13.26601,0 24.02101,11.334 24.02101,25.315c0,13.981 -10.755,25.315 -24.02101,25.315c-13.267,0 -24.02199,-11.334 -24.02199,-25.315zm114.21001,96.905c0,0 91.642,71.489 148.77698,-56.439c4.75601,-10.658 20.23801,10.037 1.189,52.67999c-19.04898,42.64299 -98.18799,81.51399 -144.60898,19.442c-9.789,-13.101 -5.35699,-15.683 -5.35699,-15.683zm-34.25401,-171.3561c0,0 75.01799,3.215 93.65901,-6.0375c18.64099,-9.2526 1.634,37.1115 -39.17902,47.9586c-40.812,10.848 -54.48,-41.9211 -54.48,-41.9211zm25.23399,33.9346c0,0 54.06,1.7214 72.71301,-7.5185c18.65298,-9.2399 1.633,37.112 -39.17902,47.959c-40.82399,10.847 -33.534,-40.4405 -33.534,-40.4405z',
            # Bird emoji: 🐦
            `reptile` = 'path://m175.714,126.065c-8.83501,0 -28.20201,25.733 -43.83301,11.806c-5.407,-4.808 22.341,-14.663 21.222,-23.141c-0.92099,-6.964 -34.923,-17.43871 -23.03999,-24.0815c11.882,-6.6312 29.713,9.6485 43.16899,9.9355c29.27101,0.631 51.759,-9.7863 52.078,-9.9355c6.649,-3.1435 14.685,-0.5965 17.991,5.6905c3.31801,6.276 0.627,13.917 -5.99699,17.049c-1.61,0.757 -27.342,12.677 -61.59,12.677zm196.34499,325.43701c-48.74799,0 -100.54398,-33.40903 -100.54398,-95.31601c0,-15.76401 -10.93701,-19.056 -20.11601,-19.056c-9.16701,0 -20.104,3.29199 -20.104,19.056c0,61.90698 -51.808,95.31601 -100.54399,95.31601c-48.7364,0 -100.53241,-31.78003 -100.53241,-95.31601c0,-152.496 174.2754,-173.54901 174.2754,-152.496c0,21.052 -93.83501,-12.701 -93.83501,139.79599c0,25.41202 10.937,31.76801 20.104,31.76801c9.179,0 20.116,-3.293 20.116,-19.056c0,-61.896 51.79601,-95.31601 100.545,-95.31601c48.73601,0 100.54399,33.40802 100.54399,95.31601c0,15.763 10.93701,19.056 20.11603,19.056c9.17999,0 20.10397,-3.293 20.10397,-19.056l0,-190.632c0,-44.228 -41.98999,-50.83599 -67.021,-50.83599c0,0 -40.20798,12.712 -80.42799,12.712c-40.22099,0 -53.627,-29.7836 -53.627,-50.8361c-0.02499,-21.0526 53.60201,-38.1241 134.03,-38.1241c80.44,0 147.46201,51.0654 147.46201,127.08419l0,190.62001c0,61.90698 -51.80801,95.31601 -100.54501,95.31601zm-120.64799,-378.60191c0,-6.3362 5.502,-11.4727 12.28902,-11.4727c6.78598,0 12.28799,5.13651 12.28799,11.4727c0,6.3363 -5.50201,11.4728 -12.28799,11.4728c-6.78702,0 -12.28902,-5.13651 -12.28902,-11.4728z',
            `detritus` = 'path://m452.76999,302.44199c4.13501,-17.08398 2.76001,-35.35797 -5.203,-53.54599c-7.70297,-17.592 -20.98297,-31.504 -37.15997,-40.847c3.61298,-12.905 2.65799,-26.795 -3.681,-40.59799c-9.55402,-20.78601 -30.21802,-34.65401 -53.52902,-38.563c2.82901,-6.192 3.737,-13.954 0.409,-23.46c-11.35999,-32.4782 -56.802,-10.8259 -90.88199,-54.1196c-27.71899,15.8495 -33.74001,39.4071 -32.69499,59.4026c-27.50301,4.461 -43.16901,10.134 -43.16901,10.134l0,0.021c-15.45,5.955 -26.379,20.386 -26.379,37.26401c0,9.51599 3.61299,18.144 9.40599,25.03l-7.86099,2.793l0.01199,0.032c-26.47,9.42999 -45.158,32.21899 -45.158,58.884c0,11.33501 3.409,21.94398 9.316,31.157c-32.0702,13.73901 -54.4613,43.55399 -54.4613,78.40298c0,47.83002 41.9303,86.60901 93.6543,86.60901c37.13699,0 74.51199,-7.61099 108.27499,-18.02499c25.48099,11.259 64.69598,18.02499 123.73599,18.02499c46.009,0 83.30499,-35.54199 83.30499,-79.388c0,-23.55798 -10.827,-44.65799 -27.935,-59.20801zm-267.43298,-83.33899c0,-26.90599 17.802,-48.718 39.761,-48.718c21.95999,0 39.761,21.81201 39.761,48.718c0,26.905 -17.80101,48.71701 -39.761,48.71701c-21.959,0 -39.761,-21.81201 -39.761,-48.71701zm113.603,0c0,-26.90599 17.802,-48.718 39.76099,-48.718c21.95901,0 39.76102,21.81201 39.76102,48.718c0,26.905 -17.802,48.71701 -39.76102,48.71701c-21.95898,0 -39.76099,-21.81201 -39.76099,-48.71701zm-90.882,0c0,-14.948 10.172,-27.06599 22.72101,-27.06599c12.54799,0 22.71999,12.118 22.71999,27.06599c0,14.94701 -10.172,27.065 -22.71999,27.065c-12.54901,0 -22.72101,-12.118 -22.72101,-27.065zm102.24199,0c0,-14.948 10.173,-27.06599 22.72101,-27.06599c12.548,0 22.72101,12.118 22.72101,27.06599c0,14.94701 -10.173,27.065 -22.72101,27.065c-12.548,0 -22.72101,-12.118 -22.72101,-27.065zm-131.245,101.711c-2.79399,-5.33701 0.03401,-9.689 6.28201,-9.689l204.48499,0c6.24802,0 9.077,4.35199 6.28302,9.689c0,0 -29.00302,55.267 -108.52502,55.267c-79.52199,0 -108.52499,-55.267 -108.52499,-55.267zm108.52499,11.96301c-31.47897,0 -58.58499,9.98099 -71.47899,24.42398c16.95,10.33801 40.27199,18.88 71.47899,18.88c31.207,0 54.54102,-8.54199 71.479,-18.88c-12.89398,-14.44299 -40,-24.42398 -71.479,-24.42398z',
            # Leaf emoji: 🍂
            `unidentified` = 'path://m258.09399,90.625c-77.72499,0 -143.40599,44.38 -143.40599,96.90601c0,17.84299 19.237,32.28099 43,32.28099c23.76199,0 43.03099,-14.438 43.03099,-32.28099c0,-10.76801 22.37001,-32.31201 57.375,-32.31201c43.021,0 71.68701,21.526 71.68701,43.06201c0,43.07199 -77.384,53.77899 -86.03101,53.84399c-23.76199,0 -43.03101,14.47 -43.03101,32.31299l0,43.06201c0,17.84201 19.26901,32.31201 43.03101,32.31201c23.76199,0.00098 43,-14.47 43,-32.31201l0,-14.34399c11.42899,-1.72299 24.18701,-4.28302 37.09399,-8.06201c59.31201,-17.30399 91.96802,-51.39899 91.96802,-96.032c0.00098,-54.03299 -42.99503,-118.437 -157.71802,-118.437zm-14.34399,290.71899c-23.75999,0 -43.03101,14.47101 -43.03101,32.31201c0,17.841 19.27101,32.28198 43.03101,32.28198c23.76001,-0.00098 43,-14.44098 43,-32.28198c0,-17.841 -19.23999,-32.31201 -43,-32.31201z',
            `invertebrate` = 'path://m100.844,109.563c-15.63461,-0.87 -21.8029,26.993 -11.969,26.993c13.521,0 20.639,13.31 17.125,34.457c-27.0613,6.286 -54.9375,28.226 -54.9375,43.379c0,21.10901 12.106,21.097 36.3125,31.651c24.207,10.55399 -12.1033,84.44199 0,126.659c8.8112,30.71201 36.296,63.32901 96.813,63.32901l278.37401,0c12.10397,0 24.21899,0.004 24.21899,-10.55002c0,-7.759 -32.716,-21.207 -64.46899,-31.987c20.86899,-14.332 35.672,-34.51398 42.12598,-57.88599c18.51801,-67.15601 -26.70499,-135.457 -100.81299,-152.24901c-89.48001,-20.29599 -180.55901,29.22701 -202.937,110.356c-1.127,4.08301 -0.826,8.16101 0.562,11.86902c-4.354,-6.263 -4.99899,-14.77802 -1.25,-27.86203c6.756,-23.56598 16.39,-57.51599 2.53101,-82.40999c5.45999,-32.88499 16.72699,-63.063 -2.53101,-79.856c-24.207,-21.1084 -36.322,21.1 -24.21899,21.1c15.556,0 22.644,17.548 14.75,44.502c-4.104,-3.336 -8.94,-6.362 -14.75,-8.895c-4.66,-2.032 -9.90001,-2.82899 -15.37501,-2.862c4.315,-22.16699 6.649,-41.671 -7.312,-53.84499c-4.539,-3.958 -8.642,-5.692 -12.25,-5.893z'      # Snail emoji: 🐌
          )


          class2 = classification_list2[match(qw, names(classification_list2))]

          class2 <- data.frame(class2)
          class2 = class2 %>% gather('name', 'path', 1:length(data2$category))
          qw3 = class2$path


        }


        if (input$ch1 == 'Nocturnal or Diurnal') {
          #gpt3 classification
          classify_category <- function(text) {
            prompt <- paste(
              "Please classify the following as Nocturnal, Diurnal or Unidentified:\n\n",
              text,
              "\n\nCategory:"
            )
            response <- gpt3_single_completion(
              prompt_input = prompt,
              temperature = 0.3,
              max_tokens = 3,
              n = 1,
              model = "gpt-3.5-turbo-instruct"
            )
            category <- response[[1]]$gpt3
          }
          qw = sapply(data2$name, classify_category) %>% tolower()

          standardize_word <- function(word) {
            target_words <- c('nocturnal', 'diurnal', 'unidentified')
            distances <- stringdistmatrix(word, target_words, method = 'jw')

            closest_match_index <- which.min(distances)
            closest_match_distance <- distances[closest_match_index]

            other_distances <- distances[-closest_match_index]
            if (closest_match_distance < 10 &&
                all(closest_match_distance < other_distances + 3)) {
              return(target_words[closest_match_index])
            } else {
              return(word)
            }
          }

          qw <- sapply(qw, standardize_word)


          classification_list <- list(
            `nocturnal` = 'path://m58.7766,224.431l12.8893,-7.85899l12.7605,8.12599l-2.3201,-16.95999l10.4565,-11.89401l-14.3072,-2.638l-6.3158,-15.47l-6.50909,15.37401l-14.3555,2.27499l10.2954,12.123l-2.594,16.923zm261.20341,25.144c-34.914,-71.76199 -32.41702,-156.7948 0.07999,-223.7769c-32.09399,-0.0574 -64.62399,9.3885 -94.431,29.8293c-64.22099,44.0365 -98.184,126.02861 -93.802,208.28859c15.226,0.59302 29.629,7.01801 41.23001,18.52902c10.972,-7.24701 23.12,-10.97601 35.784,-10.97601c33.722,0 62.884,26.94202 71.987,64.61099c23.78101,8.70102 40.55301,34.66702 40.55301,65.28101c0,31.97101 -18.64102,58.702 -43.66202,66.293c44.871,12.25702 93.59201,5.37402 136.62701,-24.09198c29.80701,-20.422 52.95898,-49.12302 68.974,-82.16501c-65.12302,-0.134 -128.42599,-40.078 -163.34,-111.82201zm-14.40402,151.74699c0,-25.94699 -16.77298,-47.01898 -38.08798,-49.371c-3.69,-34.763 -28.38901,-61.74298 -58.647,-61.74298c-14.468,0 -27.519,6.32898 -37.83,16.483c-9.683,-14.685 -24.58701,-24.30301 -41.504,-24.30301c-25.27901,0 -46.32121,21.052 -51.58971,49.142c-27.4866,2.27499 -49.2374,29.16 -49.2374,62.37302c0,34.64798 23.6842,62.73798 52.8947,62.73798c6.203,0 12.0999,-1.492 17.6263,-3.82498c9.6351,15.67999 25.1181,25.98599 42.7121,25.98599c10.763,0 20.752,-3.862 29.114,-10.42099c9.53801,10.97598 22.492,17.82098 36.847,17.82098c21.123,0 39.20001,-14.819 47.675,-36.082c2.59401,0.59302 5.252,0.995 8.007,0.995c23.20099,0.01901 42.01999,-22.29599 42.01999,-49.793zm115.311,-123.96298l7.54102,-19.69501l17.93198,-3.767l-13.43698,-14.62801l2.49701,-21.435l-15.83801,10.689l-16.38501,-9.446l3.65701,21.205l-12.63202,15.565l18.09402,2.44801l8.57098,19.064zm-69.345,-91.24701l5.88101,13.05901l5.172,-13.51801l12.293,-2.563l-9.216,-10.019l1.724,-14.685l-10.875,7.304l-11.246,-6.48201l2.513,14.55101l-8.668,10.651l12.422,1.702zm59.22702,-38.817l3.60898,8.03101l3.17401,-8.27901l7.556,-1.60699l-5.655,-6.157l1.03101,-8.987l-6.67001,4.513l-6.84698,-3.996l1.49799,8.91l-5.31699,6.53999l7.621,1.032zm-271.91701,-54.0177l3.60899,8.0307l3.174,-8.2984l7.556,-1.6062l-5.655,-6.157l1.047,-8.9871l-6.67,4.4935l-6.87999,-3.9772l1.53099,8.8914l-5.33299,6.5587l7.621,1.0516z',
            `diurnal` = 'path://m426.62701,415.82101c0,0 -104.83502,-32.737 -163.07703,-32.737c-58.24098,0 -163.07599,32.737 -163.07599,32.737c0,0 34.94501,-109.12201 34.94501,-152.77103c0,-43.64899 -34.94501,-152.77099 -34.94501,-152.77099c0,0 104.83501,32.73701 163.07599,32.73701c58.242,0 163.07703,-32.73701 163.07703,-32.73701c0,0 -34.94501,109.122 -34.94501,152.77099c0,43.64902 34.94501,152.77103 34.94501,152.77103zm-163.09003,-360.11041c0,0 -55.63699,89.73239 -90.59399,122.4684c-34.95599,32.737 -130.71839,84.87498 -130.71839,84.87498c-0.0001,0 89.94939,46.68301 130.71839,84.875c40.76901,38.19302 90.59399,122.43802 90.59399,122.43802c0,0 55.68002,-89.70102 90.625,-122.43802c34.94501,-32.73599 130.71902,-84.875 130.71902,-84.875c0,0 -95.78601,-52.13799 -130.71902,-84.87498c-34.93298,-32.73601 -90.625,-122.4684 -90.625,-122.4684zm0,98.2184c64.33401,0 116.5,48.84599 116.5,109.12498c0,60.27902 -52.16599,109.125 -116.5,109.125c-64.33398,0 -116.46899,-48.84598 -116.46899,-109.125c0,-60.27899 52.13501,-109.12498 116.46899,-109.12498z',
            `unidentified` = 'path://m421.38,72.426c-46.56,-46.64 -108.52002,-72.356 -174.64401,-72.42c-135.93199,0 -246.61999,110.572 -246.73599,246.5c-0.064,65.916 25.548,127.90401 72.1,174.55998c46.568,46.62802 108.284,72.436 174.19601,72.436l0.57199,0l0,-0.02399c134.95601,0 246.53999,-110.59601 246.64,-246.51602c0.064,-65.91197 -25.58398,-127.89198 -72.12799,-174.53597zm-163.67999,304.7c-2.836,2.86401 -6.8,4.504 -10.87201,4.504c-4.088,-0.008 -8.064,-1.65601 -10.93199,-4.56c-2.84801,-2.82401 -4.48401,-6.79199 -4.48,-10.87601c0.008,-4.07199 1.664,-8.064 4.532,-10.92398c2.856,-2.84802 7.064,-4.48801 10.92,-4.48801c4.06,0 8.028,1.64801 10.85999,4.504c2.89603,2.92001 4.556,6.91599 4.548,10.93201c-0.004,4.03198 -1.672,8.00397 -4.57599,10.90799zm7.42398,-94.452c-1.76001,0.388 -3.01999,1.948 -3.02402,3.75198l-0.01999,18.12003c-0.008,8.48798 -6.916,15.40799 -15.43599,15.40799c-8.51201,-0.008 -15.412,-6.94 -15.40401,-15.436l0.036,-34.96399c0.00801,-8.48401 6.916,-15.08 15.416,-15.08l0.06801,0c29.48799,0 53.49998,-24.32001 53.532,-53.808c0.01199,-14.28801 -5.53601,-27.884 -15.64001,-38.024c-10.13998,-10.132 -23.56799,-15.78801 -37.88397,-15.804c-29.49202,0 -53.51201,23.95599 -53.54401,53.464c-0.008,8.49199 -6.924,15.38 -15.44,15.38c-4.12,0 -7.996,-1.62401 -10.89999,-4.54401c-2.916,-2.912 -4.508,-6.78799 -4.504,-10.90401c0.04399,-46.492 37.896,-84.32399 84.448,-84.32399c46.53198,0.048 84.34399,37.936 84.29999,84.46001c-0.03198,39.17198 -27.78,73.78796 -66.004,82.30399z'
          )

          #Create a new column 'classified_column' based on the mapping from the classification list
          class = classification_list[match(qw, names(classification_list))]

          class <- data.frame(class)
          class = class %>% gather('name', 'path', 1:length(data2$category))
          qw2 = class$path
          qw3 = data2$grp

        }

        if (input$ch1 == 'Niche and Habitat (Ocean)') {
          #gpt3 classification
          classify_category <- function(text) {
            prompt <- paste(
              "Please classify the following as  Benthic, Pelagic, Terrestrial or Unidentified:\n\n",
              text,
              "\n\nCategory:"
            )
            response <- gpt3_single_completion(
              prompt_input = prompt,
              temperature = 0.1,
              max_tokens = 3,
              n = 1,
              model = "gpt-3.5-turbo-instruct"
            )
            category <- response[[1]]$gpt3
          }
          qw = sapply(data2$name, classify_category) %>% tolower()

          standardize_word <- function(word) {
            target_words <- c('benthic',
                              'pelagic',
                              'terrestrial',
                              'unidentified')
            distances <- stringdistmatrix(word, target_words, method = 'jw')

            closest_match_index <- which.min(distances)
            closest_match_distance <- distances[closest_match_index]

            other_distances <- distances[-closest_match_index]
            if (closest_match_distance < 10 &&
                all(closest_match_distance < other_distances + 3)) {
              return(target_words[closest_match_index])
            } else {
              return(word)
            }
          }

          qw <- sapply(qw, standardize_word)

          classification_list <- list(
            `benthic` = 'path://m58.7766,224.431l12.8893,-7.85899l12.7605,8.12599l-2.3201,-16.95999l10.4565,-11.89401l-14.3072,-2.638l-6.3158,-15.47l-6.50909,15.37401l-14.3555,2.27499l10.2954,12.123l-2.594,16.923zm261.20341,25.144c-34.914,-71.76199 -32.41702,-156.7948 0.07999,-223.7769c-32.09399,-0.0574 -64.62399,9.3885 -94.431,29.8293c-64.22099,44.0365 -98.184,126.02861 -93.802,208.28859c15.226,0.59302 29.629,7.01801 41.23001,18.52902c10.972,-7.24701 23.12,-10.97601 35.784,-10.97601c33.722,0 62.884,26.94202 71.987,64.61099c23.78101,8.70102 40.55301,34.66702 40.55301,65.28101c0,31.97101 -18.64102,58.702 -43.66202,66.293c44.871,12.25702 93.59201,5.37402 136.62701,-24.09198c29.80701,-20.422 52.95898,-49.12302 68.974,-82.16501c-65.12302,-0.134 -128.42599,-40.078 -163.34,-111.82201zm-14.40402,151.74699c0,-25.94699 -16.77298,-47.01898 -38.08798,-49.371c-3.69,-34.763 -28.38901,-61.74298 -58.647,-61.74298c-14.468,0 -27.519,6.32898 -37.83,16.483c-9.683,-14.685 -24.58701,-24.30301 -41.504,-24.30301c-25.27901,0 -46.32121,21.052 -51.58971,49.142c-27.4866,2.27499 -49.2374,29.16 -49.2374,62.37302c0,34.64798 23.6842,62.73798 52.8947,62.73798c6.203,0 12.0999,-1.492 17.6263,-3.82498c9.6351,15.67999 25.1181,25.98599 42.7121,25.98599c10.763,0 20.752,-3.862 29.114,-10.42099c9.53801,10.97598 22.492,17.82098 36.847,17.82098c21.123,0 39.20001,-14.819 47.675,-36.082c2.59401,0.59302 5.252,0.995 8.007,0.995c23.20099,0.01901 42.01999,-22.29599 42.01999,-49.793zm115.311,-123.96298l7.54102,-19.69501l17.93198,-3.767l-13.43698,-14.62801l2.49701,-21.435l-15.83801,10.689l-16.38501,-9.446l3.65701,21.205l-12.63202,15.565l18.09402,2.44801l8.57098,19.064zm-69.345,-91.24701l5.88101,13.05901l5.172,-13.51801l12.293,-2.563l-9.216,-10.019l1.724,-14.685l-10.875,7.304l-11.246,-6.48201l2.513,14.55101l-8.668,10.651l12.422,1.702zm59.22702,-38.817l3.60898,8.03101l3.17401,-8.27901l7.556,-1.60699l-5.655,-6.157l1.03101,-8.987l-6.67001,4.513l-6.84698,-3.996l1.49799,8.91l-5.31699,6.53999l7.621,1.032zm-271.91701,-54.0177l3.60899,8.0307l3.174,-8.2984l7.556,-1.6062l-5.655,-6.157l1.047,-8.9871l-6.67,4.4935l-6.87999,-3.9772l1.53099,8.8914l-5.33299,6.5587l7.621,1.0516z',
            `pelagic` = 'path://m426.62701,415.82101c0,0 -104.83502,-32.737 -163.07703,-32.737c-58.24098,0 -163.07599,32.737 -163.07599,32.737c0,0 34.94501,-109.12201 34.94501,-152.77103c0,-43.64899 -34.94501,-152.77099 -34.94501,-152.77099c0,0 104.83501,32.73701 163.07599,32.73701c58.242,0 163.07703,-32.73701 163.07703,-32.73701c0,0 -34.94501,109.122 -34.94501,152.77099c0,43.64902 34.94501,152.77103 34.94501,152.77103zm-163.09003,-360.11041c0,0 -55.63699,89.73239 -90.59399,122.4684c-34.95599,32.737 -130.71839,84.87498 -130.71839,84.87498c-0.0001,0 89.94939,46.68301 130.71839,84.875c40.76901,38.19302 90.59399,122.43802 90.59399,122.43802c0,0 55.68002,-89.70102 90.625,-122.43802c34.94501,-32.73599 130.71902,-84.875 130.71902,-84.875c0,0 -95.78601,-52.13799 -130.71902,-84.87498c-34.93298,-32.73601 -90.625,-122.4684 -90.625,-122.4684zm0,98.2184c64.33401,0 116.5,48.84599 116.5,109.12498c0,60.27902 -52.16599,109.125 -116.5,109.125c-64.33398,0 -116.46899,-48.84598 -116.46899,-109.125c0,-60.27899 52.13501,-109.12498 116.46899,-109.12498z',
            `terrestrial` = 'path://m421.38,72.426c-46.56,-46.64 -108.52002,-72.356 -174.64401,-72.42c-135.93199,0 -246.61999,110.572 -246.73599,246.5c-0.064,65.916 25.548,127.90401 72.1,174.55998c46.568,46.62802 108.284,72.436 174.19601,72.436l0.57199,0l0,-0.02399c134.95601,0 246.53999,-110.59601 246.64,-246.51602c0.064,-65.91197 -25.58398,-127.89198 -72.12799,-174.53597zm-163.67999,304.7c-2.836,2.86401 -6.8,4.504 -10.87201,4.504c-4.088,-0.008 -8.064,-1.65601 -10.93199,-4.56c-2.84801,-2.82401 -4.48401,-6.79199 -4.48,-10.87601c0.008,-4.07199 1.664,-8.064 4.532,-10.92398c2.856,-2.84802 7.064,-4.48801 10.92,-4.48801c4.06,0 8.028,1.64801 10.85999,4.504c2.89603,2.92001 4.556,6.91599 4.548,10.93201c-0.004,4.03198 -1.672,8.00397 -4.57599,10.90799zm7.42398,-94.452c-1.76001,0.388 -3.01999,1.948 -3.02402,3.75198l-0.01999,18.12003c-0.008,8.48798 -6.916,15.40799 -15.43599,15.40799c-8.51201,-0.008 -15.412,-6.94 -15.40401,-15.436l0.036,-34.96399c0.00801,-8.48401 6.916,-15.08 15.416,-15.08l0.06801,0c29.48799,0 53.49998,-24.32001 53.532,-53.808c0.01199,-14.28801 -5.53601,-27.884 -15.64001,-38.024c-10.13998,-10.132 -23.56799,-15.78801 -37.88397,-15.804c-29.49202,0 -53.51201,23.95599 -53.54401,53.464c-0.008,8.49199 -6.924,15.38 -15.44,15.38c-4.12,0 -7.996,-1.62401 -10.89999,-4.54401c-2.916,-2.912 -4.508,-6.78799 -4.504,-10.90401c0.04399,-46.492 37.896,-84.32399 84.448,-84.32399c46.53198,0.048 84.34399,37.936 84.29999,84.46001c-0.03198,39.17198 -27.78,73.78796 -66.004,82.30399z',
            `unidentified` = 'path://m421.38,72.426c-46.56,-46.64 -108.52002,-72.356 -174.64401,-72.42c-135.93199,0 -246.61999,110.572 -246.73599,246.5c-0.064,65.916 25.548,127.90401 72.1,174.55998c46.568,46.62802 108.284,72.436 174.19601,72.436l0.57199,0l0,-0.02399c134.95601,0 246.53999,-110.59601 246.64,-246.51602c0.064,-65.91197 -25.58398,-127.89198 -72.12799,-174.53597zm-163.67999,304.7c-2.836,2.86401 -6.8,4.504 -10.87201,4.504c-4.088,-0.008 -8.064,-1.65601 -10.93199,-4.56c-2.84801,-2.82401 -4.48401,-6.79199 -4.48,-10.87601c0.008,-4.07199 1.664,-8.064 4.532,-10.92398c2.856,-2.84802 7.064,-4.48801 10.92,-4.48801c4.06,0 8.028,1.64801 10.85999,4.504c2.89603,2.92001 4.556,6.91599 4.548,10.93201c-0.004,4.03198 -1.672,8.00397 -4.57599,10.90799zm7.42398,-94.452c-1.76001,0.388 -3.01999,1.948 -3.02402,3.75198l-0.01999,18.12003c-0.008,8.48798 -6.916,15.40799 -15.43599,15.40799c-8.51201,-0.008 -15.412,-6.94 -15.40401,-15.436l0.036,-34.96399c0.00801,-8.48401 6.916,-15.08 15.416,-15.08l0.06801,0c29.48799,0 53.49998,-24.32001 53.532,-53.808c0.01199,-14.28801 -5.53601,-27.884 -15.64001,-38.024c-10.13998,-10.132 -23.56799,-15.78801 -37.88397,-15.804c-29.49202,0 -53.51201,23.95599 -53.54401,53.464c-0.008,8.49199 -6.924,15.38 -15.44,15.38c-4.12,0 -7.996,-1.62401 -10.89999,-4.54401c-2.916,-2.912 -4.508,-6.78799 -4.504,-10.90401c0.04399,-46.492 37.896,-84.32399 84.448,-84.32399c46.53198,0.048 84.34399,37.936 84.29999,84.46001c-0.03198,39.17198 -27.78,73.78796 -66.004,82.30399z'
          )

          #Create a new column 'classified_column' based on the mapping from the classification list
          class = classification_list[match(qw, names(classification_list))]

          class <- data.frame(class)
          class = class %>% gather('name', 'path', 1:length(data2$category))
          qw2 = class$path
          qw3 = data2$grp


        }
        if (input$ch1 == 'Niche and Habitat (River)') {
          #gpt3 classification
          classify_category <- function(text) {
            prompt <- paste(
              "Please classify the following as  Benthic, Littoral, Demersal or Unidentified:\n\n",
              text,
              "\n\nCategory:"
            )
            response <- gpt3_single_completion(
              prompt_input = prompt,
              temperature = 0.9,
              max_tokens = 3,
              n = 1,
              model = "gpt-3.5-turbo-instruct"
            )
            category <- response[[1]]$gpt3
          }
          qw = sapply(data2$name, classify_category) %>% tolower()

          standardize_word <- function(word) {
            target_words <- c('benthic', 'littoral', 'demersal', 'unidentified')
            distances <- stringdistmatrix(word, target_words, method = 'jw')

            closest_match_index <- which.min(distances)
            closest_match_distance <- distances[closest_match_index]

            other_distances <- distances[-closest_match_index]
            if (closest_match_distance < 10 &&
                all(closest_match_distance < other_distances + 3)) {
              return(target_words[closest_match_index])
            } else {
              return(word)
            }
          }

          qw <- sapply(qw, standardize_word)

          classification_list <- list(
            `benthic` = 'path://m58.7766,224.431l12.8893,-7.85899l12.7605,8.12599l-2.3201,-16.95999l10.4565,-11.89401l-14.3072,-2.638l-6.3158,-15.47l-6.50909,15.37401l-14.3555,2.27499l10.2954,12.123l-2.594,16.923zm261.20341,25.144c-34.914,-71.76199 -32.41702,-156.7948 0.07999,-223.7769c-32.09399,-0.0574 -64.62399,9.3885 -94.431,29.8293c-64.22099,44.0365 -98.184,126.02861 -93.802,208.28859c15.226,0.59302 29.629,7.01801 41.23001,18.52902c10.972,-7.24701 23.12,-10.97601 35.784,-10.97601c33.722,0 62.884,26.94202 71.987,64.61099c23.78101,8.70102 40.55301,34.66702 40.55301,65.28101c0,31.97101 -18.64102,58.702 -43.66202,66.293c44.871,12.25702 93.59201,5.37402 136.62701,-24.09198c29.80701,-20.422 52.95898,-49.12302 68.974,-82.16501c-65.12302,-0.134 -128.42599,-40.078 -163.34,-111.82201zm-14.40402,151.74699c0,-25.94699 -16.77298,-47.01898 -38.08798,-49.371c-3.69,-34.763 -28.38901,-61.74298 -58.647,-61.74298c-14.468,0 -27.519,6.32898 -37.83,16.483c-9.683,-14.685 -24.58701,-24.30301 -41.504,-24.30301c-25.27901,0 -46.32121,21.052 -51.58971,49.142c-27.4866,2.27499 -49.2374,29.16 -49.2374,62.37302c0,34.64798 23.6842,62.73798 52.8947,62.73798c6.203,0 12.0999,-1.492 17.6263,-3.82498c9.6351,15.67999 25.1181,25.98599 42.7121,25.98599c10.763,0 20.752,-3.862 29.114,-10.42099c9.53801,10.97598 22.492,17.82098 36.847,17.82098c21.123,0 39.20001,-14.819 47.675,-36.082c2.59401,0.59302 5.252,0.995 8.007,0.995c23.20099,0.01901 42.01999,-22.29599 42.01999,-49.793zm115.311,-123.96298l7.54102,-19.69501l17.93198,-3.767l-13.43698,-14.62801l2.49701,-21.435l-15.83801,10.689l-16.38501,-9.446l3.65701,21.205l-12.63202,15.565l18.09402,2.44801l8.57098,19.064zm-69.345,-91.24701l5.88101,13.05901l5.172,-13.51801l12.293,-2.563l-9.216,-10.019l1.724,-14.685l-10.875,7.304l-11.246,-6.48201l2.513,14.55101l-8.668,10.651l12.422,1.702zm59.22702,-38.817l3.60898,8.03101l3.17401,-8.27901l7.556,-1.60699l-5.655,-6.157l1.03101,-8.987l-6.67001,4.513l-6.84698,-3.996l1.49799,8.91l-5.31699,6.53999l7.621,1.032zm-271.91701,-54.0177l3.60899,8.0307l3.174,-8.2984l7.556,-1.6062l-5.655,-6.157l1.047,-8.9871l-6.67,4.4935l-6.87999,-3.9772l1.53099,8.8914l-5.33299,6.5587l7.621,1.0516z',
            `littoral` = 'path://m426.62701,415.82101c0,0 -104.83502,-32.737 -163.07703,-32.737c-58.24098,0 -163.07599,32.737 -163.07599,32.737c0,0 34.94501,-109.12201 34.94501,-152.77103c0,-43.64899 -34.94501,-152.77099 -34.94501,-152.77099c0,0 104.83501,32.73701 163.07599,32.73701c58.242,0 163.07703,-32.73701 163.07703,-32.73701c0,0 -34.94501,109.122 -34.94501,152.77099c0,43.64902 34.94501,152.77103 34.94501,152.77103zm-163.09003,-360.11041c0,0 -55.63699,89.73239 -90.59399,122.4684c-34.95599,32.737 -130.71839,84.87498 -130.71839,84.87498c-0.0001,0 89.94939,46.68301 130.71839,84.875c40.76901,38.19302 90.59399,122.43802 90.59399,122.43802c0,0 55.68002,-89.70102 90.625,-122.43802c34.94501,-32.73599 130.71902,-84.875 130.71902,-84.875c0,0 -95.78601,-52.13799 -130.71902,-84.87498c-34.93298,-32.73601 -90.625,-122.4684 -90.625,-122.4684zm0,98.2184c64.33401,0 116.5,48.84599 116.5,109.12498c0,60.27902 -52.16599,109.125 -116.5,109.125c-64.33398,0 -116.46899,-48.84598 -116.46899,-109.125c0,-60.27899 52.13501,-109.12498 116.46899,-109.12498z',
            `demersal` = 'path://m421.38,72.426c-46.56,-46.64 -108.52002,-72.356 -174.64401,-72.42c-135.93199,0 -246.61999,110.572 -246.73599,246.5c-0.064,65.916 25.548,127.90401 72.1,174.55998c46.568,46.62802 108.284,72.436 174.19601,72.436l0.57199,0l0,-0.02399c134.95601,0 246.53999,-110.59601 246.64,-246.51602c0.064,-65.91197 -25.58398,-127.89198 -72.12799,-174.53597zm-163.67999,304.7c-2.836,2.86401 -6.8,4.504 -10.87201,4.504c-4.088,-0.008 -8.064,-1.65601 -10.93199,-4.56c-2.84801,-2.82401 -4.48401,-6.79199 -4.48,-10.87601c0.008,-4.07199 1.664,-8.064 4.532,-10.92398c2.856,-2.84802 7.064,-4.48801 10.92,-4.48801c4.06,0 8.028,1.64801 10.85999,4.504c2.89603,2.92001 4.556,6.91599 4.548,10.93201c-0.004,4.03198 -1.672,8.00397 -4.57599,10.90799zm7.42398,-94.452c-1.76001,0.388 -3.01999,1.948 -3.02402,3.75198l-0.01999,18.12003c-0.008,8.48798 -6.916,15.40799 -15.43599,15.40799c-8.51201,-0.008 -15.412,-6.94 -15.40401,-15.436l0.036,-34.96399c0.00801,-8.48401 6.916,-15.08 15.416,-15.08l0.06801,0c29.48799,0 53.49998,-24.32001 53.532,-53.808c0.01199,-14.28801 -5.53601,-27.884 -15.64001,-38.024c-10.13998,-10.132 -23.56799,-15.78801 -37.88397,-15.804c-29.49202,0 -53.51201,23.95599 -53.54401,53.464c-0.008,8.49199 -6.924,15.38 -15.44,15.38c-4.12,0 -7.996,-1.62401 -10.89999,-4.54401c-2.916,-2.912 -4.508,-6.78799 -4.504,-10.90401c0.04399,-46.492 37.896,-84.32399 84.448,-84.32399c46.53198,0.048 84.34399,37.936 84.29999,84.46001c-0.03198,39.17198 -27.78,73.78796 -66.004,82.30399z',
            `unidentified` = 'path://m421.38,72.426c-46.56,-46.64 -108.52002,-72.356 -174.64401,-72.42c-135.93199,0 -246.61999,110.572 -246.73599,246.5c-0.064,65.916 25.548,127.90401 72.1,174.55998c46.568,46.62802 108.284,72.436 174.19601,72.436l0.57199,0l0,-0.02399c134.95601,0 246.53999,-110.59601 246.64,-246.51602c0.064,-65.91197 -25.58398,-127.89198 -72.12799,-174.53597zm-163.67999,304.7c-2.836,2.86401 -6.8,4.504 -10.87201,4.504c-4.088,-0.008 -8.064,-1.65601 -10.93199,-4.56c-2.84801,-2.82401 -4.48401,-6.79199 -4.48,-10.87601c0.008,-4.07199 1.664,-8.064 4.532,-10.92398c2.856,-2.84802 7.064,-4.48801 10.92,-4.48801c4.06,0 8.028,1.64801 10.85999,4.504c2.89603,2.92001 4.556,6.91599 4.548,10.93201c-0.004,4.03198 -1.672,8.00397 -4.57599,10.90799zm7.42398,-94.452c-1.76001,0.388 -3.01999,1.948 -3.02402,3.75198l-0.01999,18.12003c-0.008,8.48798 -6.916,15.40799 -15.43599,15.40799c-8.51201,-0.008 -15.412,-6.94 -15.40401,-15.436l0.036,-34.96399c0.00801,-8.48401 6.916,-15.08 15.416,-15.08l0.06801,0c29.48799,0 53.49998,-24.32001 53.532,-53.808c0.01199,-14.28801 -5.53601,-27.884 -15.64001,-38.024c-10.13998,-10.132 -23.56799,-15.78801 -37.88397,-15.804c-29.49202,0 -53.51201,23.95599 -53.54401,53.464c-0.008,8.49199 -6.924,15.38 -15.44,15.38c-4.12,0 -7.996,-1.62401 -10.89999,-4.54401c-2.916,-2.912 -4.508,-6.78799 -4.504,-10.90401c0.04399,-46.492 37.896,-84.32399 84.448,-84.32399c46.53198,0.048 84.34399,37.936 84.29999,84.46001c-0.03198,39.17198 -27.78,73.78796 -66.004,82.30399z'
          )

          #Create a new column 'classified_column' based on the mapping from the classification list
          class = classification_list[match(qw, names(classification_list))]

          class <- data.frame(class)
          class = class %>% gather('name', 'path', 1:length(data2$category))
          qw2 = class$path
          qw3 = data2$grp


        }
        if (input$ch1 == 'Migration Patterns') {
          #gpt3 classification
          classify_category <- function(text) {
            prompt <- paste(
              "Please classify the following as Migratory, Non-Migratory or Unidentified:\n\n",
              text,
              "\n\nCategory:"
            )
            response <- gpt3_single_completion(
              prompt_input = prompt,
              temperature = 0.9,
              max_tokens = 5,
              n = 1,
              model = "gpt-3.5-turbo-instruct"
            )
            category <- response[[1]]$gpt3
          }
          qw = sapply(data2$name, classify_category) %>% tolower()

          standardize_word <- function(word) {
            target_words <- c('migratory', 'non-migratory', 'unidentified')
            distances <- stringdistmatrix(word, target_words, method = 'jw')

            closest_match_index <- which.min(distances)
            closest_match_distance <- distances[closest_match_index]

            other_distances <- distances[-closest_match_index]
            if (closest_match_distance < 10 &&
                all(closest_match_distance < other_distances + 3)) {
              return(target_words[closest_match_index])
            } else {
              return(word)
            }
          }

          qw <- sapply(qw, standardize_word)

          classification_list <- list(
            `migratory` = 'path://m58.7766,224.431l12.8893,-7.85899l12.7605,8.12599l-2.3201,-16.95999l10.4565,-11.89401l-14.3072,-2.638l-6.3158,-15.47l-6.50909,15.37401l-14.3555,2.27499l10.2954,12.123l-2.594,16.923zm261.20341,25.144c-34.914,-71.76199 -32.41702,-156.7948 0.07999,-223.7769c-32.09399,-0.0574 -64.62399,9.3885 -94.431,29.8293c-64.22099,44.0365 -98.184,126.02861 -93.802,208.28859c15.226,0.59302 29.629,7.01801 41.23001,18.52902c10.972,-7.24701 23.12,-10.97601 35.784,-10.97601c33.722,0 62.884,26.94202 71.987,64.61099c23.78101,8.70102 40.55301,34.66702 40.55301,65.28101c0,31.97101 -18.64102,58.702 -43.66202,66.293c44.871,12.25702 93.59201,5.37402 136.62701,-24.09198c29.80701,-20.422 52.95898,-49.12302 68.974,-82.16501c-65.12302,-0.134 -128.42599,-40.078 -163.34,-111.82201zm-14.40402,151.74699c0,-25.94699 -16.77298,-47.01898 -38.08798,-49.371c-3.69,-34.763 -28.38901,-61.74298 -58.647,-61.74298c-14.468,0 -27.519,6.32898 -37.83,16.483c-9.683,-14.685 -24.58701,-24.30301 -41.504,-24.30301c-25.27901,0 -46.32121,21.052 -51.58971,49.142c-27.4866,2.27499 -49.2374,29.16 -49.2374,62.37302c0,34.64798 23.6842,62.73798 52.8947,62.73798c6.203,0 12.0999,-1.492 17.6263,-3.82498c9.6351,15.67999 25.1181,25.98599 42.7121,25.98599c10.763,0 20.752,-3.862 29.114,-10.42099c9.53801,10.97598 22.492,17.82098 36.847,17.82098c21.123,0 39.20001,-14.819 47.675,-36.082c2.59401,0.59302 5.252,0.995 8.007,0.995c23.20099,0.01901 42.01999,-22.29599 42.01999,-49.793zm115.311,-123.96298l7.54102,-19.69501l17.93198,-3.767l-13.43698,-14.62801l2.49701,-21.435l-15.83801,10.689l-16.38501,-9.446l3.65701,21.205l-12.63202,15.565l18.09402,2.44801l8.57098,19.064zm-69.345,-91.24701l5.88101,13.05901l5.172,-13.51801l12.293,-2.563l-9.216,-10.019l1.724,-14.685l-10.875,7.304l-11.246,-6.48201l2.513,14.55101l-8.668,10.651l12.422,1.702zm59.22702,-38.817l3.60898,8.03101l3.17401,-8.27901l7.556,-1.60699l-5.655,-6.157l1.03101,-8.987l-6.67001,4.513l-6.84698,-3.996l1.49799,8.91l-5.31699,6.53999l7.621,1.032zm-271.91701,-54.0177l3.60899,8.0307l3.174,-8.2984l7.556,-1.6062l-5.655,-6.157l1.047,-8.9871l-6.67,4.4935l-6.87999,-3.9772l1.53099,8.8914l-5.33299,6.5587l7.621,1.0516z',
            `non-migratory` = 'path://m426.62701,415.82101c0,0 -104.83502,-32.737 -163.07703,-32.737c-58.24098,0 -163.07599,32.737 -163.07599,32.737c0,0 34.94501,-109.12201 34.94501,-152.77103c0,-43.64899 -34.94501,-152.77099 -34.94501,-152.77099c0,0 104.83501,32.73701 163.07599,32.73701c58.242,0 163.07703,-32.73701 163.07703,-32.73701c0,0 -34.94501,109.122 -34.94501,152.77099c0,43.64902 34.94501,152.77103 34.94501,152.77103zm-163.09003,-360.11041c0,0 -55.63699,89.73239 -90.59399,122.4684c-34.95599,32.737 -130.71839,84.87498 -130.71839,84.87498c-0.0001,0 89.94939,46.68301 130.71839,84.875c40.76901,38.19302 90.59399,122.43802 90.59399,122.43802c0,0 55.68002,-89.70102 90.625,-122.43802c34.94501,-32.73599 130.71902,-84.875 130.71902,-84.875c0,0 -95.78601,-52.13799 -130.71902,-84.87498c-34.93298,-32.73601 -90.625,-122.4684 -90.625,-122.4684zm0,98.2184c64.33401,0 116.5,48.84599 116.5,109.12498c0,60.27902 -52.16599,109.125 -116.5,109.125c-64.33398,0 -116.46899,-48.84598 -116.46899,-109.125c0,-60.27899 52.13501,-109.12498 116.46899,-109.12498z',
            `unidentified` = 'path://m421.38,72.426c-46.56,-46.64 -108.52002,-72.356 -174.64401,-72.42c-135.93199,0 -246.61999,110.572 -246.73599,246.5c-0.064,65.916 25.548,127.90401 72.1,174.55998c46.568,46.62802 108.284,72.436 174.19601,72.436l0.57199,0l0,-0.02399c134.95601,0 246.53999,-110.59601 246.64,-246.51602c0.064,-65.91197 -25.58398,-127.89198 -72.12799,-174.53597zm-163.67999,304.7c-2.836,2.86401 -6.8,4.504 -10.87201,4.504c-4.088,-0.008 -8.064,-1.65601 -10.93199,-4.56c-2.84801,-2.82401 -4.48401,-6.79199 -4.48,-10.87601c0.008,-4.07199 1.664,-8.064 4.532,-10.92398c2.856,-2.84802 7.064,-4.48801 10.92,-4.48801c4.06,0 8.028,1.64801 10.85999,4.504c2.89603,2.92001 4.556,6.91599 4.548,10.93201c-0.004,4.03198 -1.672,8.00397 -4.57599,10.90799zm7.42398,-94.452c-1.76001,0.388 -3.01999,1.948 -3.02402,3.75198l-0.01999,18.12003c-0.008,8.48798 -6.916,15.40799 -15.43599,15.40799c-8.51201,-0.008 -15.412,-6.94 -15.40401,-15.436l0.036,-34.96399c0.00801,-8.48401 6.916,-15.08 15.416,-15.08l0.06801,0c29.48799,0 53.49998,-24.32001 53.532,-53.808c0.01199,-14.28801 -5.53601,-27.884 -15.64001,-38.024c-10.13998,-10.132 -23.56799,-15.78801 -37.88397,-15.804c-29.49202,0 -53.51201,23.95599 -53.54401,53.464c-0.008,8.49199 -6.924,15.38 -15.44,15.38c-4.12,0 -7.996,-1.62401 -10.89999,-4.54401c-2.916,-2.912 -4.508,-6.78799 -4.504,-10.90401c0.04399,-46.492 37.896,-84.32399 84.448,-84.32399c46.53198,0.048 84.34399,37.936 84.29999,84.46001c-0.03198,39.17198 -27.78,73.78796 -66.004,82.30399z'
          )

          #Create a new column 'classified_column' based on the mapping from the classification list
          class = classification_list[match(qw, names(classification_list))]

          class <- data.frame(class)
          class = class %>% gather('name', 'path', 1:length(data2$category))
          qw2 = class$path
          qw3 = data2$grp



        }

        if (input$ch1 == 'Conservation Status') {
          #gpt3 classification
          classify_category <- function(text) {
            prompt <- paste(
              "Please classify the following according to IUCN redlist as Extinct, Endangered, Vulnerable, Least Concern, or Not Evaluated:\n\n",
              text,
              "\n\nCategory:"
            )
            response <- gpt3_single_completion(
              prompt_input = prompt,
              temperature = 0.1,
              max_tokens = 3,
              n = 1,
              model = "gpt-3.5-turbo-instruct"
            )
            category <- response[[1]]$gpt3
          }
          qw = sapply(data2$name, classify_category) %>% tolower()


          standardize_word <- function(word) {
            target_words <- c('extinct',
                              'endangered',
                              'vulnerable',
                              'least concern',
                              'not evaluated')
            distances <- stringdistmatrix(word, target_words, method = 'jw')

            closest_match_index <- which.min(distances)
            closest_match_distance <- distances[closest_match_index]

            other_distances <- distances[-closest_match_index]
            if (closest_match_distance < 10 &&
                all(closest_match_distance < other_distances + 3)) {
              return(target_words[closest_match_index])
            } else {
              return(word)
            }
          }

          qw <- sapply(qw, standardize_word)


          classification_list <- list(
            `extinct` = 'path://m282.31201,93.7812c-10.91901,0.00011 -21.94501,2.5816 -33.12401,7.7808c-11.96001,5.46001 -17.562,11.177 -16.782,17.15701c0.51999,3.12 2.78299,5.471 6.81299,7.031c4.03,1.56 6.43901,2.981 7.21901,4.28101l63.187,105.31299l-66.313,116.59399c-1.039,1.55902 -3.245,3.242 -6.62399,5.06201c-3.38,1.82001 -5.586,4.02499 -6.62601,6.625c-0.77899,1.82001 -1.15599,3.534 -1.15599,5.09399c0,6.759 5.04799,12.47601 15.18799,17.15601c9.35901,4.67999 19.37201,7 30.03101,7c9.099,0 15.74701,-1.798 19.90601,-5.43701c3.12,-2.85999 4.16501,-6.37198 3.125,-10.53198c-1.04001,-5.71899 -0.77802,-10.16101 0.78198,-13.28101l44.43701,-82.65601l46.81299,72.125c0.77902,1.30002 1.15601,2.60602 1.15601,3.90601c0,1.56 -0.72699,3.76501 -2.15601,6.625c-1.42999,2.85999 -2.12598,5.211 -2.12598,7.03101c0.00098,2.60001 1.04599,5.18201 3.12598,7.78198c3.379,4.159 9.09601,7.93201 17.15601,11.31201c8.05902,3.38 16.09601,5.09399 24.15601,5.09399c20.01901,0 30.70001,-9.89798 32,-29.65601c0.26001,-4.41998 -1.94501,-7.93198 -6.625,-10.53198c-6.23999,-3.64001 -9.75101,-6.22101 -10.53101,-7.78101l-74.09399,-111.53101l50.68799,-94c1.039,-2.07999 4.66602,-4.43199 10.90601,-7.032c4.939,-2.33899 7.814,-6.604 8.59399,-12.84299c0.77902,-7.28 -3.25497,-13.519 -12.09399,-18.719c-8.06,-4.4197 -17.173,-6.625 -27.31299,-6.625c-8.57901,0 -14.93402,1.6827 -19.09302,5.063c-2.85999,2.599 -4.80399,6.487 -5.84399,11.687c-1.29999,6.5 -2.492,10.795 -3.53198,12.875l-31.96802,63.96899c-25.99899,-46.797 -39.784,-74.25299 -41.34399,-82.313c-1.04001,-5.979 -3.62201,-9.8674 -7.78101,-11.68719c-2.60001,-1.3 -5.99701,-1.93761 -10.15698,-1.93761zm-104.50002,0.375c-4.41899,0 -8.30699,0.8989 -11.687,2.7188c-4.94,2.5998 -7.929,4.053 -8.96899,4.313l-46.812,13.25c-3.12,-1.3 -6.37,-2.722 -9.75,-4.28201c-5.19991,-2.08 -9.4955,-3.00999 -12.8752,-2.75c-15.8591,2.34 -23.7813,7.304 -23.7813,14.844c0,2.34 0.8989,4.66 2.7187,7c-1.81979,76.955 -1.29729,149.509 1.56261,217.625c-2.8599,8.83899 -4.2813,13.51099 -4.2813,14.03101c0,1.82001 0.3763,3.242 1.1563,4.28198c11.1793,15.599 23.65829,25.35001 37.43719,29.25c1.3,0.26001 2.492,0.40601 3.531,0.40601c3.12,0 6.632,-1.56799 10.53201,-4.68799c5.199,-3.89999 8.56499,-6.25101 10.125,-7.03101l36.656,-16.375c14.039,0.78 24.052,-0.323 30.03101,-3.31201c5.98,-2.98999 8.96899,-7.60498 8.96899,-13.84399c0,-7.28 -3.888,-14.418 -11.687,-21.43799c-7.8,-7.01901 -15.34601,-10.79199 -22.62601,-11.31201c-6.759,-0.51999 -11.431,0.52499 -14.03099,3.125c-1.3,1.30002 -2.606,2.836 -3.90601,4.65601c-7.28,3.12 -16.39301,5.84799 -27.313,8.18701c-1.559,-5.979 -2.34299,-19.47202 -2.34299,-40.53101c8.579,-3.63901 15.86399,-6.77499 21.84299,-9.375c2.08,-0.78 6.89801,-0.89502 14.438,-0.375c7.53999,0.51999 13.256,0.259 17.15601,-0.78101c6.5,-1.82001 11.31799,-6.26199 14.43799,-13.28101c0.78,-1.82001 1.15601,-3.50299 1.15601,-5.06299c0,-6.23901 -4.991,-12.683 -15,-19.31201c-10.009,-6.62999 -18.804,-9.93799 -26.34399,-9.93799c-7.539,0 -12.849,2.467 -15.968,7.40599c-6.24001,1.04001 -10.159,1.97101 -11.719,2.75c-1.56001,-31.198 -1.56001,-59.03 0,-83.468c4.679,-3.37999 14.316,-7.52899 28.87499,-12.46899c5.979,-2.08 12.74101,-4.17 20.28101,-6.25c5.2,0.52 9.756,0.78101 13.65601,0.78101c9.36,0 17.021,-2.205 23,-6.625c2.86,-2.08 4.28099,-5.069 4.28099,-8.96901c0,-6.239 -2.785,-12.944 -8.37399,-20.09299c-5.59,-7.15 -11.25,-11.2416 -16.96901,-12.2815c-2.86,-0.52 -5.327,-0.7813 -7.407,-0.7813z',
            `endangered` = 'path://m399.90601,93c-5.979,0 -10.39001,1.2752 -13.25,3.875c-5.19901,4.68 -7.81201,8.599 -7.81201,11.719c0,1.56 0.89902,3.561 2.71802,6.031c1.81998,2.47 2.75,4.764 2.75,6.844l4.65698,171.59301c-49.397,-76.43501 -76.67599,-126.61201 -81.875,-150.53101c-0.25998,-0.52 -0.40601,-1.18901 -0.40601,-1.96901c-0.00098,-1.039 0.26102,-2.722 0.78101,-5.062c0.52002,-2.34 0.78101,-4.16901 0.78101,-5.46899c0,-3.38 -1.16,-6.22201 -3.5,-8.562c-8.319,-9.1 -22.22,-13.65701 -41.71899,-13.65701c-7.27901,0 -12.93901,1.103 -16.96901,3.313c-4.02899,2.21 -6.062,4.995 -6.062,8.375c0,1.3 0.261,3.129 0.78101,5.469c0.51999,2.34 0.78099,4.022 0.78099,5.062l11.71901,214.875c0.25999,2.34 -1.71501,5.00998 -5.875,8c-4.15901,2.98999 -5.84201,7.34299 -5.06201,13.06299c1.04001,7.01901 6.06201,13.14401 15.03101,18.34302c8.96899,5.19998 18.10901,7.78198 27.46899,7.78198c8.83902,0 15.48599,-2.46698 19.90601,-7.40601c3.12,-3.63998 4.68799,-7.52798 4.68799,-11.68799c0,-3.38 -1.30698,-7.56 -3.90698,-12.5c-2.60001,-4.94 -3.90601,-8.04401 -3.90601,-9.34399c-5.20001,-66.03601 -7.29001,-111.01901 -6.25,-134.93701c9.35901,20.27901 23.92899,45.383 43.68701,75.28101c8.06,12.479 16.91199,25.33499 26.53198,38.59399c2.08002,3.63901 3.35501,8.19601 3.875,13.65601c0.26001,6.23999 1.04401,10.79599 2.34302,13.65601c8.06,18.19901 23.15198,27.94998 45.25,29.25c8.84,0.51999 16.23999,-2.09302 22.21899,-7.81201c5.97998,-5.72 9.22998,-12.858 9.75,-21.43799c0.25998,-3.38 -1.48001,-7.61801 -5.25,-12.68701c-3.77002,-5.07001 -5.65601,-9.30798 -5.65601,-12.68799l-5.46899,-192.25c0,-2.60001 2.14798,-5.12401 6.43799,-7.593c4.29001,-2.47 6.29102,-6.04 6.03101,-10.719c-0.26001,-7.02 -5.45401,-13.521 -15.59399,-19.5c-10.13901,-5.9799 -20.005,-8.969 -29.625,-8.969zm-213.31201,1.1562c-4.42,0 -8.33899,0.8989 -11.71899,2.7188c-4.94,2.5998 -7.929,4.053 -8.96899,4.313l-46.78101,13.25c-3.12,-1.3 -6.37,-2.722 -9.75,-4.28201c-5.2,-2.08 -9.4952,-3.00999 -12.875,-2.75c-15.859,2.34 -23.7812,7.304 -23.7812,14.844c-0.00011,2.34 0.8988,4.66 2.7187,7c-1.8199,76.955 -1.2973,149.509 1.5625,217.625c-2.8598,8.83899 -4.2812,13.51099 -4.2812,14.03101c-0.00011,1.82001 0.3762,3.242 1.1562,4.28198c11.1793,15.599 23.6583,25.35001 37.437,29.25c1.3,0.26001 2.492,0.40601 3.53201,0.40601c3.12,0 6.6,-1.56799 10.5,-4.68799c5.199,-3.89999 8.596,-6.25101 10.156,-7.03101l36.65601,-16.375c14.039,0.78 24.05199,-0.323 30.032,-3.31201c5.979,-2.98999 8.968,-7.60498 8.968,-13.84399c0,-7.28 -3.888,-14.418 -11.68701,-21.43799c-7.79999,-7.01901 -15.34599,-10.79199 -22.625,-11.31201c-6.75999,-0.51999 -11.463,0.52499 -14.06299,3.125c-1.3,1.30002 -2.57501,2.836 -3.875,4.65601c-7.27901,3.12 -16.39301,5.84799 -27.31201,8.18701c-1.56,-5.979 -2.34399,-19.47202 -2.34399,-40.53101c8.57899,-3.63901 15.864,-6.77499 21.84399,-9.375c2.08,-0.78 6.89801,-0.89502 14.43701,-0.375c7.53999,0.51999 13.25699,0.259 17.157,-0.78101c6.49899,-1.82001 11.317,-6.26199 14.437,-13.28101c0.78,-1.82001 1.15601,-3.50299 1.15601,-5.06299c0,-6.23901 -4.99001,-12.683 -15,-19.31201c-10.009,-6.62999 -18.804,-9.93799 -26.343,-9.93799c-7.54001,0 -12.849,2.467 -15.96901,7.40599c-6.23999,1.04001 -10.159,1.97101 -11.71899,2.75c-1.56,-31.198 -1.56,-59.03 0,-83.468c4.67999,-3.37999 14.31599,-7.52899 28.875,-12.46899c5.98,-2.08 12.742,-4.17 20.28101,-6.25c5.2,0.52 9.72499,0.78101 13.625,0.78101c9.36,0 17.05199,-2.205 23.03099,-6.625c2.86,-2.08 4.282,-5.069 4.282,-8.96901c0,-6.239 -2.786,-12.944 -8.375,-20.09299c-5.59,-7.15 -11.24899,-11.2416 -16.96899,-12.2815c-2.86,-0.52 -5.326,-0.7813 -7.40601,-0.7813z',
            `vulnerable` = 'path://m209.21899,106.781c-6.75999,0 -12.50899,1.191 -17.18799,3.531c-7.28,4.42001 -10.90601,10.25301 -10.90601,17.53201c0,0.77999 0,2.143 0,4.094c0,1.95 0,3.57399 0,4.87399c0,2.85901 -0.261,5.32701 -0.78101,7.407l-39.782,140.40601l-28.062,-132.21899c-0.519,-2.34001 0.264,-5.50101 2.344,-9.53101c2.08,-4.03 3.094,-7.108 3.094,-9.187c-0.00101,-1.56 -0.262,-2.98201 -0.78201,-4.282c-1.82,-4.94 -6.695,-8.77 -14.625,-11.50001c-7.9292,-2.73 -16.69279,-4.094 -26.31219,-4.094c-22.09871,0 -33.1563,5.19501 -33.1563,15.59401c0,3.89999 2.5554,7.616 7.625,11.125c5.0697,3.50999 7.74,6.14899 8,7.96899l44.4375,200.06201c0.52,2.07999 0.259,4.547 -0.781,7.40698c-1.3,3.89999 -1.938,6.51199 -1.938,7.81201c0,8.57898 5.717,17.48999 17.156,26.71899c11.43901,9.23001 21.97501,13.84399 31.59401,13.84399c6.5,0 12.01399,-2.20599 16.56299,-6.625c4.55,-4.41998 6.81201,-10.138 6.81201,-17.15698c0,-2.34003 -0.31801,-5.59003 -0.96901,-9.75c-0.64999,-4.15802 -0.968,-7.03302 -0.968,-8.59302c0,-1.29999 0.14601,-2.345 0.40601,-3.125l63.15601,-206.68799c0.78,-2.34001 3.45,-4.748 8,-7.218c4.549,-2.47101 7.33499,-4.79001 8.375,-7c1.03999,-2.21001 1.56299,-4.358 1.56299,-6.438c0,-6.76 -4.55699,-12.622 -13.65599,-17.562c-9.10001,-4.941 -18.82001,-7.40701 -29.21901,-7.40701zm219.53101,0c-14.55899,0 -24.57101,3.511 -30.03101,10.531c-3.63998,4.68 -5.43799,9.091 -5.43799,13.25c0,3.901 2.20499,8.776 6.625,14.62601c4.41998,5.849 6.36398,10.34799 5.84399,13.468c0.51999,2.86 0.78101,7.532 0.78101,14.032c0,33.27699 -3.13501,69.554 -9.375,108.812c-7.79901,48.617 -17.51901,73.168 -29.21802,73.68799c-6.76099,0.26001 -12.884,-15.84598 -18.34399,-48.34399c-4.16,-24.95801 -7.526,-55.78 -10.125,-92.43799c-2.07999,-32.75801 -2.603,-50.692 -1.56299,-53.81201c-0.52002,-3.12 0.698,-6.89299 3.68799,-11.31299c2.98901,-4.42001 4.353,-8.57001 4.09399,-12.46901c-0.51999,-7.799 -5.453,-14.154 -14.81299,-19.09299c-8.05899,-4.16 -17.173,-6.25 -27.31299,-6.25c-8.319,0 -14.151,1.682 -17.53101,5.062c-5.20001,4.94 -7.81201,11.064 -7.81201,18.344c0,4.939 1.306,11.032 3.90601,18.313c-1.04001,9.618 -1.56299,24.30299 -1.56299,44.062c0.00098,53.55701 5.341,98.017 16,133.375c15.34,51.47699 40.81998,76.32001 76.43799,74.5c30.418,-1.29999 53.43201,-22.108 69.03101,-62.40601c11.17999,-29.11798 18.17099,-67.97699 21.03101,-116.59399c0.51999,-26.258 0.92798,-52.638 1.18799,-79.15601l4.68799,-12.5c-0.00098,-3.12 -1.453,-7.008 -4.31299,-11.688c-6.23999,-10.659 -18.19601,-16 -35.875,-16z',
            `least concern` = 'path://m118.344,94.5625c-10.14,0 -17.947,2.2053 -23.4065,6.6255c-3.8998,3.119 -5.8437,6.37 -5.8437,9.75c-0.00011,2.339 1.3639,5.182 4.0937,8.562c2.7298,3.38 4.0937,5.47 4.0937,6.25l16.3748,212.93799c0.26,2.599 -1.48,5.76102 -5.25,9.53101c-3.77,3.77002 -5.656,7.224 -5.656,10.34302c0,1.29999 0.261,2.86798 0.781,4.68799c2.86,8.05899 8.169,14.879 15.969,20.46899c7.8,5.58902 15.492,7.99802 23.03101,7.21899c12.22,-1.81998 20.77899,-5.07098 25.71899,-9.75c5.72,-6.23999 10.799,-9.95599 15.21899,-11.12598c4.41901,-1.16901 11.558,-1.75 21.43701,-1.75c9.87999,0.00098 17.483,-0.841 22.81299,-2.53101c5.32901,-1.69 10.03201,-5.259 14.06201,-10.71899c4.03,-5.45901 6.03099,-11.061 6.03099,-16.78101c0,-3.64001 -0.78299,-6.89001 -2.343,-9.75c-8.57999,-14.819 -17.547,-22.21899 -26.907,-22.21899c-3.379,0.00098 -7.61699,0.957 -12.687,2.90698c-5.07001,1.95001 -10.06,3.98199 -15,6.06201l-23.40601,8.56299l-14.03099,-193.81299c-0.26001,-1.82001 0.785,-3.76401 3.12399,-5.843c2.34,-2.08 3.5,-4.17101 3.5,-6.25c0.00101,-2.08 -0.63699,-4.401 -1.937,-7c-2.08,-4.42001 -7.10201,-8.25101 -15.03101,-11.5005c-7.92999,-3.2498 -16.171,-4.875 -24.74999,-4.875zm226.96801,3.5c-3.11902,0 -6.37003,0.115 -9.75,0.375c-23.138,2.3395 -41.48001,22.3645 -55,60.0625c-11.69901,32.23801 -17.41602,67.992 -17.15601,107.25c0.25998,34.83801 5.716,63.04599 16.375,84.625c13.77899,28.078 35.633,41.979 65.53101,41.71899c24.69897,-0.25998 49.396,-28.061 74.09399,-83.43799c7.28,-5.45901 10.90601,-11.95999 10.90601,-19.5c0,-9.099 -6.354,-14.81601 -19.09302,-17.15601c-4.16,-0.78 -8.341,-1.18799 -12.5,-1.18799c-18.71899,0.00098 -28.06299,6.909 -28.06299,20.68799c0,2.07999 0.26199,4.285 0.78198,6.625c-4.15997,14.039 -9.35498,26.25699 -15.59399,36.65601c-6.5,11.17999 -12.10199,16.37399 -16.78198,15.59399c-7.79901,-1.29999 -13.63101,-12.09601 -17.53101,-32.375c-3.38,-17.939 -4.686,-37.29501 -3.90601,-58.09399c1.04001,-27.558 3.883,-52.77701 8.56299,-75.65601c5.45901,-27.81799 11.845,-40.82001 19.12402,-39c4.67999,0.78 8.82898,5.771 12.46899,15c3.63998,9.229 5.72998,19.069 6.25,29.46899c-3.63901,8.319 -5.46899,12.845 -5.46899,13.625c0.00098,6.239 5.341,11.841 16,16.78101c9.09998,4.42 17.39798,6.625 24.93799,6.625c3.12,0 5.84799,-0.37601 8.18799,-1.15601c10.659,-4.15999 15.99902,-10.138 16,-17.93799c0,-2.60001 -2.20599,-9.623 -6.62598,-21.06201c-5.979,-28.599 -13.26401,-49.407 -21.84302,-62.40599c-11.69901,-17.41901 -28.328,-26.1255 -49.90698,-26.1255z',
            `not evaluated` = 'path://m227.53101,104.438c-5.979,-0.00101 -10.39,1.306 -13.25,3.906c-5.19901,4.679 -7.81201,8.567 -7.81201,11.687c0,1.56001 0.899,3.562 2.71901,6.031c1.819,2.47 2.75,4.76401 2.75,6.84401l4.687,171.59399c-49.397,-76.435 -76.707,-126.61301 -81.90601,-150.53101c-0.25999,-0.51999 -0.407,-1.189 -0.407,-1.96899c0,-1.03999 0.26201,-2.72301 0.782,-5.062c0.52,-2.34 0.78101,-4.16901 0.78101,-5.46901c0,-3.37999 -1.16,-6.22299 -3.5,-8.56299c-8.32,-9.09901 -22.22,-13.65601 -41.7188,-13.65601c-7.2795,0 -12.9389,1.103 -16.9687,3.312c-4.0298,2.21001 -6.0313,4.996 -6.0313,8.37601c0.00011,1.299 0.2301,3.12799 0.75,5.468c0.52,2.34 0.7813,4.02299 0.7813,5.06299l11.7187,214.875c0.26,2.34 -1.684,5.01001 -5.8437,8c-4.1597,2.99002 -5.8737,7.34302 -5.0937,13.06201c1.03989,7.01999 6.0617,13.14398 15.0312,18.34399c8.9695,5.20001 18.141,7.78101 27.5,7.78101c8.839,0 15.455,-2.466 19.875,-7.40601c3.12,-3.64001 4.687,-7.52802 4.687,-11.68701c0.00101,-3.37997 -1.306,-7.53 -3.90599,-12.46899c-2.60001,-4.94 -3.90601,-8.07498 -3.90601,-9.375c-5.2,-66.03598 -7.259,-111.019 -6.219,-134.93799c9.36001,20.27899 23.898,45.383 43.65701,75.28198c8.05899,12.479 16.911,25.33401 26.53099,38.59302c2.08,3.63998 3.386,8.19699 3.90601,13.65698c0.25999,6.23901 1.04401,10.79602 2.34399,13.65601c8.05901,18.19901 23.12001,27.95001 45.21901,29.25c8.83899,0.52002 16.239,-2.09299 22.218,-7.81299c5.97998,-5.71899 9.22998,-12.858 9.75,-21.43701c0.25998,-3.38 -1.48001,-7.61798 -5.25,-12.68799c-3.77002,-5.069 -5.65601,-9.276 -5.65601,-12.65601l-5.46899,-192.28101c0,-2.59999 2.14798,-5.12399 6.43799,-7.59399c4.289,-2.47 6.32199,-6.039 6.06201,-10.71899c-0.26001,-7.019 -5.48502,-13.52 -15.625,-19.50001c-10.13901,-5.979 -20.005,-8.96799 -29.625,-8.96799zm197.71899,1.156c-4.42001,0 -8.30801,0.93 -11.68799,2.75c-4.93903,2.6 -7.92801,4.021 -8.96802,4.281l-46.81299,13.25c-3.12,-1.3 -6.37,-2.721 -9.75,-4.281c-5.19901,-2.08 -9.495,-2.979 -12.875,-2.719c-15.85901,2.34 -23.78101,7.273 -23.78101,14.813c0,2.33899 0.89899,4.66 2.71899,7c-1.82001,76.955 -1.298,149.50899 1.56201,217.62401c-2.86002,8.84 -4.28101,13.51199 -4.28101,14.03198c0,1.82001 0.37601,3.241 1.15601,4.28101c11.17999,15.599 23.659,25.35001 37.43799,29.25c1.30002,0.26001 2.491,0.40601 3.53101,0.40601c3.12,0 6.63101,-1.56702 10.53101,-4.68701c5.19998,-3.89999 8.565,-6.25198 10.125,-7.03198l36.65601,-16.37402c14.03998,0.78 24.052,-0.323 30.03198,-3.31299c5.979,-2.98999 8.96802,-7.604 8.96802,-13.84399c0,-7.27899 -3.88702,-14.418 -11.68701,-21.43701c-7.79901,-7.01999 -15.345,-10.793 -22.625,-11.31299c-6.76001,-0.52002 -11.431,0.52499 -14.03101,3.125c-1.29999,1.29999 -2.60699,2.83701 -3.90698,4.65601c-7.27902,3.12 -16.39301,5.879 -27.31201,8.21899c-1.56,-5.979 -2.31201,-19.504 -2.31201,-40.56201c8.57901,-3.63998 15.832,-6.77499 21.81201,-9.375c2.07999,-0.78 6.89801,-0.89499 14.43799,-0.375c7.539,0.52002 13.25601,0.258 17.15601,-0.78101c6.49899,-1.81998 11.31702,-6.26199 14.43701,-13.28198c0.78,-1.82001 1.15698,-3.50201 1.15698,-5.06201c0,-6.23999 -4.991,-12.65201 -15,-19.282c-10.00998,-6.629 -18.77298,-9.968 -26.31299,-9.968c-7.539,0 -12.88,2.466 -16,7.40601c-6.23999,1.03999 -10.12799,1.97 -11.68701,2.75c-1.56,-31.198 -1.56,-59.03 0,-83.46899c4.67902,-3.38 14.284,-7.52901 28.84302,-12.46901c5.97998,-2.07899 12.742,-4.17 20.28101,-6.25c5.19998,0.52 9.75699,0.782 13.65698,0.782c9.35901,0 17.02002,-2.20599 23,-6.625c2.86002,-2.07999 4.28101,-5.069 4.28101,-8.96899c0,-6.24001 -2.785,-12.944 -8.375,-20.094c-5.59,-7.14899 -11.24899,-11.241 -16.96899,-12.281c-2.86002,-0.52 -5.32602,-0.781 -7.40601,-0.781z'

          )

          #Create a new column 'classified_column' based on the mapping from the classification list
          class = classification_list[match(qw, names(classification_list))]

          class <- data.frame(class)
          class = class %>% gather('name', 'path', 1:length(data2$category))
          qw2 = class$path
          qw3 = data2$grp



        }



      }






      table_data3_1 <- data.frame(
        name = data2$name,
        t_level = data2$t_level,
        value = data2$value,
        size = data2$size,
        grp = floor(data2$t_level),
        category = qw,
        symbol = qw2,
        symbol2 = qw3
      )


      table_data4_1 <- data.frame(from = data$from,
                                  to = data$to,
                                  weight = data$weight)
      table_data3(table_data3_1)
      table_data4(table_data4_1)


      output$editableTable3 <- renderRHandsontable({
        rhandsontable(table_data3(), rowHeaders = NULL) %>%
          hot_cols(width = c(100, 100, 0.1, 100, 0.1, 100, 0.1, 0.1)) %>%
          hot_cols(
            renderer = "
        function(instance, td, row, col, prop, value, cellProperties) {
          Handsontable.renderers.TextRenderer.apply(this, arguments);
          if (col === 6|| col === 7) { // Adjust the column index (zero-based) you want to change the font size
            td.style.fontSize = '0px'; // Set the desired font size
            td.style.textAlign = 'right'; // Center the content
          }
        }
      "
          )


      })

      output$editableTable4 <- renderRHandsontable({
        rhandsontable(
          table_data4(),
          stretchH = "all",
          rowHeaders = NULL,
          width = "100%",
          allowRowAdd = TRUE
        )
      })

      # Observe changes in the tables and update the reactive values





      output$my_chart <- renderEcharts4r({
        les <- list(nodes = table_data3(), edges = table_data4())



        les$nodes$size <- scales::rescale(les$nodes$size, to = c(10, 50))
        les$edges$weight <- scales::rescale(les$edges$weight, to = c(1, 6))


        if (input$ch3 == 'Icons') {
          a <- e_charts() |>
            e_graph(
              emphasis = list(focus = 'adjacency', label = list(show = TRUE)),
              roam = TRUE,
              zoom = input$ch20,
              left = '30%',
              right = '10%',
              lineStyle = list(color = "source", curveness = 0.3),
              draggable = FALSE
            ) |>
            e_graph_nodes(
              nodes = les$nodes,
              names = name,
              value = value,
              size = size,
              legend = TRUE,
              category = category,
              symbol = symbol
            ) |>
            e_graph_edges(
              edges = les$edges,
              source = from,
              target = to,
              value = weight,
              size = weight
            ) |>
            e_tooltip() |>
            e_theme(name = input$ch2) |>
            e_toolbox() |>
            e_toolbox_feature(feature = c("saveAsImage"))
        } else {
          if (input$ch3 == 'Emoji') {
            a <- e_charts() |>
              e_graph(
                emphasis = list(focus = 'adjacency', label = list(show = TRUE)),
                roam = TRUE,
                zoom = input$ch20,
                left = '30%',
                right = '10%',
                lineStyle = list(color = "source", curveness = 0.3),
                draggable = FALSE
              ) |>
              e_graph_nodes(
                nodes = les$nodes,
                names = name,
                value = value,
                size = size,
                legend = TRUE,
                category = category,
                symbol = symbol2
              ) |>
              e_graph_edges(
                edges = les$edges,
                source = from,
                target = to,
                value = weight,
                size = weight
              ) |>
              e_tooltip() |>
              e_theme(name = input$ch2) |>
              e_toolbox() |>
              e_toolbox_feature(feature = c("saveAsImage"))
          }
          if (input$ch3 != 'Icons' && input$ch3 != 'Emoji') {
            les$nodes$symbol = rep(input$ch3, length(les$nodes$category))

            a <- e_charts() |>
              e_graph(
                emphasis = list(focus = 'adjacency', label = list(show = TRUE)),
                roam = TRUE,
                left = '30%',
                right = '10%',
                zoom = input$ch20,
                lineStyle = list(color = "source", curveness = 0.3),
                draggable = FALSE,
                symbolSize = 20
              ) |>
              e_graph_nodes(
                nodes = les$nodes,
                names = name,
                value = value,
                size = size,
                legend = TRUE,
                category = category,
                symbol = symbol
              ) |>
              e_graph_edges(
                edges = les$edges,
                source = from,
                target = to,
                value = weight,
                size = weight
              ) |>
              e_tooltip() |>
              e_theme(name = input$ch2) |>
              e_toolbox() |>
              e_toolbox_feature(feature = c("saveAsImage"))
          }
        }

        for (i in 1:length(levels(as.factor(data2$name)))) {
          a$x$opts$series[[1]]$data[[i]]$y <- les$nodes$t_level[i] * -150
        }

        for (i in 1:length(levels(as.factor(data2$name)))) {
          pattern <- ((i - 1) %/% 10) * 50
          offset <- ((i - 1) %% 10) * 66
          a$x$opts$series[[1]]$data[[i]]$x <- pattern + offset
        }

        a$x$opts$series[[1]]$layout <- input$ch6
        a$x$opts$series[[1]]$draggable <- TRUE
        a$x$opts$series[[1]]$label <- list(
          show = TRUE,
          fontSize = input$fontsize,
          position = "bottom",
          borderColor = 'transparent',
          borderWidth = 0
        )
        a$x$opts$series[[1]]$itemStyle <- list(borderWidth = 1,
                                               borderColor = 'black')
        a$x$opts$legend <- list(show = TRUE)
        a$x$opts$itemStyle = list(borderColor = 'transparent', borderWidth =
                                    0)

        for (i in 1:length(les$nodes$grp)) {
          a$x$opts$series[[1]]$data[[i]]$symbolSize = as.numeric(a$x$opts$series[[1]]$data[[i]]$symbolSize) * input$ch4
        }

        # Return the chart using echartOutput
        a

      })
    }
    else {
      req(input$file1R, input$file2R)
      # Read data from uploaded files

      data <- read_csv(input$file2R$datapath)
      data2 <- read_csv(input$file1R$datapath)
      colnames(data2) <- str_to_title(colnames(data2))
      colnames(data) <- tolower(colnames(data))
      data2 <- data2 %>% select(
        'name' = 'Group_name',
        'value' = 'Biomass',
        'size' = 'Biomass',
        't_level' = 'Trophic_level'
      )
      data2$name = as.factor(data2$name)
      data2$value = as.numeric(data2$value)
      data2$size = as.numeric(data2$size)
      data2$t_level = as.numeric(data2$t_level)
      data2$grp <- floor(data2$t_level)
      data2$category <- rep('', length(data2$name))




      ############################################## parei aqui###################
      #falta agora trazer de volta os demais loops dos filtros e integrar eles com as tabelas



      if (input$ch1 == 'Trophic Position') {
        qw = data2$grp
        qw2 = data2$grp
        qw3 = data2$grp
        qw2_names = data2$grp
      } else {
        if (input$ch1 == 'Groups') {
          classify_category <- function(text) {
            prompt <- paste(
              "Please classify the following as one of the following categories:\n\n Bird, Detritus, Invertebrate, Mammal, Fish, Reptile, Primary producer, or Unidentified.\n\nHere is the text to classify:\n\n",
              text,
              "\n\nCategory:"
            )
            response <- gpt3_single_completion(
              prompt_input = prompt,
              temperature = 0.3,
              max_tokens = 3,
              n = 1,
              model = "gpt-3.5-turbo-instruct"
            )
            category <- response[[1]]$gpt3
          }

          qw = sapply(data2$name, classify_category) %>% tolower()

          standardize_word <- function(word) {
            target_words <- c(
              'bird',
              'detritus',
              'invertebrate',
              'mammal',
              'fish',
              'reptile',
              'primary producer',
              'unidentified'
            )
            distances <- stringdistmatrix(word, target_words, method = 'jw')

            closest_match_index <- which.min(distances)
            closest_match_distance <- distances[closest_match_index]

            other_distances <- distances[-closest_match_index]
            if (closest_match_distance < 10 &&
                all(closest_match_distance < other_distances + 3)) {
              return(target_words[closest_match_index])
            } else {
              return(word)
            }
          }

          qw <- sapply(qw, standardize_word)


          classification_list <- list(
            `mammal` = 'path://m439.56,144.813c-4.522,-39.83599 -45.271,-56.241 -45.271,-56.241s-11.198,32.337 -6.79001,63.26701c5.35101,37.51399 -41.853,77.83699 -141.994,77.83699c0,0 -192.82299,0 -231.951,0c-39.12,0 5.032,133.035 150.90901,138.85101c11.23599,0.44901 21.924,0.13699 32.155,-0.76199c18.55199,18.72699 46.42799,40.01898 86.75099,55.43399c15.27802,5.086 36.43298,-75.39301 -47.79102,-131.25302l2.634,-2.26898c28.08301,11.50998 47.63101,26.65198 60.86902,42.43198c51.55099,-34.32397 78.332,-82.633 90.68698,-98.26199c20.371,-25.77499 40.17001,-29.14799 70.172,-32.802c38.47202,-4.68799 52.06003,-32.80199 52.06003,-32.80199s-40.75,-25.77499 -72.44,-23.42999z',
            `fish` = 'path://m473.47198,266.47699l38.172,-98.60899c0.84399,-2.203 0.14102,-4.688 -1.71899,-6.10901c-1.875,-1.438 -4.453,-1.453 -6.34399,-0.063l-99.09402,73.09401c-21.32797,-2.51601 -44.39099,-53.46901 -145.92197,-78.75l29.672,-4.23401c4.73398,-0.672 8.89099,-3.43799 11.35898,-7.547c2.453,-4.09399 2.922,-9.078 1.297,-13.563l-14.922,-41.03099c-1.828,-5.01601 -6.047,-8.78101 -11.23398,-10.01601s-10.64102,0.219 -14.53101,3.875l-67.922,63.938c-109.89,2.40501 -192.281,90.85802 -192.281,119.015c3.734,23.60901 48.891,77.875 117.25,104.25c7.141,-9.96899 12.906,-19.59399 17.516,-28.76599c13.453,-26.828 17.23401,-49.875 17.23401,-65.73401c0,-6.39099 -0.625,-11.60901 -1.42201,-15.26599c-1.28099,-6.04701 2.563,-11.98401 8.60901,-13.26601c6.047,-1.297 11.98399,2.563 13.28099,8.59401c1.15601,5.453 1.89101,12.10898 1.89101,19.93799c0,19.34399 -4.578,45.81299 -19.60899,75.76599c-4.21901,8.422 -9.313,17.125 -15.328,26.01602c23.5,6.40598 49.203,9.297 76.48399,6.70297l20.25,39.453c2.047,4 5.688,6.93802 10.03101,8.09402c4.34399,1.14099 8.96899,0.40598 12.75,-2.06302l15.453,-10.10901c4.26599,-2.78098 6.90601,-7.422 7.172,-12.48398c0.23401,-5.06302 -1.93799,-9.953 -5.89099,-13.14102l-20.70302,-16.672c104.59401,-24.93799 127.95302,-77.078 149.51601,-79.625l99.09402,73.09402c1.89099,1.39099 4.46899,1.375 6.34399,-0.04703c1.85898,-1.422 2.56302,-3.922 1.71899,-6.10898l-38.17203,-98.62601zm-397.04698,7.46802c-9.26601,0 -16.781,-7.53101 -16.781,-16.78101c0,-9.26599 7.516,-16.78099 16.781,-16.78099s16.781,7.51601 16.781,16.78099c0,9.25 -7.516,16.78101 -16.781,16.78101z',
            `primary producer` = 'path://m176.692,9.90914c-0.87,0.86836 -3.327,-0.0956 -4.576,0.40346c-2.81999,1.1269 -5.842,1.8909 -8.265,4.3034c-20.717,20.623 -41.459,41.2699 -62.139,61.9286c-3.0002,2.9966 -3.9965,7.6413 -4.5023,11.431c-0.0134,0.1008 -0.1204,0.2555 -0.22141,0.2689c-1.3557,0.1806 -2.9412,0.0434 -4.2065,0.6052c-2.4825,1.1021 -5.276,2.0682 -7.4537,4.2361c-20.6083,20.5152 -41.1976,41.04221 -61.7701,61.59219c-2.2604,2.25801 -3.7738,5.73901 -4.1328,8.60701c-0.1319,1.05499 -0.4115,2.89 -0.6642,3.89999c-0.2363,0.94501 0.191,1.918 0.2214,2.89101c0.1537,4.914 3.2081,9.625 6.9372,12.978c0.0496,-0.03999 0.0981,0.03 0.1476,0c6.4839,6.297 19.171,6.55499 25.7559,0c20.7163,-20.623 41.4586,-41.27 62.1389,-61.929c2.07301,-2.07 2.481,-4.607 3.543,-6.993c0.131,-0.29601 0.635,-0.916 0.664,-1.21001c0.123,-1.271 -0.678,-3.60699 0.59,-3.766c1.036,-0.129 2.134,0.098 3.174,0c0.293,-0.027 0.884,-0.545 1.18,-0.672c2.552,-1.093 4.988,-1.601 7.159,-3.766c20.554,-20.4966 41.086,-40.9426 61.62199,-61.4575c4.86101,-4.8555 6.382,-14.7692 3.543,-20.4411c-0.88699,-1.7725 -1.53299,-4.4598 -3.321,-5.7155c-2.914,-3.3266 -6.255,-5.373 -10.11099,-6.6568c-1.597,-0.53202 -3.90901,0.3973 -5.313,-0.53796zm31.069,3.89996c-0.51801,0.518 -0.04001,2.073 0.44299,2.5551c0.59401,-0.5393 0.58701,-0.5364 1.181,-1.0758c-0.81,-0.7552 -0.814,-0.7241 -1.62399,-1.4793zm169.59099,32.8134c-0.06598,-0.0933 -0.11899,-0.0515 -0.36899,0.269c-3.02399,3.873 -9.27301,5.6305 -11.36499,9.9516c-1.98001,4.0902 -0.08902,8.8709 0,13.3137c0.00299,0.1385 0.81699,-0.2187 1.328,-0.3362c-0.51602,0.18629 -1.11301,0.3808 -1.328,0.5379c-3.617,2.6444 -5.68402,4.5582 -6.93701,8.40511c-1.36801,4.1998 0.77399,8.4589 3.98499,11.4981c-0.31699,-0.3409 -0.62997,-0.6944 -0.88599,-0.94131c-0.49301,0.43291 -1.34601,-0.6554 -1.845,-0.8742c-1.21301,-0.5321 -3.10199,-1.4683 -4.42801,-1.6137c-5.552,-0.60889 -9.94699,0.65411 -13.79999,4.0344c-3.28201,2.8788 -4.74899,8.2416 -3.39499,12.1031c0.34698,0.99 1.077,2.506 1.91898,3.429c0.26801,0.294 0.81201,0.498 0.81201,0.875c0,0.095 -0.08801,0.122 -0.14801,0.201c0.20001,0.176 0.38901,0.362 0.591,0.538c-2.646,-2.051 -5.42599,-2.995 -10.03699,-3.295c-7.96402,0.499 -13.34702,5.38499 -13.948,12.238c-0.15201,1.732 0.00998,4.018 1.03299,5.514c0.733,1.072 1.496,2.102 2.435,3.093c-0.12,-0.11301 -0.24799,-0.222 -0.36899,-0.33601c-0.09,0.079 -0.05701,0.122 -0.147,0.202c-1.733,-0.76 -3.16699,-2.015 -5.01901,-2.421c-5.72198,-1.255 -10.884,0.435 -14.83298,3.89999c-1.06702,0.936 -1.51401,2.143 -2.28802,3.16c-0.54099,0.71201 -1.09598,1.92001 -1.25497,2.757c-0.43503,2.293 -0.36301,5.334 0.81198,7.397c0.32602,0.57201 2.10501,2.868 1.771,3.16c0.14502,0.127 0.517,0.407 0.88602,0.672c-3.617,-2.745 -7.92502,-3.875 -12.767,-3.026c-1.30402,0.229 -2.67902,0.509 -3.76401,1.144c-1.521,0.88901 -2.845,1.83101 -4.207,3.02501c-0.70499,0.61899 -1.08899,1.38399 -1.69699,1.95c-0.02502,-0.017 -0.039,-0.06601 -0.07401,-0.067c-5.03302,-0.13 -10.09302,-0.026 -15.129,0c-0.06702,0 -0.10001,0.026 -0.147,0.067c-3.694,3.21399 -7.377,6.46899 -11.07001,9.683c-0.048,0.04199 -0.129,0.00999 -0.14799,0.067c-0.138,0.425 -0.09601,0.46199 0.14799,0.673c2.472,2.142 4.87799,4.271 7.38,6.38799c0.043,0.03601 0.17801,0.037 0.22101,0c2.71298,-2.32799 5.34598,-4.71999 8.04398,-7.06099c0.048,-0.041 0.08002,-0.06601 0.14801,-0.067c3.05099,-0.026 6.17401,0.049 9.22501,0c0.29999,0.388 0.306,0.711 0.59,1.20999c0.69299,1.21701 1.367,2.61601 2.509,3.63101c4.267,3.79599 8.56,7.58099 12.841,11.364c4.14899,3.666 8.30899,7.308 12.47299,10.95999c1.35602,1.19 3.702,2.52701 5.534,2.757c0.25101,0.032 0.439,0.276 0.66501,0.40401c-0.05899,2.72299 1.31201,5.66699 0,8.136c-1.62201,3.05099 -5.508,4.78799 -8.19202,7.19398c-0.04199,0.03801 -0.04199,0.097 0,0.13501c2.41202,2.168 4.95203,4.3 7.38,6.455c0.30099,0.267 0.05402,0.373 0.73801,0.202c0.065,-0.017 0.026,-0.093 0.07401,-0.13499c3.724,-3.293 9.14401,-5.617 11.21701,-9.884c1.974,-4.064 0.14697,-8.83101 0,-13.24701c-0.00201,-0.05199 -0.104,-0.013 -0.147,-0.06699c1.564,-1.35501 3.58499,-2.49901 4.944,-4.16901c3.72498,-4.57401 2.76498,-10.79001 -1.03302,-14.927c0.117,0.11501 0.25101,0.22101 0.36902,0.336c0.46298,-0.40599 2.853,1.20401 3.69,1.479c2.07098,0.68199 4.61499,0.89099 6.93698,0.74001c5.16501,-0.33601 9.51001,-3.69601 11.73401,-7.59801c1.11401,-1.95399 1.10699,-4.791 1.10699,-6.79199c0,-2.02 -1.40201,-4.62701 -3.026,-6.05101c0.20901,-0.183 0.21802,-0.117 0.36902,-0.202c1.76199,1.28101 3.89297,2.312 6.12598,2.42101c0.72302,0.03499 1.539,0.323 2.14001,-0.067c-0.091,0.07899 -0.13101,0.12199 -0.22202,0.20099c0.38501,0.33701 1.617,0.19501 1.99301,-0.13399c-0.09,-0.08 -0.05701,-0.05501 -0.14801,-0.13501c0.061,-0.05299 0.14801,-0.05899 0.14801,-0.134c0.436,0.664 2.43799,0.242 3.173,0c3.022,-0.99399 5.612,-2.76399 7.67599,-5.17799c2.53601,-2.966 2.944,-7.955 1.62299,-11.431c-0.46698,-1.23 -1.491,-2.162 -2.435,-3.16c0.25803,-0.226 0.14102,-0.103 0.36902,-0.403c5.289,4.63901 15.87399,3.095 20.147,-2.15199c0.539,-0.662 1.582,-1.548 1.845,-2.354c0.16299,-0.499 0.56998,-1.031 0.73798,-1.546c1.349,-4.14201 0.53302,-8.19901 -2.28799,-11.498c0.14502,-0.127 0.19702,-0.183 0.29501,-0.269c0.267,0.182 0.48199,0.445 0.73801,0.605c4.96899,3.113 12.24799,2.254 16.89999,-0.807c1.53598,-1.01 2.37799,-2.945 3.69,-3.765c0.03299,0.044 0.017,0.133 0.07401,0.134c5.064,0.104 10.13699,0.026 15.20297,0c0.06702,0 0.173,-0.02499 0.22101,-0.06699c3.694,-3.214 7.30301,-6.469 10.996,-9.6828c0.048,-0.0416 0.203,-0.07761 0.22202,-0.13451c0.138,-0.42419 0.022,-0.394 -0.22202,-0.60509c-2.47198,-2.1428 -4.948,-4.3126 -7.60098,-6.4551c-2.71402,2.3805 -5.36002,4.8535 -8.11801,7.1947c-0.065,0.0552 -0.20502,-0.0008 -0.29501,0c-2.86499,0.0257 -5.69598,0.0412 -8.56097,0.0673c-0.12003,0.0011 -0.26501,-0.0545 -0.36902,0c-0.715,0.3764 -0.02301,1.3395 0,1.7485c0.035,0.627 0.008,1.254 0,1.882c-0.05399,-3.3802 -0.91501,-6.6101 -3.69,-9.077c-4.20801,-3.7413 -8.47198,-7.4325 -12.69299,-11.162c-0.03201,0.02821 -0.052,0.04111 -0.07401,0.06731c-4.138,-3.7835 -8.40799,-7.44141 -12.62,-11.162c-1.625,-1.4359 -3.599,-2.573 -5.608,-2.8913c0.08801,-2.67039 -1.29901,-5.585 0,-8.0017c1.63501,-3.0454 5.508,-4.721 8.19101,-7.1275c0.151,-0.1352 -0.22702,-0.4118 -0.29501,-0.4707c-2.35098,-2.037 -4.74799,-4.0688 -7.08499,-6.1189c-0.211,-0.185 -0.229,-0.3773 -0.29501,-0.4707zm-188.77899,109.8045c-0.668,-0.08 -1.213,-0.03799 -1.476,0.47c0.326,0.315 0.66701,0.367 1.034,0.47099c-3.01799,0.56401 -6.211,1.42 -7.45399,2.62201c0.084,0.16199 0.13699,0.174 0.22099,0.33699c-1.123,-0.85199 -3.996,0.43001 -5.092,1.27701c-1.79199,1.386 -4.866,1.8 -6.86301,2.959c-1.90999,1.10699 -4.21899,3.38499 -6.347,3.89999c-2.14,0.517 -5.33299,3.66701 -7.01099,5.177c-1.12801,1.01601 -2.25601,2.088 -3.395,3.093c-7.248,6.39799 -11.715,14.59599 -14.612,22.99699c-0.39801,1.155 -1.222,2.901 -1.328,4.03401c-0.355,3.76799 -0.29601,7.57999 -0.29601,11.364c0,3.55099 1.08101,8.409 2.51001,11.63199c0.38199,0.862 1.209,2.229 1.328,3.093c0.93799,6.80301 1.41399,13.608 0,20.442c-0.34901,1.686 -0.09401,3.817 -0.81201,5.379c-1.509,3.282 -1.883,8.032 -4.20599,11.02699c-2.095,2.70001 -2.633,6.517 -4.724,9.21201c-1.157,1.49301 -1.79401,3.586 -2.509,5.31201c-3.403,8.22598 -6.436,15.84399 -6.715,25.01401c-0.099,3.224 -0.626,7.41498 0.221,10.69098c1.913,7.39902 4.2,15.853 9.37201,21.853c7.92799,9.19601 17.12399,18.36401 17.786,30.52701c0.84,15.431 -6.959,27.24301 -11.07001,41.15201c-0.403,1.36499 -0.832,4.246 -0.88499,5.51401c-0.108,2.53699 -0.108,5.06 0,7.59799c0.006,0.15201 0.343,0.185 0.369,0.336c0.36099,2.095 -0.02501,4.362 0.51599,6.45499c2.295,8.875 5.85301,17.23502 11.218,25.01401c0.034,-0.02899 0.041,-0.10501 0.07401,-0.13501c0.565,1.02802 5.037,6.74902 5.534,7.26202c-6.52,0.11697 -13.035,0.134 -19.556,0.13498c-4.91901,0 -9.844,0.16 -14.76,0c-0.16499,-0.00598 -0.195,-0.189 -0.295,-0.33701c0.038,-0.05899 0.11,-0.08099 0.147,-0.13397c1.136,-1.647 3.122,-8.414 3.174,-10.22101c0.108,-3.78101 0.16,-7.58401 0,-11.36301c-0.045,-1.05701 -0.879,-2.867 -1.181,-4.035c-0.914,-3.53299 -1.99,-7.69901 -4.354,-10.55701c-3.045,-3.67899 -5.961,-7.603 -8.045,-11.63199c-0.834,-1.61301 -1.954,-3.13699 -2.361,-4.909c-0.359,-1.56201 -0.007,-3.39902 -0.29501,-4.97601c-0.16,-0.87698 -0.841,0.35901 -0.369,-1.008c1.069,-3.10098 0.825,-6.48401 2.066,-9.68298c5.09299,-13.12802 10.759,-28.39502 0.44299,-41.21802c-5.266,-6.54599 -12.3087,-10.229 -20.295,-11.633c-4.3168,-0.759 -9.2678,-0.59201 -13.3577,-2.28601c-4.9809,-2.064 -9.4058,-4.573 -13.579,-8.60699c-5.2144,-5.04099 -6.8571,-12.10098 -10.4057,-17.819c-2.763,-4.452 -7.4212,-7.92499 -11.4389,-11.16199c-1.5394,-1.23999 -3.7465,-3.297 -5.6826,-3.76501c-0.8945,-0.216 -1.7008,-1.14499 -2.5092,-1.61398c-1.667,-0.96701 -3.5378,-1.47601 -5.1659,-2.42102c-0.3896,-0.22598 -2.1388,-1.53497 -2.583,-1.27698c-2.4486,-2.142 -6.5017,-1.75 -9.0035,-3.564c-0.4682,-0.33902 -3.1351,-1.29102 -3.3948,-0.53802c-0.218,0.63202 2.509,3.06403 2.8782,3.56403c2.2093,2.98999 4.391,6.849 5.3873,10.21997c0.5578,1.888 1.3383,4.45602 1.476,6.18701c0.1118,1.40399 -0.6617,3.23901 0.369,4.23599c-0.5803,1.83301 -0.1035,4.11801 0,6.11902c0.131,2.53198 0.4149,6.17599 1.476,8.741c0.8669,2.095 0.7599,4.54199 1.6974,6.65698c3.0871,6.96301 7.1191,12.88 13.0625,18.625c7.9415,7.67801 18.5186,10.44601 26.3463,18.35703c6.8354,6.90799 4.1083,18.715 1.9926,26.896c-0.5237,2.02499 -0.9536,3.811 -1.3284,5.98499c-0.0556,0.32199 -0.6412,0.78702 -0.6642,1.008c-0.3561,3.44302 -0.3689,6.896 -0.369,10.35501c0,1.46799 0.4993,3.85999 1.1808,5.17801c1.1737,2.26898 2.6737,4.40598 3.8376,6.65698c0.8365,1.617 2.6826,2.888 4.2066,4.034c7.12431,5.35703 16.31651,5.603 23.68961,10.35501c3.0919,1.99301 6.596,5.237 8.339,8.60699c0.674,1.302 1.603,3.077 2.657,4.23599c-0.075,0.08701 -0.06499,0.25702 -0.14799,0.336c1.311,2.53403 1.238,5.81201 2.50999,8.27103c-15.1823,0.53098 -30.4164,0.284 -45.6084,0.336c-6.1662,0.022 -13.8257,6.90399 -14.3908,12.642c-0.1167,1.18399 -0.1066,2.37399 -0.1476,3.56299c-0.1062,3.07901 -0.1656,6.13199 -0.2214,9.21201c102.7862,0.08099 102.8182,0.05399 205.6052,0.13501c0.06401,-3.54501 0.382,-8.21902 0,-12.104c-0.222,-2.25302 -1.366,-4.18002 -2.657,-6.05099c-6.45799,-9.36603 -14.959,-7.733 -26.19901,-7.733c-11.793,0 -23.556,0.18799 -35.34999,0.13498c-0.158,-0.00098 -0.257,-0.228 -0.369,-0.33701c0.679,-0.86099 2.98199,-6.694 3.543,-7.59799c4.8,-7.73401 11.104,-15.987 19.409,-20.57599c7.024,-3.88 15.091,-6.59201 22.804,-9.077c4.42101,-1.42502 9.52,-2.85901 13.431,-5.379c3.17101,-2.04401 6.84001,-3.63901 9.89,-5.85001c17.29901,-12.543 32.74701,-30.811 33.578,-51.70801c0.01501,-0.36301 0.65701,-0.84399 0.664,-1.07599c0.26001,-7.771 -0.70401,-14.13501 -2.509,-21.11401c-0.38501,-1.48898 -0.30899,-3.30798 -1.03299,-4.707c-1.86099,-3.59799 -1.66501,-7.897 -3.32101,-11.63199c-0.776,-1.75 -0.651,-3.63699 -1.181,-5.51401c-0.21698,-0.76901 -0.573,0.198 -0.664,-0.80701c-0.40601,-4.51801 -0.603,-8.827 -0.51599,-13.64999c0.01999,-1.15698 0.48499,-3.168 0.95898,-4.23599c0.32501,-0.733 0.09601,-1.89801 0.36902,-2.689c1.27499,-3.698 1.746,-7.85602 3.026,-11.56601c0.38,-1.103 0.20401,-3.36099 0.29498,-4.37c0.72501,-8.05801 -0.04398,-16.69601 -2.65698,-24.27402c-1.02499,-2.97198 -2.02002,-9.37399 -4.354,-11.83499c-2.19299,-4.23999 -4.948,-8.879 -8.561,-12.37199c-0.53299,-0.51601 -3.33899,-3.87201 -4.354,-2.89101c0.42502,0.82001 0.336,3.06201 0.36902,3.429c0.05499,0.61 0.62598,1.621 0.664,2.084c0.31799,3.84401 0.25198,7.647 0.664,11.49901c0.02197,0.19699 0.10599,0.54399 0.14798,0.806c-0.23801,0.759 -0.46799,1.724 -0.517,2.287c-0.10199,1.185 -0.04498,2.377 -0.147,3.56299c-0.034,0.39401 -0.603,0.64601 -0.664,0.942c-1.05698,5.10899 -3.035,10.321 -6.716,14.59102c-4.836,5.60999 -10.59198,10.37 -15.79298,15.39798c-6.007,5.80701 -13.241,10.48102 -17.71201,17.68399c-2.35699,3.79703 -4.619,7.04102 -5.38699,11.49902c-0.01601,0.091 -0.66301,1.42798 -0.66501,1.479c-0.10699,3.02399 -0.15799,6.05499 0,9.077c0.05901,1.112 0.903,4.267 1.476,5.51398c3.10101,6.74301 7.96501,13.31403 10.11101,20.57602c0.461,1.55899 1.674,3.16599 1.993,4.707c1.147,5.54498 0.218,11.276 -1.55,16.40601c-2.37199,6.87997 -7.638,13.16299 -12.54599,18.96198c-9.15401,10.81601 -20.99001,21.17401 -28.339,33.01501c-2.658,4.28299 -5.745,8.10001 -7.38,12.84299c-0.411,1.19101 -1.403,2.77301 -1.10699,4.16901c-0.058,-0.186 -0.125,-0.36899 -0.369,-0.60498c-0.93199,0.901 -0.839,2.81 -1.40199,3.89999c-1.90201,3.67798 -2.412,8.97 -2.509,13.112c-0.043,1.81699 -0.312,4.26898 0.22099,6.186c-5.754,0.10898 -13.03,0.33099 -18.819,0.13498c-0.123,-0.005 -0.14499,-0.16098 -0.22099,-0.26898c0.013,-0.03 0.064,-0.03799 0.07401,-0.06802c0.86699,-2.79498 -0.14801,-5.823 -0.14801,-8.741c0,-6.01797 1.207,-11.681 2.509,-17.34799c0.22,-0.957 -0.067,-1.92801 0.295,-2.89099c2.034,-5.40601 3.35201,-12.47101 6.716,-17.34799c5.215,-7.56201 10.452,-15.453 15.793,-23.19901c1.601,-2.32101 4.166,-6.01401 4.871,-8.741c0.16299,-0.629 0.439,-1.88 0.812,-2.42001c1.881,-2.728 2.23801,-6.14099 3.321,-9.28c8.202,-23.78699 -9.58699,-37.81299 -12.694,-58.83499c-1.19299,-8.07602 0.826,-16.48901 5.314,-22.99701c3.46101,-5.01901 7.48601,-10.28299 9.74101,-15.73401c0.53099,-1.28299 0.521,-2.71399 1.03299,-4.034c0.43201,-1.112 1.15001,-3.28699 1.181,-4.371c0.25101,-8.84698 -0.22299,-20.28099 -5.38699,-27.76999c-5.744,-8.32899 -12.435,-15.937 -15.27701,-25.552c-2.207,-7.46899 -2.47899,-16.89 -1.32799,-24.677c0.23099,-1.563 0.87999,-3.554 1.03299,-5.17799c0.162,-1.72501 2.82901,-8.87201 2.436,-10.22c0.033,-0.03801 0.03999,-0.097 0.073,-0.13501c0.168,0.08101 0.12801,0.054 0.29601,0.13501c1.44899,-1.40201 1.82899,-3.82401 2.87799,-5.51401c2.15701,-3.476 4.30301,-7.026 6.19901,-10.69099c-0.64,-0.04401 -1.972,0.26801 -3.026,0.403c0.27299,-0.142 0.561,-0.161 0.812,-0.403c-0.58699,-0.02901 -1.325,-0.257 -1.993,-0.336zm301.02802,73.29199c-0.07101,0.033 0.04398,0.14301 0,0.20201c-2.07901,2.77199 -4.22702,5.521 -6.34702,8.26999c-0.04498,0.058 -0.07001,0.12001 -0.147,0.13501c-15.56198,2.948 -31.15298,5.86 -46.715,8.808c-2.16199,0.41 -5.17801,1.394 -6.79001,2.69c-6.285,5.052 -9.198,9.83099 -7.74899,17.21298c0.371,1.888 0.68301,3.83801 1.10699,5.716c0.04102,0.18201 0.02802,0.38602 0.14801,0.53799c0.02798,0.035 0.427,0.09302 0.51599,0.134c-4.79999,-1.22198 -10.702,-0.45599 -15.42398,0.80701c-1.73401,0.46402 -7.01901,1.784 -8.11801,3.228c-0.30099,-0.172 -0.23999,-0.005 -0.29501,-0.26898c-0.38998,-1.884 -0.68298,-3.83801 -1.10699,-5.716c-0.203,-0.89999 -0.61301,-2.56302 -1.181,-3.42902c-0.92398,-1.40799 -1.78299,-3.11899 -3.099,-4.371c-4.522,-4.29898 -11.34198,-6.44 -17.78598,-5.24399c-15.61002,2.89499 -31.17203,5.80899 -46.789,8.67401c-1.621,0.297 -9.53702,-6.49402 -10.332,-5.51401c-2.311,2.849 -4.37601,5.82199 -6.56802,8.741c-0.15799,0.211 -0.53098,0.603 -0.29498,0.73999c4.681,2.72101 9.34601,5.439 14.09601,8.069c0.08899,0.04901 0.18997,-0.048 0.29498,-0.06699c17.38699,-3.228 34.78299,-6.48502 52.17599,-9.68301c1.927,-0.354 5.34302,1.11301 5.978,2.689c0.18402,0.45801 0.414,1.052 0.51602,1.48001c1.18399,4.923 2.38898,9.85001 3.46899,14.793c0.08701,0.397 -0.96899,2.16901 -1.181,2.55499c-0.043,0.07901 -0.04901,0.25 -0.147,0.26901c-9.147,1.77701 -18.29999,3.36301 -27.45401,5.10999c-0.078,0.01501 -0.177,0.07703 -0.22098,0.13501c-4.19202,5.47299 -8.32202,10.97699 -12.47202,16.474c-0.125,0.16501 -0.11301,0.42999 0.07401,0.53799c3.36099,1.94202 6.72101,3.87601 10.10999,5.78201c0.06601,0.03699 0.21902,0.04999 0.29501,0.06699c3.20499,-4.21399 6.409,-8.474 9.668,-12.64099c0.08301,-0.10599 0.22601,-0.10599 0.36899,-0.134c5.83801,-1.15698 11.70602,-2.36301 17.56403,-3.42999c0.099,-0.01801 0.15997,0.06699 0.22198,0.13501c0.17499,0.19498 0.23999,0.495 0.29501,0.73999c2.29099,10.14499 4.45898,20.30798 6.71597,30.45999c1.56201,7.03 3.17502,14.02701 4.79703,21.04602c0.58899,2.55298 3.66098,5.93698 6.56799,6.85797c1.16901,0.371 2.569,0.95401 3.83701,1.07602c0.28198,0.02701 1.39499,-0.37799 1.54999,0.06799c1.20999,3.47202 2.94501,6.91602 6.125,9.27899c0.73901,0.54901 1.61401,0.87201 2.362,1.41202c0.96899,0.69998 0.45499,5.181 1.62399,6.65698c0.59802,0.75601 2.07901,2.23602 2.28702,3.16c0.07898,0.349 -0.33902,0.88101 -0.44202,1.20999c-0.336,1.06403 -0.31198,2.63101 -0.29599,3.63101c0.02798,1.755 0.74399,4.71301 2.06699,6.186c0.44702,0.49799 1.34201,1.15799 1.62302,1.74899c0.27399,0.57501 -0.366,1.02402 -0.44299,1.54599c-0.17502,1.194 -0.31302,2.46701 -0.29501,3.63101c0.06601,4.09201 2.328,6.19202 4.797,8.94299c-0.60699,0.79901 -3.64398,1.10101 -4.64899,1.61401c-2.31,1.17999 -4.70602,2.69699 -6.79001,4.30301c-4.58701,3.53598 -8.23801,10.97198 -8.33899,16.07098c-0.01202,0.59201 0.017,1.17001 0.14798,1.74802c0.03601,0.15997 0.11102,0.31097 0.147,0.47098c-0.117,0.85901 0.14401,2.69202 0.29501,3.362c0.42899,-0.03299 0.45798,-0.035 0.88599,-0.06699c3.98401,-0.68399 7.91101,-1.47501 11.88202,-2.21899c-0.69101,-4.319 0.51797,-8.73203 4.72299,-11.633c0.70099,-0.48401 1.22501,-1.17401 1.992,-1.479c2.56299,-1.02002 4.90799,-1.60703 8.04498,-2.08502c0.099,-0.01498 0.27402,0.04901 0.29501,0.13501c0.944,3.86301 1.707,7.75601 2.58301,11.63199c6.38397,-1.14899 6.383,-1.13599 12.767,-2.28598c-0.84702,-3.91299 -1.73001,-7.84201 -2.509,-11.767c-0.017,-0.086 0.04999,-0.18002 0.147,-0.202c1.69299,-0.37701 3.37399,-0.67902 5.09299,-0.94101c0.746,-0.11401 2.612,-0.159 3.54199,0c6.22202,1.06299 9.84399,4.29099 11.36502,9.48099c6.38397,-1.14899 6.383,-1.13699 12.767,-2.28598c-1.12003,-7.17401 -8.27402,-14.95801 -16.38303,-17.21402c-1.32098,-0.367 -2.991,-0.48798 -4.28,-0.87399c-1.94699,-0.582 -3.58798,-0.28699 -5.60898,-0.40298c-0.405,-0.02402 -2.57202,-0.26001 -3.10001,0.13397c-1.133,0.84601 -1.733,2.22101 -2.65701,3.22803c-0.495,0.53998 -1.15198,0.85699 -1.771,1.20999c3.67102,-3.061 6.259,-6.565 5.60901,-11.16202c-0.245,-1.73499 -0.64801,-3.15399 -1.255,-4.707c-0.27301,-0.69998 -2.36301,-2.547 -2.36099,-3.09299c0.00299,-0.75101 0.504,-1.61099 0.664,-2.353c0.366,-1.69601 -0.01801,-3.88901 -0.517,-5.51401c-0.46201,-1.50699 -1.29102,-2.72299 -2.06601,-4.034c-0.202,-0.34201 -1.06,-0.68298 -1.03299,-1.14401c0.09799,-1.66699 0.80499,-3.396 0.81198,-5.10999c0.00702,-1.724 -1.03299,-3.20401 -1.40298,-4.841c-0.08099,-0.35999 1.896,-2.86801 2.21399,-3.698c0.87701,-2.28299 1.99402,-7.19501 0.73801,-9.48099c3.74899,-1.36801 7.27701,-5.53 7.74899,-8.742c0.14001,-0.952 0.14099,-1.854 -0.073,-2.82401c-1.526,-6.91101 -3.05099,-13.79901 -4.57599,-20.70999c-0.013,-0.06 -0.06,-0.14102 -0.07401,-0.202c-2.147,-9.509 -4.245,-18.99301 -6.642,-28.64401c-0.02301,0.004 -0.05002,-0.005 -0.07401,0c0.70599,-0.60101 -1.06799,-2.76801 -0.147,-2.95901c3.155,-0.65298 6.27701,-1.22098 9.44601,-1.81497c2.647,-0.496 5.31699,-1.013 7.97098,-1.48001c5.582,-0.98001 9.40601,8.276 14.90701,8.20401c0.07901,-0.00101 0.177,-0.07703 0.22101,-0.13501c2.28799,-2.97 4.543,-5.94901 6.78998,-8.94299c0.065,-0.086 0.11301,-0.405 0,-0.47c-6.20798,-3.61801 -12.46698,-7.16501 -18.745,-10.69202c-0.05899,-0.03299 -0.15198,-0.01199 -0.22098,0c-9.16702,1.68701 -18.34802,3.48401 -27.52802,5.11099c-0.133,0.02301 -0.306,-0.267 -0.36899,-0.336c-0.673,-0.75 -1.53702,-1.258 -2.36102,-1.81598c0.08401,-0.11002 0.24701,-0.207 0.22101,-0.336c-0.99799,-4.89401 -2.215,-9.77002 -3.24701,-14.659c-0.39297,-1.86002 1.04401,-4.38901 2.95203,-5.44601c0.31,-0.172 1.40698,-0.564 1.62399,-0.60501c17.22598,-3.29199 34.49899,-6.42099 51.733,-9.68298c0.85199,-0.16101 4.117,-5.06 4.871,-6.052c1.35699,-1.785 2.77499,-3.526 4.13199,-5.312c0.211,-0.27701 0.77399,-0.92101 0.88599,-1.27701c0.082,-0.261 -0.41599,-0.41299 -0.517,-0.47099c-3.21597,-1.858 -6.46597,-3.70401 -9.66699,-5.58101c-0.34601,-0.203 0.08099,-0.47899 -0.81198,-0.067z',
            `bird` = 'path://m438.16,457.97501c-10.96201,-0.40601 -20.79001,-5.285 -27.59399,-13.823c-2.26801,-2.84601 -5.29202,-4.47202 -8.694,-4.47202c-3.40201,0 -6.42599,1.62601 -8.694,4.47202c-6.80502,8.944 -17.38901,13.823 -28.729,13.823c-3.02402,0 -5.67001,-0.40601 -8.31601,-0.81302l-65.77301,-97.983c-7.18198,-10.56998 -17.00998,-17.48199 -28.34998,-20.32797l0,-44.72202l26.45999,0c32.508,0 62.74899,-19.922 77.491,-50.821c27.97299,-15.45 47.25101,-47.162 47.25101,-83.34599c0,-6.912 -4.914,-12.19701 -11.34,-12.19701l-37.80099,0l-102.061,0l0,-69.1166c0,-29.2728 -21.925,-52.8537 -49.14101,-52.8537c-27.21701,0 -49.14101,23.5809 -49.14101,52.8537l0,8.1313l-45.361,0c-6.42599,0 -11.34,5.2854 -11.34,12.197l0,4.0653c0,6.912 4.914,12.197 11.34,12.197c3.402,0 6.426,-1.626 8.316,-4.06499l37.045,0l0,89.44399c0,47.569 32.886,86.59901 75.601,92.69801l0,45.12799c-11.34,2.84601 -21.54599,10.16501 -28.34999,20.32901l-66.151,98.38898c-1.89,0.40701 -3.78,0.40701 -5.67,0.40701c-11.341,0 -21.925,-4.879 -28.729,-13.82401c-2.268,-2.84601 -5.292,-4.47198 -8.694,-4.47198c-3.4021,0 -6.4261,1.62598 -8.6941,4.47198c-6.8041,8.94501 -17.3883,13.82401 -28.7285,13.82401c-11.3402,0 -21.9243,-4.879 -28.7284,-13.82401c-4.1581,-5.285 -11.3402,-5.69199 -15.8763,-1.21899c-4.9141,4.47198 -5.2921,12.19699 -1.134,17.07501c11.3402,14.22998 27.9724,22.362 46.1167,22.362c13.9862,0 26.8384,-4.879 37.4226,-13.41702c10.584,8.944 23.436,13.41702 37.423,13.41702c13.98601,0 26.838,-4.879 37.422,-13.41702c10.58401,8.944 23.43701,13.41702 37.423,13.41702c13.608,0 26.838,-4.879 37.04401,-13.41702c10.58501,8.944 23.81499,14.23001 37.80101,14.23001c0.37799,0 0.37799,0 0.75598,0c13.98599,0 27.59399,-5.28601 38.17902,-14.23001c0,0 0.37799,0 0.37799,0.40601c0.37799,0.40701 0.75601,0.40701 1.134,0.814c1.134,0.81302 2.646,2.03201 3.78,2.845c0.37799,0.40701 1.134,0.814 1.51199,1.22c1.134,0.81302 2.646,1.62601 3.78,2.03302c0.37799,0.40698 1.134,0.40698 1.51199,0.81299c1.89001,0.81299 3.40201,1.62601 5.29202,2.44c0.37799,0 0.75598,0 0.75598,0.40601c1.51199,0.40698 3.02402,0.81299 4.914,1.22c0.75601,0 1.134,0.40598 1.89001,0.40598c1.51199,0.40701 2.646,0.40701 4.15799,0.81403c0.75601,0 1.134,0 1.89001,0.40598c1.88998,0.40701 4.15799,0.40701 6.04797,0.40701c13.98602,0 26.83902,-4.879 37.423,-13.41699c10.20602,8.53799 22.68002,13.41699 35.91,13.41699l0.37799,0c6.048,0 11.34003,-5.28601 11.34003,-11.79102c-0.75601,-7.31799 -5.67001,-13.00998 -12.09601,-13.00998zm-74.08899,-285.81601l0,0l0,28.459c0,5.692 -0.37802,10.978 -1.51202,16.263c-10.20599,7.72501 -22.67999,12.19701 -36.28799,12.19701c-31.75299,0 -57.83499,-24.80101 -63.12698,-56.91901l100.927,0zm-177.66301,28.459l0,-121.9696c0,-15.8561 11.71899,-28.4597 26.461,-28.4597c14.74199,0 26.45999,12.6036 26.45999,28.4597l0,93.5106c0,51.634 38.93501,93.51001 86.942,93.51001c1.134,0 2.26801,-12.19701 3.78,-12.19701c-11.341,10.16399 -26.08301,16.26299 -41.58099,16.26299l-37.80099,0c-35.53201,0 -64.261,-31.30598 -64.261,-69.11699zm102.43999,258.17c-10.96201,0 -21.54599,-5.285 -28.35098,-13.823l-0.75601,-0.81299c-2.26801,-2.84601 -5.29199,-4.47202 -8.694,-4.47202l0,0c-3.40199,0 -6.42599,1.62601 -8.694,4.47202c-6.804,8.53799 -17.388,13.823 -28.34999,13.823c-11.34001,0 -21.925,-4.879 -28.729,-13.823c-0.756,-0.81302 -1.134,-1.22 -1.89,-2.03302l45.739,-67.897c3.78,-5.69199 9.07201,-9.75699 15.12,-11.78998c0,0 0,0 0.37801,0c7.938,-2.03302 15.87601,2.84601 18.901,10.97699l30.996,84.97299c-1.51199,0 -3.02402,0.40601 -4.53601,0.40601c-1.134,0 -1.134,0 -1.134,0z',
            `reptile` = 'path://m399.78601,82.5471c-40.26001,26.6179 -32.591,77.63589 -57.51401,110.90889c-53.681,77.63602 -155.289,117.56302 -258.8152,128.65399c-21.0886,2.21802 -47.9287,19.96402 -57.5144,44.36401c19.1715,-6.655 49.8458,-2.21899 65.183,8.87201c0,13.30899 -38.3429,26.61798 -21.0886,51.01801c13.42001,8.87299 32.5912,8.87299 51.76321,2.21799c17.254,-13.30899 19.17099,-22.181 26.84,-39.927c82.437,19.96399 139.951,-2.21799 139.951,-2.21799c0,0 5.75198,26.61798 23.00598,39.927c19.17203,11.09097 44.095,8.87299 61.34903,0c17.254,-19.96301 -21.08902,-31.05402 -21.08902,-70.98102c0,-59.89099 15.33801,-102.036 57.51501,-146.39999c13.41998,26.618 51.763,22.18199 67.09998,-2.218c5.75101,-11.091 9.58603,-22.18201 9.58603,-35.491c0,-79.8542 -61.349,-104.2542 -86.272,-88.7269zm47.92899,77.63589c-7.66901,0 -13.41998,-6.65399 -13.41998,-15.52699c0,-8.873 5.75098,-15.52701 13.41998,-15.52701c7.668,0 13.42001,6.65401 13.42001,15.52701c0,8.873 -5.75201,15.52699 -13.42001,15.52699zm-159.12399,-2.218c-15.33701,-33.27299 -57.51401,-77.63609 -147.62001,-48.8c-99.69139,35.491 -97.77429,128.654 -82.43709,150.83601c0,0 -23.0058,11.091 -9.5857,33.27298c11.5028,15.52701 72.8518,4.436 126.5318,-15.52698c53.68001,-17.746 99.69099,-46.58202 124.614,-68.76401c23.00601,-19.964 13.42001,-55.45399 -11.50299,-51.01801z',
            `detritus` = 'path://m421.38,72.426c-46.56,-46.64 -108.52002,-72.356 -174.64401,-72.42c-135.93199,0 -246.61999,110.572 -246.73599,246.5c-0.064,65.916 25.548,127.90401 72.1,174.55998c46.568,46.62802 108.284,72.436 174.19601,72.436l0.57199,0l0,-0.02399c134.95601,0 246.53999,-110.59601 246.64,-246.51602c0.064,-65.91197 -25.58398,-127.89198 -72.12799,-174.53597zm-163.67999,304.7c-2.836,2.86401 -6.8,4.504 -10.87201,4.504c-4.088,-0.008 -8.064,-1.65601 -10.93199,-4.56c-2.84801,-2.82401 -4.48401,-6.79199 -4.48,-10.87601c0.008,-4.07199 1.664,-8.064 4.532,-10.92398c2.856,-2.84802 7.064,-4.48801 10.92,-4.48801c4.06,0 8.028,1.64801 10.85999,4.504c2.89603,2.92001 4.556,6.91599 4.548,10.93201c-0.004,4.03198 -1.672,8.00397 -4.57599,10.90799zm7.42398,-94.452c-1.76001,0.388 -3.01999,1.948 -3.02402,3.75198l-0.01999,18.12003c-0.008,8.48798 -6.916,15.40799 -15.43599,15.40799c-8.51201,-0.008 -15.412,-6.94 -15.40401,-15.436l0.036,-34.96399c0.00801,-8.48401 6.916,-15.08 15.416,-15.08l0.06801,0c29.48799,0 53.49998,-24.32001 53.532,-53.808c0.01199,-14.28801 -5.53601,-27.884 -15.64001,-38.024c-10.13998,-10.132 -23.56799,-15.78801 -37.88397,-15.804c-29.49202,0 -53.51201,23.95599 -53.54401,53.464c-0.008,8.49199 -6.924,15.38 -15.44,15.38c-4.12,0 -7.996,-1.62401 -10.89999,-4.54401c-2.916,-2.912 -4.508,-6.78799 -4.504,-10.90401c0.04399,-46.492 37.896,-84.32399 84.448,-84.32399c46.53198,0.048 84.34399,37.936 84.29999,84.46001c-0.03198,39.17198 -27.78,73.78796 -66.004,82.30399z',
            `unidentified` = 'path://m421.38,72.426c-46.56,-46.64 -108.52002,-72.356 -174.64401,-72.42c-135.93199,0 -246.61999,110.572 -246.73599,246.5c-0.064,65.916 25.548,127.90401 72.1,174.55998c46.568,46.62802 108.284,72.436 174.19601,72.436l0.57199,0l0,-0.02399c134.95601,0 246.53999,-110.59601 246.64,-246.51602c0.064,-65.91197 -25.58398,-127.89198 -72.12799,-174.53597zm-163.67999,304.7c-2.836,2.86401 -6.8,4.504 -10.87201,4.504c-4.088,-0.008 -8.064,-1.65601 -10.93199,-4.56c-2.84801,-2.82401 -4.48401,-6.79199 -4.48,-10.87601c0.008,-4.07199 1.664,-8.064 4.532,-10.92398c2.856,-2.84802 7.064,-4.48801 10.92,-4.48801c4.06,0 8.028,1.64801 10.85999,4.504c2.89603,2.92001 4.556,6.91599 4.548,10.93201c-0.004,4.03198 -1.672,8.00397 -4.57599,10.90799zm7.42398,-94.452c-1.76001,0.388 -3.01999,1.948 -3.02402,3.75198l-0.01999,18.12003c-0.008,8.48798 -6.916,15.40799 -15.43599,15.40799c-8.51201,-0.008 -15.412,-6.94 -15.40401,-15.436l0.036,-34.96399c0.00801,-8.48401 6.916,-15.08 15.416,-15.08l0.06801,0c29.48799,0 53.49998,-24.32001 53.532,-53.808c0.01199,-14.28801 -5.53601,-27.884 -15.64001,-38.024c-10.13998,-10.132 -23.56799,-15.78801 -37.88397,-15.804c-29.49202,0 -53.51201,23.95599 -53.54401,53.464c-0.008,8.49199 -6.924,15.38 -15.44,15.38c-4.12,0 -7.996,-1.62401 -10.89999,-4.54401c-2.916,-2.912 -4.508,-6.78799 -4.504,-10.90401c0.04399,-46.492 37.896,-84.32399 84.448,-84.32399c46.53198,0.048 84.34399,37.936 84.29999,84.46001c-0.03198,39.17198 -27.78,73.78796 -66.004,82.30399z',
            `invertebrate` = 'path://m76.6852,324.99301c0,-102.28601 54.3028,-144.78801 78.6318,-144.78801c13.90199,0 17.92799,94.744 177.425,94.744c34.42499,0 53.12399,-18.94901 58.47101,-18.94901c5.77197,0 15.72699,19.59299 15.72699,62.45499c0,115.19 -148.61499,120.32501 -172.09401,120.57101c-49.03499,0.53101 -47.85599,44.35999 -76.17899,44.35999c-14.53101,0 -81.9818,-74.33698 -81.9818,-158.39297zm110.0848,-163.73701c0,11.123 37.649,75.795 131.45699,75.795c36.89401,0 88.71301,-24.93599 88.71301,-59.53699c0,-15.67101 -3.38199,-25.73201 -7.974,-25.73201c-3.271,0 -20.177,9.474 -41.832,9.474c-67.35599,0 -71.93301,-56.84599 -76.00601,-56.84599c-38.78099,0 -94.35799,45.72299 -94.35799,56.84599zm220.17,-113.69279c0,-7.8448 -4.45099,-18.9488 -15.72699,-18.9488c-11.276,0 -14.24802,19.6878 -19.61102,27.4c-8.052,-1.6486 -16.76398,3.6571 -20.41299,12.4683c-0.534,1.3075 -1.022,2.72861 -2.013,3.5624c-1.336,1.118 -3.11301,0.7769 -4.733,0.56841c-11.52798,-1.4401 -31.862,7.5038 -31.862,12.8473c0,5.3436 1.62,37.8972 59.17902,37.8972c13.634,0 35.17999,-5.229 35.17999,-13.832c0,-4.794 0,-54.118 0,-61.9628z'
          )

          #Create a new column 'classified_column' based on the mapping from the classification list
          class = classification_list[match(qw, names(classification_list))]

          class <- data.frame(class)
          class = class %>% gather('name', 'path', 1:length(data2$category))
          qw2 = class$path


          # emojis
          classification_list2 <- list(
            `mammal` =  'path://m115.089,80.352c-19.93079,-0.4459 -42.68719,8.2031 -42.68719,20.219c0,21.361 35.9702,10.67 47.9692,32.03101c0.268,0.478 0.544,0.72 0.812,1.125c2.614,23.23399 11.959,52.28099 23.188,52.28099c11.233,0 20.60899,-29.073 23.218,-52.312c0.25999,-0.394 0.521,-0.631 0.782,-1.09399c11.998,-21.36101 48,-10.67001 48,-32.03101c0,-21.3614 -72,-32.042 -72,0c0,-14.0185 -13.78,-19.8722 -29.28201,-20.219zm360.93801,34.40601c-8.43701,0.501 -28.69101,20.521 -55.68802,28.531c-35.995,10.681 -83.96698,-21.361 -71.96799,0c11.064,19.69901 32.36801,48.42101 73.25,52.782c-3.27301,19.08 2.28201,42.03799 -25.28201,64.718c-24.09299,19.83398 -36.25198,13.96799 -95.96799,-21.40601c-35.996,-21.31799 -84.009,-42.687 -156,-42.687c-86.1498,0 -95.9692,52.61501 -95.9692,117.50002c0,28.41699 1.8916,54.46298 11.25,74.78098c0.0355,0.077 0.0893,0.142 0.125,0.21902c1.3751,2.961 2.9128,5.79498 4.625,8.5c0.6395,1.01099 1.40369,1.93298 2.0937,2.90598c1.2682,1.78802 2.553,3.564 4,5.21902c0.8195,0.93698 1.7453,1.79398 2.625,2.68698c1.4597,1.48199 2.9609,2.927 4.5938,4.28101c1.09019,0.905 2.26649,1.74799 3.4375,2.59399c1.7047,1.23199 3.492,2.397 5.375,3.5c1.2331,0.72299 2.4998,1.42801 3.8125,2.09399c2.0739,1.052 4.28239,2.00101 6.5625,2.90601c1.4617,0.58002 2.9191,1.17001 4.4692,1.68802c2.388,0.79797 4.958,1.47897 7.562,2.125c1.626,0.40198 3.193,0.84598 4.906,1.18698c3.011,0.60101 6.273,1.03201 9.563,1.43802c1.618,0.19897 3.125,0.474 4.812,0.625c5.08499,0.45499 10.41299,0.71799 16.157,0.71799c35.647,0.00101 127.55099,-0.31201 156,-0.31201c23.99701,0 62.888,-7.09998 95.96799,-31.71899c3.83301,-2.85199 7.38702,-5.92801 10.81302,-9.09399c1.272,-1.16501 2.49799,-2.358 3.71899,-3.56201c1.802,-1.798 3.53299,-3.65198 5.21799,-5.53098c22.86301,-25.108 35.854,-57.039 40.28201,-88.625c-0.02899,0.06299 -0.06601,0.12399 -0.09399,0.18698c6.84198,-39.457 2.97998,-77.679 -4.625,-99.937c29.62,-12.205 28.68698,-53.05499 28.68698,-71.125c0,-5.341 -1.5,-7.355 -4.31198,-7.188zm-374.90601,184.87499c9.118,0 16.5,7.802 16.5,17.43802c0,9.63599 -7.382,17.43698 -16.5,17.43698c-9.1191,0 -16.5317,-7.80099 -16.5317,-17.43698c0,-9.63602 7.4125,-17.43802 16.5317,-17.43802z',
            # Whale emoji: 🐋
            `fish` = 'path://m205.188,80.7812c-16.78,0.00011 -33.24001,30.4448 -36.84401,64.40681c-73.35699,19.08099 -110.96899,81.035 -111.09399,129.812c3.2441,3.03201 11.5988,8.65201 21.6875,15.18799c27.0765,17.539 68.1205,42.75803 67.59351,50.46802c-0.72301,10.58301 -28.394,-1.121 -38.687,-3.56201c-13.1782,-3.11301 -19.5259,-5.58798 -24.0002,-6.46899c-1.8088,-0.35599 -3.397,-0.51501 -4.875,-0.25c-10.4677,4.103 -6.9193,15.35199 -3.0313,21.78101c18.6673,33.35901 90.79449,59.59399 151.53149,59.59399c7.91901,0 15.81601,-0.73801 23.68701,-1.78101c19.91,12.02402 45.789,21.25 71.81299,21.25c22.51501,0 4.733,-18.909 -9.375,-39.31299c26.276,-11.57901 50.367,-27.004 70.125,-43.375c24.564,37.49298 63.78302,66.25 91.09302,66.25c18.97897,0 37.948,-17.92801 18.96899,-37.40601c-18.979,-19.453 -37.96899,-70.25 -37.96899,-95.81299c0,-12.78101 18.978,-79.40901 37.96899,-98.87401c18.96698,-19.466 0.00998,-40.46901 -18.96899,-40.46901c-25.48203,0 -61.345,31.856 -86,68.343c-3.70502,-3.093 -7.504,-6.166 -11.53101,-9.218c-35.54901,-74.81599 -123.078,-120.56269 -172.093,-120.5628zm-62.813,111.3128c13.757,0 24.938,11.42601 24.937,25.56201c0,14.123 -11.17999,25.56299 -24.937,25.56299c-13.77,0 -24.937,-11.452 -24.937,-25.56299c0,-14.136 11.16699,-25.56201 24.937,-25.56201z',
            # Fish emoji: 🐟
            `primary producer` = 'path://m159.25,40.6562c-24.94501,21.2956 -35.47,49.4967 -34.125,77.1558c0.126,2.633 0.598,5.228 0.937,7.844c0.26,1.989 0.339,3.99599 0.719,5.969c0.868,4.50999 2.04501,8.996 3.531,13.375c1.424,4.198 3.076,8.019 4.907,11.625c0.063,0.12399 0.09201,0.282 0.15601,0.40601c0.02699,0.05299 0.06599,0.10399 0.09399,0.157c0.931,1.797 1.92601,3.545 2.96901,5.218c0.043,0.071 0.08,0.14899 0.12399,0.21899c1.035,1.647 2.134,3.241 3.282,4.78101c2.071,2.78099 4.442,5.31499 6.90601,7.81299c0.392,0.39801 0.69099,0.858 1.09399,1.25c1.748,1.701 3.80101,3.26801 5.75,4.875c1.39801,1.15201 2.651,2.38301 4.15601,3.5c1.40199,1.039 3.065,2.01401 4.562,3.03101c2.30901,1.56799 4.55,3.179 7.09401,4.71899c2.69499,1.62901 5.74599,3.272 8.71899,4.90601c1.41,0.77499 2.651,1.562 4.125,2.34399c5.771,3.061 13.097,6.52701 19.90601,9.84401c4.381,2.133 7.946,4.026 12.782,6.343l0,-0.03101c0.383,0.18401 0.644,0.315 1.03099,0.5c-28.61899,25.597 -51.97299,49.418 -71,71.375c3.01901,-29.38699 3.09801,-46.612 -13.25,-64.53101c-18.298,-20.05299 -47.74369,-31.87599 -79.18779,-25.43799c-0.247,0.49699 -0.3609,1.002 -0.5937,1.5c-0.0053,-0.00401 -0.0259,0.00499 -0.0313,0c-0.1405,0.30099 -0.2083,0.605 -0.3437,0.90599c-1.3185,2.93201 -2.4697,5.858 -3.3125,8.813c-0.0777,0.271 -0.1136,0.541 -0.1875,0.813c-0.8244,3.04399 -1.4639,6.086 -1.8125,9.12399c-0.0024,0.021 0.0024,0.04201 0,0.063c-1.1121,9.782 0.1117,19.466 3.3438,28.53101c0.2314,0.653 0.5922,1.25999 0.8437,1.90599c0.9142,2.338 1.8339,4.66501 3,6.907c0.6007,1.159 1.366,2.245 2.0313,3.375c1.0156,1.72101 1.9671,3.478 3.125,5.125c1.8886,2.69 3.9429,5.25601 6.1874,7.71899c9.15591,10.026 18.8129,15.50201 31.25,18.90601c3.1098,0.85101 6.38181,1.55301 9.8748,2.18701c8.62,1.565 19.165,2.59 30.87501,3.65698c-58.5201,70.431 -72.36211,120.69302 -76.93721,147.53101c-1.2299,7.18802 9.3944,16.25702 17.375,17.375c7.99419,1.08099 24.28719,-4.84299 25.5312,-12.03198c2.92,-17.18402 10.168,-47.13202 30.812,-86.46802c32.181,33.46201 48.39801,50.207 83.157,52.5c34.87401,2.24802 70.96802,-11.142 90.90601,-41.34399c-0.01599,-0.034 -0.047,-0.06 -0.06299,-0.09399c-0.892,-1.939 -1.85202,-3.82101 -2.87402,-5.65601c-0.04498,-0.08099 -0.07999,-0.16901 -0.12598,-0.25c-1.05801,-1.88599 -2.186,-3.72501 -3.37402,-5.5c-0.017,-0.02399 -0.047,-0.03799 -0.06299,-0.06201c-1.19,-1.77399 -2.439,-3.526 -3.75,-5.18799c-0.01801,-0.02301 -0.04401,-0.039 -0.06299,-0.06201c-1.311,-1.65997 -2.668,-3.26498 -4.09302,-4.81299c-0.01999,-0.022 -0.043,-0.04099 -0.06299,-0.06299c-2.87701,-3.11801 -5.96402,-5.996 -9.25,-8.65601c-6.62201,-5.358 -14.03201,-9.78302 -21.90601,-13.25c-11.783,-5.18802 -24.65601,-8.241 -37.71899,-9.09399c-4.27,-0.27402 -8.304,-0.289 -12.15601,-0.06201c-1.62399,0.095 -3.12199,0.41101 -4.687,0.59399c-2.243,0.263 -4.541,0.43201 -6.688,0.875c-1.466,0.30099 -2.849,0.83401 -4.28101,1.21899c-2.01599,0.54102 -4.06099,1.01401 -6.03099,1.71802c-1.82401,0.65201 -3.632,1.52298 -5.438,2.31299c-1.612,0.70502 -3.231,1.311 -4.84399,2.125c-1.86101,0.94 -3.77301,2.103 -5.65601,3.18701c-1.513,0.871 -3.024,1.63199 -4.562,2.59399c-2.942,1.841 -5.996,3.952 -9.09401,6.125c-0.41199,0.289 -0.804,0.51801 -1.21899,0.81201c-5.35699,3.79999 -11.58501,8.65298 -17.75,13.40698c-2.229,1.71899 -4.037,2.97202 -6.40601,4.81201c0.017,-0.00101 0.04501,0.00198 0.06201,0c-0.61601,0.479 -1.061,0.79498 -1.68701,1.28101c16.718,-31.733 42.283,-69.54602 81.59401,-111.96802c30.33699,34.79501 47.01399,52.76001 82.718,56.68701c36.87799,4.01498 75.965,-8.423 99,-39.40601c0.082,-0.12299 0.19998,-0.22101 0.28198,-0.34399c-13.97998,-35.30101 -48.68597,-55.983 -85.71899,-60.06201c-4.474,-0.48999 -8.711,-0.679 -12.78101,-0.625c-1.57397,0.01901 -3.03699,0.24501 -4.56299,0.34401c-2.47198,0.162 -4.96899,0.257 -7.34399,0.62399c-1.668,0.257 -3.27301,0.73801 -4.90601,1.09401c-2.05301,0.45 -4.13901,0.83299 -6.15601,1.43799c-2.01401,0.60301 -4.03101,1.40001 -6.03101,2.15601c-1.59,0.601 -3.189,1.149 -4.78198,1.84399c-2.19699,0.959 -4.457,2.11301 -6.68701,3.25c-1.44098,0.73401 -2.88,1.44301 -4.34399,2.25c-2.325,1.283 -4.77699,2.72301 -7.187,4.18701c-1.30301,0.791 -2.63501,1.595 -3.96901,2.43799c-3.77699,2.388 -8.29599,5.483 -12.407,8.28101c25.15401,-25.59399 55.058,-52.614 91.157,-80.875c2.784,-2.18401 5.44,-4.649 7.125,-7.21899c1.58401,0.573 3.06302,1.07999 4.59399,1.625c4.979,1.77499 10.54602,3.82999 15.03101,5.28099c1.785,0.57701 3.46701,1.04201 5.18701,1.563c2.81598,0.854 5.67801,1.744 8.34399,2.437c0.61099,0.159 1.177,0.257 1.78101,0.407c7.68799,1.91 14.89099,3.175 21.90698,3.5c0.02002,0.00101 0.04202,-0.00099 0.06201,0c7.52399,0.34201 14.91901,-0.314 22.625,-2.157c3.854,-0.91899 7.79401,-2.12 11.875,-3.65599c4.16299,-1.57501 8.21399,-3.37401 12.125,-5.40601c27.32101,-14.17599 47.71201,-39.192 50.03101,-70.8438c-30.52802,-23.616 -70.73801,-25.9827 -104,-13.43739c-31.07901,11.7597 -41.742,31.7836 -58.75,68.9692c-3.24301,0.744 -6.621,2.767 -9.78101,5.093c-35.27399,25.85599 -65.123,50.22099 -91.09399,73.28099c25.95399,-43.84999 38.905,-66.912 27.25,-101.312c-11.97101,-35.3012 -43.576,-65.2006 -88.78101,-72.0938z',
            # Herb emoji: 🌿
            `bird` = 'path://m146.88901,185.386c-1.33301,20.91 21.23499,39.567 -8.552,37.453c-29.786,-2.114 -94.11541,-32.061 -93.29871,-44.68001c0.8168,-12.62 44.5357,-34.897 74.3227,-32.78299c29.786,2.101 28.87299,19.08699 27.52801,40.00999zm241.67899,203.13899c-2.42599,-0.405 -4.70801,0.19 -6.77399,1.202c-27.92502,2.93701 -38.73401,-23.85898 -38.73401,-23.85898c-5.27301,-4.25302 -11.78299,-25.42902 -19.08499,-15.379l2.246,17.74597c2.246,17.746 30.867,40.80701 30.867,40.80701l-14.59302,20.11301c-4.035,5.55701 -3.026,13.49301 2.246,17.746c5.27301,4.25299 12.80402,3.189 16.83899,-2.367l8.08301,-11.13901l-0.46799,3.15201c-1.04501,6.91101 3.423,13.392 9.98099,14.49301c6.55801,1.10098 12.707,-3.608 13.75201,-10.51901l5.64499,-37.50299c1.021,-6.91101 -3.44699,-13.392 -10.005,-14.49301zm-75.40298,7.88501c-2.354,-0.73401 -4.68402,-0.46802 -6.87,0.228c-28.04501,-1.03799 -35.35901,-29.112 -35.35901,-29.112c-4.685,-4.96201 -8.444,-26.87201 -16.96001,-17.935l-0.036,17.897c-0.036,17.89798 25.40298,44.79498 25.40298,44.79498l-17.01898,17.87201c-4.70801,4.936 -4.72,12.94901 -0.03601,17.89801c4.68399,4.961 12.28702,4.974 16.983,0.03799l9.42801,-9.89902l-0.87601,3.06403c-1.91,6.69498 1.69299,13.746 8.047,15.771c6.353,2.01199 13.05499,-1.785 14.965,-8.48102l10.353,-36.36499c1.94601,-6.70801 -1.65698,-13.758 -8.02298,-15.771zm147.11899,-288.88c-4.60001,-2.152 -9.104,-0.721 -12.61099,3.089c-0.64902,0.708 -50.745,79.817 -174.539,62.578c-4.08401,-0.57001 37.70099,151.48399 38.422,151.408c1.48901,-0.177 36.87299,-4.65802 73.745,-32.315c33.84702,-25.37802 75.47601,-75.83 81.63699,-172.11501c0.336,-5.291 -2.05399,-10.48 -6.65399,-12.645zm-6.38901,182.00101c-2.45099,-4.25299 -7.08698,-7.08801 -11.759,-5.96201c-15.53,3.73401 -38.39798,6.87299 -54.40799,5.73401c-76.35199,-5.41702 -112.43298,-52.26201 -112.80499,-52.65501c-3.30301,-3.569 5.59698,146.21901 9.80099,146.52299c110.42599,7.84702 166.492,-76.28699 168.83401,-79.86899c2.66699,-4.12601 2.79898,-9.505 0.33698,-13.771zm-118.798,-26.479c-4.45599,69.742 15.80603,124.815 -50.37299,120.10599c-66.179,-4.69598 -121.849,-62.27399 -117.39301,-132.02899c4.45601,-69.756 172.23401,-57.81999 167.76599,11.923zm-15.96298,-83.59c-4.23901,66.26199 -47.10501,117.16998 -109.96901,112.702c-62.87599,-4.46799 -110.41479,-61.79401 -106.175,-128.05501c4.24001,-66.2618 58.036,-106.87949 120.91199,-102.41139c48.054,3.4048 98.968,59.2744 95.23201,117.7644zm-175.2,-43.326c0,-13.981 10.75499,-25.315 24.02199,-25.315c13.26601,0 24.02101,11.334 24.02101,25.315c0,13.981 -10.755,25.315 -24.02101,25.315c-13.267,0 -24.02199,-11.334 -24.02199,-25.315zm114.21001,96.905c0,0 91.642,71.489 148.77698,-56.439c4.75601,-10.658 20.23801,10.037 1.189,52.67999c-19.04898,42.64299 -98.18799,81.51399 -144.60898,19.442c-9.789,-13.101 -5.35699,-15.683 -5.35699,-15.683zm-34.25401,-171.3561c0,0 75.01799,3.215 93.65901,-6.0375c18.64099,-9.2526 1.634,37.1115 -39.17902,47.9586c-40.812,10.848 -54.48,-41.9211 -54.48,-41.9211zm25.23399,33.9346c0,0 54.06,1.7214 72.71301,-7.5185c18.65298,-9.2399 1.633,37.112 -39.17902,47.959c-40.82399,10.847 -33.534,-40.4405 -33.534,-40.4405z',
            # Bird emoji: 🐦
            `reptile` = 'path://m175.714,126.065c-8.83501,0 -28.20201,25.733 -43.83301,11.806c-5.407,-4.808 22.341,-14.663 21.222,-23.141c-0.92099,-6.964 -34.923,-17.43871 -23.03999,-24.0815c11.882,-6.6312 29.713,9.6485 43.16899,9.9355c29.27101,0.631 51.759,-9.7863 52.078,-9.9355c6.649,-3.1435 14.685,-0.5965 17.991,5.6905c3.31801,6.276 0.627,13.917 -5.99699,17.049c-1.61,0.757 -27.342,12.677 -61.59,12.677zm196.34499,325.43701c-48.74799,0 -100.54398,-33.40903 -100.54398,-95.31601c0,-15.76401 -10.93701,-19.056 -20.11601,-19.056c-9.16701,0 -20.104,3.29199 -20.104,19.056c0,61.90698 -51.808,95.31601 -100.54399,95.31601c-48.7364,0 -100.53241,-31.78003 -100.53241,-95.31601c0,-152.496 174.2754,-173.54901 174.2754,-152.496c0,21.052 -93.83501,-12.701 -93.83501,139.79599c0,25.41202 10.937,31.76801 20.104,31.76801c9.179,0 20.116,-3.293 20.116,-19.056c0,-61.896 51.79601,-95.31601 100.545,-95.31601c48.73601,0 100.54399,33.40802 100.54399,95.31601c0,15.763 10.93701,19.056 20.11603,19.056c9.17999,0 20.10397,-3.293 20.10397,-19.056l0,-190.632c0,-44.228 -41.98999,-50.83599 -67.021,-50.83599c0,0 -40.20798,12.712 -80.42799,12.712c-40.22099,0 -53.627,-29.7836 -53.627,-50.8361c-0.02499,-21.0526 53.60201,-38.1241 134.03,-38.1241c80.44,0 147.46201,51.0654 147.46201,127.08419l0,190.62001c0,61.90698 -51.80801,95.31601 -100.54501,95.31601zm-120.64799,-378.60191c0,-6.3362 5.502,-11.4727 12.28902,-11.4727c6.78598,0 12.28799,5.13651 12.28799,11.4727c0,6.3363 -5.50201,11.4728 -12.28799,11.4728c-6.78702,0 -12.28902,-5.13651 -12.28902,-11.4728z',
            `detritus` = 'path://m452.76999,302.44199c4.13501,-17.08398 2.76001,-35.35797 -5.203,-53.54599c-7.70297,-17.592 -20.98297,-31.504 -37.15997,-40.847c3.61298,-12.905 2.65799,-26.795 -3.681,-40.59799c-9.55402,-20.78601 -30.21802,-34.65401 -53.52902,-38.563c2.82901,-6.192 3.737,-13.954 0.409,-23.46c-11.35999,-32.4782 -56.802,-10.8259 -90.88199,-54.1196c-27.71899,15.8495 -33.74001,39.4071 -32.69499,59.4026c-27.50301,4.461 -43.16901,10.134 -43.16901,10.134l0,0.021c-15.45,5.955 -26.379,20.386 -26.379,37.26401c0,9.51599 3.61299,18.144 9.40599,25.03l-7.86099,2.793l0.01199,0.032c-26.47,9.42999 -45.158,32.21899 -45.158,58.884c0,11.33501 3.409,21.94398 9.316,31.157c-32.0702,13.73901 -54.4613,43.55399 -54.4613,78.40298c0,47.83002 41.9303,86.60901 93.6543,86.60901c37.13699,0 74.51199,-7.61099 108.27499,-18.02499c25.48099,11.259 64.69598,18.02499 123.73599,18.02499c46.009,0 83.30499,-35.54199 83.30499,-79.388c0,-23.55798 -10.827,-44.65799 -27.935,-59.20801zm-267.43298,-83.33899c0,-26.90599 17.802,-48.718 39.761,-48.718c21.95999,0 39.761,21.81201 39.761,48.718c0,26.905 -17.80101,48.71701 -39.761,48.71701c-21.959,0 -39.761,-21.81201 -39.761,-48.71701zm113.603,0c0,-26.90599 17.802,-48.718 39.76099,-48.718c21.95901,0 39.76102,21.81201 39.76102,48.718c0,26.905 -17.802,48.71701 -39.76102,48.71701c-21.95898,0 -39.76099,-21.81201 -39.76099,-48.71701zm-90.882,0c0,-14.948 10.172,-27.06599 22.72101,-27.06599c12.54799,0 22.71999,12.118 22.71999,27.06599c0,14.94701 -10.172,27.065 -22.71999,27.065c-12.54901,0 -22.72101,-12.118 -22.72101,-27.065zm102.24199,0c0,-14.948 10.173,-27.06599 22.72101,-27.06599c12.548,0 22.72101,12.118 22.72101,27.06599c0,14.94701 -10.173,27.065 -22.72101,27.065c-12.548,0 -22.72101,-12.118 -22.72101,-27.065zm-131.245,101.711c-2.79399,-5.33701 0.03401,-9.689 6.28201,-9.689l204.48499,0c6.24802,0 9.077,4.35199 6.28302,9.689c0,0 -29.00302,55.267 -108.52502,55.267c-79.52199,0 -108.52499,-55.267 -108.52499,-55.267zm108.52499,11.96301c-31.47897,0 -58.58499,9.98099 -71.47899,24.42398c16.95,10.33801 40.27199,18.88 71.47899,18.88c31.207,0 54.54102,-8.54199 71.479,-18.88c-12.89398,-14.44299 -40,-24.42398 -71.479,-24.42398z',
            # Leaf emoji: 🍂
            `unidentified` = 'path://m258.09399,90.625c-77.72499,0 -143.40599,44.38 -143.40599,96.90601c0,17.84299 19.237,32.28099 43,32.28099c23.76199,0 43.03099,-14.438 43.03099,-32.28099c0,-10.76801 22.37001,-32.31201 57.375,-32.31201c43.021,0 71.68701,21.526 71.68701,43.06201c0,43.07199 -77.384,53.77899 -86.03101,53.84399c-23.76199,0 -43.03101,14.47 -43.03101,32.31299l0,43.06201c0,17.84201 19.26901,32.31201 43.03101,32.31201c23.76199,0.00098 43,-14.47 43,-32.31201l0,-14.34399c11.42899,-1.72299 24.18701,-4.28302 37.09399,-8.06201c59.31201,-17.30399 91.96802,-51.39899 91.96802,-96.032c0.00098,-54.03299 -42.99503,-118.437 -157.71802,-118.437zm-14.34399,290.71899c-23.75999,0 -43.03101,14.47101 -43.03101,32.31201c0,17.841 19.27101,32.28198 43.03101,32.28198c23.76001,-0.00098 43,-14.44098 43,-32.28198c0,-17.841 -19.23999,-32.31201 -43,-32.31201z',
            `invertebrate` = 'path://m100.844,109.563c-15.63461,-0.87 -21.8029,26.993 -11.969,26.993c13.521,0 20.639,13.31 17.125,34.457c-27.0613,6.286 -54.9375,28.226 -54.9375,43.379c0,21.10901 12.106,21.097 36.3125,31.651c24.207,10.55399 -12.1033,84.44199 0,126.659c8.8112,30.71201 36.296,63.32901 96.813,63.32901l278.37401,0c12.10397,0 24.21899,0.004 24.21899,-10.55002c0,-7.759 -32.716,-21.207 -64.46899,-31.987c20.86899,-14.332 35.672,-34.51398 42.12598,-57.88599c18.51801,-67.15601 -26.70499,-135.457 -100.81299,-152.24901c-89.48001,-20.29599 -180.55901,29.22701 -202.937,110.356c-1.127,4.08301 -0.826,8.16101 0.562,11.86902c-4.354,-6.263 -4.99899,-14.77802 -1.25,-27.86203c6.756,-23.56598 16.39,-57.51599 2.53101,-82.40999c5.45999,-32.88499 16.72699,-63.063 -2.53101,-79.856c-24.207,-21.1084 -36.322,21.1 -24.21899,21.1c15.556,0 22.644,17.548 14.75,44.502c-4.104,-3.336 -8.94,-6.362 -14.75,-8.895c-4.66,-2.032 -9.90001,-2.82899 -15.37501,-2.862c4.315,-22.16699 6.649,-41.671 -7.312,-53.84499c-4.539,-3.958 -8.642,-5.692 -12.25,-5.893z'      # Snail emoji: 🐌
          )


          class2 = classification_list2[match(qw, names(classification_list2))]

          class2 <- data.frame(class2)
          class2 = class2 %>% gather('name', 'path', 1:length(data2$category))
          qw3 = class2$path


        }

        if (input$ch1 == 'Groups') {
          classify_category <- function(text) {
            prompt <- paste(
              "Please classify the following as one of the following categories:\n\n Bird, Detritus, Invertebrate, Mammal, Fish, Reptile, Primary producer, or Unidentified.\n\nHere is the text to classify:\n\n",
              text,
              "\n\nCategory:"
            )
            response <- gpt3_single_completion(
              prompt_input = prompt,
              temperature = 0.3,
              max_tokens = 3,
              n = 1,
              model = "gpt-3.5-turbo-instruct"
            )
            category <- response[[1]]$gpt3
          }

          qw = sapply(data2$name, classify_category) %>% tolower()

          standardize_word <- function(word) {
            target_words <- c(
              'bird',
              'detritus',
              'invertebrate',
              'mammal',
              'fish',
              'reptile',
              'primary producer',
              'unidentified'
            )
            distances <- stringdistmatrix(word, target_words, method = 'jw')

            closest_match_index <- which.min(distances)
            closest_match_distance <- distances[closest_match_index]

            other_distances <- distances[-closest_match_index]
            if (closest_match_distance < 10 &&
                all(closest_match_distance < other_distances + 3)) {
              return(target_words[closest_match_index])
            } else {
              return(word)
            }
          }

          qw <- sapply(qw, standardize_word)


          classification_list <- list(
            `mammal` = 'path://m439.56,144.813c-4.522,-39.83599 -45.271,-56.241 -45.271,-56.241s-11.198,32.337 -6.79001,63.26701c5.35101,37.51399 -41.853,77.83699 -141.994,77.83699c0,0 -192.82299,0 -231.951,0c-39.12,0 5.032,133.035 150.90901,138.85101c11.23599,0.44901 21.924,0.13699 32.155,-0.76199c18.55199,18.72699 46.42799,40.01898 86.75099,55.43399c15.27802,5.086 36.43298,-75.39301 -47.79102,-131.25302l2.634,-2.26898c28.08301,11.50998 47.63101,26.65198 60.86902,42.43198c51.55099,-34.32397 78.332,-82.633 90.68698,-98.26199c20.371,-25.77499 40.17001,-29.14799 70.172,-32.802c38.47202,-4.68799 52.06003,-32.80199 52.06003,-32.80199s-40.75,-25.77499 -72.44,-23.42999z',
            `fish` = 'path://m473.47198,266.47699l38.172,-98.60899c0.84399,-2.203 0.14102,-4.688 -1.71899,-6.10901c-1.875,-1.438 -4.453,-1.453 -6.34399,-0.063l-99.09402,73.09401c-21.32797,-2.51601 -44.39099,-53.46901 -145.92197,-78.75l29.672,-4.23401c4.73398,-0.672 8.89099,-3.43799 11.35898,-7.547c2.453,-4.09399 2.922,-9.078 1.297,-13.563l-14.922,-41.03099c-1.828,-5.01601 -6.047,-8.78101 -11.23398,-10.01601s-10.64102,0.219 -14.53101,3.875l-67.922,63.938c-109.89,2.40501 -192.281,90.85802 -192.281,119.015c3.734,23.60901 48.891,77.875 117.25,104.25c7.141,-9.96899 12.906,-19.59399 17.516,-28.76599c13.453,-26.828 17.23401,-49.875 17.23401,-65.73401c0,-6.39099 -0.625,-11.60901 -1.42201,-15.26599c-1.28099,-6.04701 2.563,-11.98401 8.60901,-13.26601c6.047,-1.297 11.98399,2.563 13.28099,8.59401c1.15601,5.453 1.89101,12.10898 1.89101,19.93799c0,19.34399 -4.578,45.81299 -19.60899,75.76599c-4.21901,8.422 -9.313,17.125 -15.328,26.01602c23.5,6.40598 49.203,9.297 76.48399,6.70297l20.25,39.453c2.047,4 5.688,6.93802 10.03101,8.09402c4.34399,1.14099 8.96899,0.40598 12.75,-2.06302l15.453,-10.10901c4.26599,-2.78098 6.90601,-7.422 7.172,-12.48398c0.23401,-5.06302 -1.93799,-9.953 -5.89099,-13.14102l-20.70302,-16.672c104.59401,-24.93799 127.95302,-77.078 149.51601,-79.625l99.09402,73.09402c1.89099,1.39099 4.46899,1.375 6.34399,-0.04703c1.85898,-1.422 2.56302,-3.922 1.71899,-6.10898l-38.17203,-98.62601zm-397.04698,7.46802c-9.26601,0 -16.781,-7.53101 -16.781,-16.78101c0,-9.26599 7.516,-16.78099 16.781,-16.78099s16.781,7.51601 16.781,16.78099c0,9.25 -7.516,16.78101 -16.781,16.78101z',
            `primary producer` = 'path://m176.692,9.90914c-0.87,0.86836 -3.327,-0.0956 -4.576,0.40346c-2.81999,1.1269 -5.842,1.8909 -8.265,4.3034c-20.717,20.623 -41.459,41.2699 -62.139,61.9286c-3.0002,2.9966 -3.9965,7.6413 -4.5023,11.431c-0.0134,0.1008 -0.1204,0.2555 -0.22141,0.2689c-1.3557,0.1806 -2.9412,0.0434 -4.2065,0.6052c-2.4825,1.1021 -5.276,2.0682 -7.4537,4.2361c-20.6083,20.5152 -41.1976,41.04221 -61.7701,61.59219c-2.2604,2.25801 -3.7738,5.73901 -4.1328,8.60701c-0.1319,1.05499 -0.4115,2.89 -0.6642,3.89999c-0.2363,0.94501 0.191,1.918 0.2214,2.89101c0.1537,4.914 3.2081,9.625 6.9372,12.978c0.0496,-0.03999 0.0981,0.03 0.1476,0c6.4839,6.297 19.171,6.55499 25.7559,0c20.7163,-20.623 41.4586,-41.27 62.1389,-61.929c2.07301,-2.07 2.481,-4.607 3.543,-6.993c0.131,-0.29601 0.635,-0.916 0.664,-1.21001c0.123,-1.271 -0.678,-3.60699 0.59,-3.766c1.036,-0.129 2.134,0.098 3.174,0c0.293,-0.027 0.884,-0.545 1.18,-0.672c2.552,-1.093 4.988,-1.601 7.159,-3.766c20.554,-20.4966 41.086,-40.9426 61.62199,-61.4575c4.86101,-4.8555 6.382,-14.7692 3.543,-20.4411c-0.88699,-1.7725 -1.53299,-4.4598 -3.321,-5.7155c-2.914,-3.3266 -6.255,-5.373 -10.11099,-6.6568c-1.597,-0.53202 -3.90901,0.3973 -5.313,-0.53796zm31.069,3.89996c-0.51801,0.518 -0.04001,2.073 0.44299,2.5551c0.59401,-0.5393 0.58701,-0.5364 1.181,-1.0758c-0.81,-0.7552 -0.814,-0.7241 -1.62399,-1.4793zm169.59099,32.8134c-0.06598,-0.0933 -0.11899,-0.0515 -0.36899,0.269c-3.02399,3.873 -9.27301,5.6305 -11.36499,9.9516c-1.98001,4.0902 -0.08902,8.8709 0,13.3137c0.00299,0.1385 0.81699,-0.2187 1.328,-0.3362c-0.51602,0.18629 -1.11301,0.3808 -1.328,0.5379c-3.617,2.6444 -5.68402,4.5582 -6.93701,8.40511c-1.36801,4.1998 0.77399,8.4589 3.98499,11.4981c-0.31699,-0.3409 -0.62997,-0.6944 -0.88599,-0.94131c-0.49301,0.43291 -1.34601,-0.6554 -1.845,-0.8742c-1.21301,-0.5321 -3.10199,-1.4683 -4.42801,-1.6137c-5.552,-0.60889 -9.94699,0.65411 -13.79999,4.0344c-3.28201,2.8788 -4.74899,8.2416 -3.39499,12.1031c0.34698,0.99 1.077,2.506 1.91898,3.429c0.26801,0.294 0.81201,0.498 0.81201,0.875c0,0.095 -0.08801,0.122 -0.14801,0.201c0.20001,0.176 0.38901,0.362 0.591,0.538c-2.646,-2.051 -5.42599,-2.995 -10.03699,-3.295c-7.96402,0.499 -13.34702,5.38499 -13.948,12.238c-0.15201,1.732 0.00998,4.018 1.03299,5.514c0.733,1.072 1.496,2.102 2.435,3.093c-0.12,-0.11301 -0.24799,-0.222 -0.36899,-0.33601c-0.09,0.079 -0.05701,0.122 -0.147,0.202c-1.733,-0.76 -3.16699,-2.015 -5.01901,-2.421c-5.72198,-1.255 -10.884,0.435 -14.83298,3.89999c-1.06702,0.936 -1.51401,2.143 -2.28802,3.16c-0.54099,0.71201 -1.09598,1.92001 -1.25497,2.757c-0.43503,2.293 -0.36301,5.334 0.81198,7.397c0.32602,0.57201 2.10501,2.868 1.771,3.16c0.14502,0.127 0.517,0.407 0.88602,0.672c-3.617,-2.745 -7.92502,-3.875 -12.767,-3.026c-1.30402,0.229 -2.67902,0.509 -3.76401,1.144c-1.521,0.88901 -2.845,1.83101 -4.207,3.02501c-0.70499,0.61899 -1.08899,1.38399 -1.69699,1.95c-0.02502,-0.017 -0.039,-0.06601 -0.07401,-0.067c-5.03302,-0.13 -10.09302,-0.026 -15.129,0c-0.06702,0 -0.10001,0.026 -0.147,0.067c-3.694,3.21399 -7.377,6.46899 -11.07001,9.683c-0.048,0.04199 -0.129,0.00999 -0.14799,0.067c-0.138,0.425 -0.09601,0.46199 0.14799,0.673c2.472,2.142 4.87799,4.271 7.38,6.38799c0.043,0.03601 0.17801,0.037 0.22101,0c2.71298,-2.32799 5.34598,-4.71999 8.04398,-7.06099c0.048,-0.041 0.08002,-0.06601 0.14801,-0.067c3.05099,-0.026 6.17401,0.049 9.22501,0c0.29999,0.388 0.306,0.711 0.59,1.20999c0.69299,1.21701 1.367,2.61601 2.509,3.63101c4.267,3.79599 8.56,7.58099 12.841,11.364c4.14899,3.666 8.30899,7.308 12.47299,10.95999c1.35602,1.19 3.702,2.52701 5.534,2.757c0.25101,0.032 0.439,0.276 0.66501,0.40401c-0.05899,2.72299 1.31201,5.66699 0,8.136c-1.62201,3.05099 -5.508,4.78799 -8.19202,7.19398c-0.04199,0.03801 -0.04199,0.097 0,0.13501c2.41202,2.168 4.95203,4.3 7.38,6.455c0.30099,0.267 0.05402,0.373 0.73801,0.202c0.065,-0.017 0.026,-0.093 0.07401,-0.13499c3.724,-3.293 9.14401,-5.617 11.21701,-9.884c1.974,-4.064 0.14697,-8.83101 0,-13.24701c-0.00201,-0.05199 -0.104,-0.013 -0.147,-0.06699c1.564,-1.35501 3.58499,-2.49901 4.944,-4.16901c3.72498,-4.57401 2.76498,-10.79001 -1.03302,-14.927c0.117,0.11501 0.25101,0.22101 0.36902,0.336c0.46298,-0.40599 2.853,1.20401 3.69,1.479c2.07098,0.68199 4.61499,0.89099 6.93698,0.74001c5.16501,-0.33601 9.51001,-3.69601 11.73401,-7.59801c1.11401,-1.95399 1.10699,-4.791 1.10699,-6.79199c0,-2.02 -1.40201,-4.62701 -3.026,-6.05101c0.20901,-0.183 0.21802,-0.117 0.36902,-0.202c1.76199,1.28101 3.89297,2.312 6.12598,2.42101c0.72302,0.03499 1.539,0.323 2.14001,-0.067c-0.091,0.07899 -0.13101,0.12199 -0.22202,0.20099c0.38501,0.33701 1.617,0.19501 1.99301,-0.13399c-0.09,-0.08 -0.05701,-0.05501 -0.14801,-0.13501c0.061,-0.05299 0.14801,-0.05899 0.14801,-0.134c0.436,0.664 2.43799,0.242 3.173,0c3.022,-0.99399 5.612,-2.76399 7.67599,-5.17799c2.53601,-2.966 2.944,-7.955 1.62299,-11.431c-0.46698,-1.23 -1.491,-2.162 -2.435,-3.16c0.25803,-0.226 0.14102,-0.103 0.36902,-0.403c5.289,4.63901 15.87399,3.095 20.147,-2.15199c0.539,-0.662 1.582,-1.548 1.845,-2.354c0.16299,-0.499 0.56998,-1.031 0.73798,-1.546c1.349,-4.14201 0.53302,-8.19901 -2.28799,-11.498c0.14502,-0.127 0.19702,-0.183 0.29501,-0.269c0.267,0.182 0.48199,0.445 0.73801,0.605c4.96899,3.113 12.24799,2.254 16.89999,-0.807c1.53598,-1.01 2.37799,-2.945 3.69,-3.765c0.03299,0.044 0.017,0.133 0.07401,0.134c5.064,0.104 10.13699,0.026 15.20297,0c0.06702,0 0.173,-0.02499 0.22101,-0.06699c3.694,-3.214 7.30301,-6.469 10.996,-9.6828c0.048,-0.0416 0.203,-0.07761 0.22202,-0.13451c0.138,-0.42419 0.022,-0.394 -0.22202,-0.60509c-2.47198,-2.1428 -4.948,-4.3126 -7.60098,-6.4551c-2.71402,2.3805 -5.36002,4.8535 -8.11801,7.1947c-0.065,0.0552 -0.20502,-0.0008 -0.29501,0c-2.86499,0.0257 -5.69598,0.0412 -8.56097,0.0673c-0.12003,0.0011 -0.26501,-0.0545 -0.36902,0c-0.715,0.3764 -0.02301,1.3395 0,1.7485c0.035,0.627 0.008,1.254 0,1.882c-0.05399,-3.3802 -0.91501,-6.6101 -3.69,-9.077c-4.20801,-3.7413 -8.47198,-7.4325 -12.69299,-11.162c-0.03201,0.02821 -0.052,0.04111 -0.07401,0.06731c-4.138,-3.7835 -8.40799,-7.44141 -12.62,-11.162c-1.625,-1.4359 -3.599,-2.573 -5.608,-2.8913c0.08801,-2.67039 -1.29901,-5.585 0,-8.0017c1.63501,-3.0454 5.508,-4.721 8.19101,-7.1275c0.151,-0.1352 -0.22702,-0.4118 -0.29501,-0.4707c-2.35098,-2.037 -4.74799,-4.0688 -7.08499,-6.1189c-0.211,-0.185 -0.229,-0.3773 -0.29501,-0.4707zm-188.77899,109.8045c-0.668,-0.08 -1.213,-0.03799 -1.476,0.47c0.326,0.315 0.66701,0.367 1.034,0.47099c-3.01799,0.56401 -6.211,1.42 -7.45399,2.62201c0.084,0.16199 0.13699,0.174 0.22099,0.33699c-1.123,-0.85199 -3.996,0.43001 -5.092,1.27701c-1.79199,1.386 -4.866,1.8 -6.86301,2.959c-1.90999,1.10699 -4.21899,3.38499 -6.347,3.89999c-2.14,0.517 -5.33299,3.66701 -7.01099,5.177c-1.12801,1.01601 -2.25601,2.088 -3.395,3.093c-7.248,6.39799 -11.715,14.59599 -14.612,22.99699c-0.39801,1.155 -1.222,2.901 -1.328,4.03401c-0.355,3.76799 -0.29601,7.57999 -0.29601,11.364c0,3.55099 1.08101,8.409 2.51001,11.63199c0.38199,0.862 1.209,2.229 1.328,3.093c0.93799,6.80301 1.41399,13.608 0,20.442c-0.34901,1.686 -0.09401,3.817 -0.81201,5.379c-1.509,3.282 -1.883,8.032 -4.20599,11.02699c-2.095,2.70001 -2.633,6.517 -4.724,9.21201c-1.157,1.49301 -1.79401,3.586 -2.509,5.31201c-3.403,8.22598 -6.436,15.84399 -6.715,25.01401c-0.099,3.224 -0.626,7.41498 0.221,10.69098c1.913,7.39902 4.2,15.853 9.37201,21.853c7.92799,9.19601 17.12399,18.36401 17.786,30.52701c0.84,15.431 -6.959,27.24301 -11.07001,41.15201c-0.403,1.36499 -0.832,4.246 -0.88499,5.51401c-0.108,2.53699 -0.108,5.06 0,7.59799c0.006,0.15201 0.343,0.185 0.369,0.336c0.36099,2.095 -0.02501,4.362 0.51599,6.45499c2.295,8.875 5.85301,17.23502 11.218,25.01401c0.034,-0.02899 0.041,-0.10501 0.07401,-0.13501c0.565,1.02802 5.037,6.74902 5.534,7.26202c-6.52,0.11697 -13.035,0.134 -19.556,0.13498c-4.91901,0 -9.844,0.16 -14.76,0c-0.16499,-0.00598 -0.195,-0.189 -0.295,-0.33701c0.038,-0.05899 0.11,-0.08099 0.147,-0.13397c1.136,-1.647 3.122,-8.414 3.174,-10.22101c0.108,-3.78101 0.16,-7.58401 0,-11.36301c-0.045,-1.05701 -0.879,-2.867 -1.181,-4.035c-0.914,-3.53299 -1.99,-7.69901 -4.354,-10.55701c-3.045,-3.67899 -5.961,-7.603 -8.045,-11.63199c-0.834,-1.61301 -1.954,-3.13699 -2.361,-4.909c-0.359,-1.56201 -0.007,-3.39902 -0.29501,-4.97601c-0.16,-0.87698 -0.841,0.35901 -0.369,-1.008c1.069,-3.10098 0.825,-6.48401 2.066,-9.68298c5.09299,-13.12802 10.759,-28.39502 0.44299,-41.21802c-5.266,-6.54599 -12.3087,-10.229 -20.295,-11.633c-4.3168,-0.759 -9.2678,-0.59201 -13.3577,-2.28601c-4.9809,-2.064 -9.4058,-4.573 -13.579,-8.60699c-5.2144,-5.04099 -6.8571,-12.10098 -10.4057,-17.819c-2.763,-4.452 -7.4212,-7.92499 -11.4389,-11.16199c-1.5394,-1.23999 -3.7465,-3.297 -5.6826,-3.76501c-0.8945,-0.216 -1.7008,-1.14499 -2.5092,-1.61398c-1.667,-0.96701 -3.5378,-1.47601 -5.1659,-2.42102c-0.3896,-0.22598 -2.1388,-1.53497 -2.583,-1.27698c-2.4486,-2.142 -6.5017,-1.75 -9.0035,-3.564c-0.4682,-0.33902 -3.1351,-1.29102 -3.3948,-0.53802c-0.218,0.63202 2.509,3.06403 2.8782,3.56403c2.2093,2.98999 4.391,6.849 5.3873,10.21997c0.5578,1.888 1.3383,4.45602 1.476,6.18701c0.1118,1.40399 -0.6617,3.23901 0.369,4.23599c-0.5803,1.83301 -0.1035,4.11801 0,6.11902c0.131,2.53198 0.4149,6.17599 1.476,8.741c0.8669,2.095 0.7599,4.54199 1.6974,6.65698c3.0871,6.96301 7.1191,12.88 13.0625,18.625c7.9415,7.67801 18.5186,10.44601 26.3463,18.35703c6.8354,6.90799 4.1083,18.715 1.9926,26.896c-0.5237,2.02499 -0.9536,3.811 -1.3284,5.98499c-0.0556,0.32199 -0.6412,0.78702 -0.6642,1.008c-0.3561,3.44302 -0.3689,6.896 -0.369,10.35501c0,1.46799 0.4993,3.85999 1.1808,5.17801c1.1737,2.26898 2.6737,4.40598 3.8376,6.65698c0.8365,1.617 2.6826,2.888 4.2066,4.034c7.12431,5.35703 16.31651,5.603 23.68961,10.35501c3.0919,1.99301 6.596,5.237 8.339,8.60699c0.674,1.302 1.603,3.077 2.657,4.23599c-0.075,0.08701 -0.06499,0.25702 -0.14799,0.336c1.311,2.53403 1.238,5.81201 2.50999,8.27103c-15.1823,0.53098 -30.4164,0.284 -45.6084,0.336c-6.1662,0.022 -13.8257,6.90399 -14.3908,12.642c-0.1167,1.18399 -0.1066,2.37399 -0.1476,3.56299c-0.1062,3.07901 -0.1656,6.13199 -0.2214,9.21201c102.7862,0.08099 102.8182,0.05399 205.6052,0.13501c0.06401,-3.54501 0.382,-8.21902 0,-12.104c-0.222,-2.25302 -1.366,-4.18002 -2.657,-6.05099c-6.45799,-9.36603 -14.959,-7.733 -26.19901,-7.733c-11.793,0 -23.556,0.18799 -35.34999,0.13498c-0.158,-0.00098 -0.257,-0.228 -0.369,-0.33701c0.679,-0.86099 2.98199,-6.694 3.543,-7.59799c4.8,-7.73401 11.104,-15.987 19.409,-20.57599c7.024,-3.88 15.091,-6.59201 22.804,-9.077c4.42101,-1.42502 9.52,-2.85901 13.431,-5.379c3.17101,-2.04401 6.84001,-3.63901 9.89,-5.85001c17.29901,-12.543 32.74701,-30.811 33.578,-51.70801c0.01501,-0.36301 0.65701,-0.84399 0.664,-1.07599c0.26001,-7.771 -0.70401,-14.13501 -2.509,-21.11401c-0.38501,-1.48898 -0.30899,-3.30798 -1.03299,-4.707c-1.86099,-3.59799 -1.66501,-7.897 -3.32101,-11.63199c-0.776,-1.75 -0.651,-3.63699 -1.181,-5.51401c-0.21698,-0.76901 -0.573,0.198 -0.664,-0.80701c-0.40601,-4.51801 -0.603,-8.827 -0.51599,-13.64999c0.01999,-1.15698 0.48499,-3.168 0.95898,-4.23599c0.32501,-0.733 0.09601,-1.89801 0.36902,-2.689c1.27499,-3.698 1.746,-7.85602 3.026,-11.56601c0.38,-1.103 0.20401,-3.36099 0.29498,-4.37c0.72501,-8.05801 -0.04398,-16.69601 -2.65698,-24.27402c-1.02499,-2.97198 -2.02002,-9.37399 -4.354,-11.83499c-2.19299,-4.23999 -4.948,-8.879 -8.561,-12.37199c-0.53299,-0.51601 -3.33899,-3.87201 -4.354,-2.89101c0.42502,0.82001 0.336,3.06201 0.36902,3.429c0.05499,0.61 0.62598,1.621 0.664,2.084c0.31799,3.84401 0.25198,7.647 0.664,11.49901c0.02197,0.19699 0.10599,0.54399 0.14798,0.806c-0.23801,0.759 -0.46799,1.724 -0.517,2.287c-0.10199,1.185 -0.04498,2.377 -0.147,3.56299c-0.034,0.39401 -0.603,0.64601 -0.664,0.942c-1.05698,5.10899 -3.035,10.321 -6.716,14.59102c-4.836,5.60999 -10.59198,10.37 -15.79298,15.39798c-6.007,5.80701 -13.241,10.48102 -17.71201,17.68399c-2.35699,3.79703 -4.619,7.04102 -5.38699,11.49902c-0.01601,0.091 -0.66301,1.42798 -0.66501,1.479c-0.10699,3.02399 -0.15799,6.05499 0,9.077c0.05901,1.112 0.903,4.267 1.476,5.51398c3.10101,6.74301 7.96501,13.31403 10.11101,20.57602c0.461,1.55899 1.674,3.16599 1.993,4.707c1.147,5.54498 0.218,11.276 -1.55,16.40601c-2.37199,6.87997 -7.638,13.16299 -12.54599,18.96198c-9.15401,10.81601 -20.99001,21.17401 -28.339,33.01501c-2.658,4.28299 -5.745,8.10001 -7.38,12.84299c-0.411,1.19101 -1.403,2.77301 -1.10699,4.16901c-0.058,-0.186 -0.125,-0.36899 -0.369,-0.60498c-0.93199,0.901 -0.839,2.81 -1.40199,3.89999c-1.90201,3.67798 -2.412,8.97 -2.509,13.112c-0.043,1.81699 -0.312,4.26898 0.22099,6.186c-5.754,0.10898 -13.03,0.33099 -18.819,0.13498c-0.123,-0.005 -0.14499,-0.16098 -0.22099,-0.26898c0.013,-0.03 0.064,-0.03799 0.07401,-0.06802c0.86699,-2.79498 -0.14801,-5.823 -0.14801,-8.741c0,-6.01797 1.207,-11.681 2.509,-17.34799c0.22,-0.957 -0.067,-1.92801 0.295,-2.89099c2.034,-5.40601 3.35201,-12.47101 6.716,-17.34799c5.215,-7.56201 10.452,-15.453 15.793,-23.19901c1.601,-2.32101 4.166,-6.01401 4.871,-8.741c0.16299,-0.629 0.439,-1.88 0.812,-2.42001c1.881,-2.728 2.23801,-6.14099 3.321,-9.28c8.202,-23.78699 -9.58699,-37.81299 -12.694,-58.83499c-1.19299,-8.07602 0.826,-16.48901 5.314,-22.99701c3.46101,-5.01901 7.48601,-10.28299 9.74101,-15.73401c0.53099,-1.28299 0.521,-2.71399 1.03299,-4.034c0.43201,-1.112 1.15001,-3.28699 1.181,-4.371c0.25101,-8.84698 -0.22299,-20.28099 -5.38699,-27.76999c-5.744,-8.32899 -12.435,-15.937 -15.27701,-25.552c-2.207,-7.46899 -2.47899,-16.89 -1.32799,-24.677c0.23099,-1.563 0.87999,-3.554 1.03299,-5.17799c0.162,-1.72501 2.82901,-8.87201 2.436,-10.22c0.033,-0.03801 0.03999,-0.097 0.073,-0.13501c0.168,0.08101 0.12801,0.054 0.29601,0.13501c1.44899,-1.40201 1.82899,-3.82401 2.87799,-5.51401c2.15701,-3.476 4.30301,-7.026 6.19901,-10.69099c-0.64,-0.04401 -1.972,0.26801 -3.026,0.403c0.27299,-0.142 0.561,-0.161 0.812,-0.403c-0.58699,-0.02901 -1.325,-0.257 -1.993,-0.336zm301.02802,73.29199c-0.07101,0.033 0.04398,0.14301 0,0.20201c-2.07901,2.77199 -4.22702,5.521 -6.34702,8.26999c-0.04498,0.058 -0.07001,0.12001 -0.147,0.13501c-15.56198,2.948 -31.15298,5.86 -46.715,8.808c-2.16199,0.41 -5.17801,1.394 -6.79001,2.69c-6.285,5.052 -9.198,9.83099 -7.74899,17.21298c0.371,1.888 0.68301,3.83801 1.10699,5.716c0.04102,0.18201 0.02802,0.38602 0.14801,0.53799c0.02798,0.035 0.427,0.09302 0.51599,0.134c-4.79999,-1.22198 -10.702,-0.45599 -15.42398,0.80701c-1.73401,0.46402 -7.01901,1.784 -8.11801,3.228c-0.30099,-0.172 -0.23999,-0.005 -0.29501,-0.26898c-0.38998,-1.884 -0.68298,-3.83801 -1.10699,-5.716c-0.203,-0.89999 -0.61301,-2.56302 -1.181,-3.42902c-0.92398,-1.40799 -1.78299,-3.11899 -3.099,-4.371c-4.522,-4.29898 -11.34198,-6.44 -17.78598,-5.24399c-15.61002,2.89499 -31.17203,5.80899 -46.789,8.67401c-1.621,0.297 -9.53702,-6.49402 -10.332,-5.51401c-2.311,2.849 -4.37601,5.82199 -6.56802,8.741c-0.15799,0.211 -0.53098,0.603 -0.29498,0.73999c4.681,2.72101 9.34601,5.439 14.09601,8.069c0.08899,0.04901 0.18997,-0.048 0.29498,-0.06699c17.38699,-3.228 34.78299,-6.48502 52.17599,-9.68301c1.927,-0.354 5.34302,1.11301 5.978,2.689c0.18402,0.45801 0.414,1.052 0.51602,1.48001c1.18399,4.923 2.38898,9.85001 3.46899,14.793c0.08701,0.397 -0.96899,2.16901 -1.181,2.55499c-0.043,0.07901 -0.04901,0.25 -0.147,0.26901c-9.147,1.77701 -18.29999,3.36301 -27.45401,5.10999c-0.078,0.01501 -0.177,0.07703 -0.22098,0.13501c-4.19202,5.47299 -8.32202,10.97699 -12.47202,16.474c-0.125,0.16501 -0.11301,0.42999 0.07401,0.53799c3.36099,1.94202 6.72101,3.87601 10.10999,5.78201c0.06601,0.03699 0.21902,0.04999 0.29501,0.06699c3.20499,-4.21399 6.409,-8.474 9.668,-12.64099c0.08301,-0.10599 0.22601,-0.10599 0.36899,-0.134c5.83801,-1.15698 11.70602,-2.36301 17.56403,-3.42999c0.099,-0.01801 0.15997,0.06699 0.22198,0.13501c0.17499,0.19498 0.23999,0.495 0.29501,0.73999c2.29099,10.14499 4.45898,20.30798 6.71597,30.45999c1.56201,7.03 3.17502,14.02701 4.79703,21.04602c0.58899,2.55298 3.66098,5.93698 6.56799,6.85797c1.16901,0.371 2.569,0.95401 3.83701,1.07602c0.28198,0.02701 1.39499,-0.37799 1.54999,0.06799c1.20999,3.47202 2.94501,6.91602 6.125,9.27899c0.73901,0.54901 1.61401,0.87201 2.362,1.41202c0.96899,0.69998 0.45499,5.181 1.62399,6.65698c0.59802,0.75601 2.07901,2.23602 2.28702,3.16c0.07898,0.349 -0.33902,0.88101 -0.44202,1.20999c-0.336,1.06403 -0.31198,2.63101 -0.29599,3.63101c0.02798,1.755 0.74399,4.71301 2.06699,6.186c0.44702,0.49799 1.34201,1.15799 1.62302,1.74899c0.27399,0.57501 -0.366,1.02402 -0.44299,1.54599c-0.17502,1.194 -0.31302,2.46701 -0.29501,3.63101c0.06601,4.09201 2.328,6.19202 4.797,8.94299c-0.60699,0.79901 -3.64398,1.10101 -4.64899,1.61401c-2.31,1.17999 -4.70602,2.69699 -6.79001,4.30301c-4.58701,3.53598 -8.23801,10.97198 -8.33899,16.07098c-0.01202,0.59201 0.017,1.17001 0.14798,1.74802c0.03601,0.15997 0.11102,0.31097 0.147,0.47098c-0.117,0.85901 0.14401,2.69202 0.29501,3.362c0.42899,-0.03299 0.45798,-0.035 0.88599,-0.06699c3.98401,-0.68399 7.91101,-1.47501 11.88202,-2.21899c-0.69101,-4.319 0.51797,-8.73203 4.72299,-11.633c0.70099,-0.48401 1.22501,-1.17401 1.992,-1.479c2.56299,-1.02002 4.90799,-1.60703 8.04498,-2.08502c0.099,-0.01498 0.27402,0.04901 0.29501,0.13501c0.944,3.86301 1.707,7.75601 2.58301,11.63199c6.38397,-1.14899 6.383,-1.13599 12.767,-2.28598c-0.84702,-3.91299 -1.73001,-7.84201 -2.509,-11.767c-0.017,-0.086 0.04999,-0.18002 0.147,-0.202c1.69299,-0.37701 3.37399,-0.67902 5.09299,-0.94101c0.746,-0.11401 2.612,-0.159 3.54199,0c6.22202,1.06299 9.84399,4.29099 11.36502,9.48099c6.38397,-1.14899 6.383,-1.13699 12.767,-2.28598c-1.12003,-7.17401 -8.27402,-14.95801 -16.38303,-17.21402c-1.32098,-0.367 -2.991,-0.48798 -4.28,-0.87399c-1.94699,-0.582 -3.58798,-0.28699 -5.60898,-0.40298c-0.405,-0.02402 -2.57202,-0.26001 -3.10001,0.13397c-1.133,0.84601 -1.733,2.22101 -2.65701,3.22803c-0.495,0.53998 -1.15198,0.85699 -1.771,1.20999c3.67102,-3.061 6.259,-6.565 5.60901,-11.16202c-0.245,-1.73499 -0.64801,-3.15399 -1.255,-4.707c-0.27301,-0.69998 -2.36301,-2.547 -2.36099,-3.09299c0.00299,-0.75101 0.504,-1.61099 0.664,-2.353c0.366,-1.69601 -0.01801,-3.88901 -0.517,-5.51401c-0.46201,-1.50699 -1.29102,-2.72299 -2.06601,-4.034c-0.202,-0.34201 -1.06,-0.68298 -1.03299,-1.14401c0.09799,-1.66699 0.80499,-3.396 0.81198,-5.10999c0.00702,-1.724 -1.03299,-3.20401 -1.40298,-4.841c-0.08099,-0.35999 1.896,-2.86801 2.21399,-3.698c0.87701,-2.28299 1.99402,-7.19501 0.73801,-9.48099c3.74899,-1.36801 7.27701,-5.53 7.74899,-8.742c0.14001,-0.952 0.14099,-1.854 -0.073,-2.82401c-1.526,-6.91101 -3.05099,-13.79901 -4.57599,-20.70999c-0.013,-0.06 -0.06,-0.14102 -0.07401,-0.202c-2.147,-9.509 -4.245,-18.99301 -6.642,-28.64401c-0.02301,0.004 -0.05002,-0.005 -0.07401,0c0.70599,-0.60101 -1.06799,-2.76801 -0.147,-2.95901c3.155,-0.65298 6.27701,-1.22098 9.44601,-1.81497c2.647,-0.496 5.31699,-1.013 7.97098,-1.48001c5.582,-0.98001 9.40601,8.276 14.90701,8.20401c0.07901,-0.00101 0.177,-0.07703 0.22101,-0.13501c2.28799,-2.97 4.543,-5.94901 6.78998,-8.94299c0.065,-0.086 0.11301,-0.405 0,-0.47c-6.20798,-3.61801 -12.46698,-7.16501 -18.745,-10.69202c-0.05899,-0.03299 -0.15198,-0.01199 -0.22098,0c-9.16702,1.68701 -18.34802,3.48401 -27.52802,5.11099c-0.133,0.02301 -0.306,-0.267 -0.36899,-0.336c-0.673,-0.75 -1.53702,-1.258 -2.36102,-1.81598c0.08401,-0.11002 0.24701,-0.207 0.22101,-0.336c-0.99799,-4.89401 -2.215,-9.77002 -3.24701,-14.659c-0.39297,-1.86002 1.04401,-4.38901 2.95203,-5.44601c0.31,-0.172 1.40698,-0.564 1.62399,-0.60501c17.22598,-3.29199 34.49899,-6.42099 51.733,-9.68298c0.85199,-0.16101 4.117,-5.06 4.871,-6.052c1.35699,-1.785 2.77499,-3.526 4.13199,-5.312c0.211,-0.27701 0.77399,-0.92101 0.88599,-1.27701c0.082,-0.261 -0.41599,-0.41299 -0.517,-0.47099c-3.21597,-1.858 -6.46597,-3.70401 -9.66699,-5.58101c-0.34601,-0.203 0.08099,-0.47899 -0.81198,-0.067z',
            `bird` = 'path://m438.16,457.97501c-10.96201,-0.40601 -20.79001,-5.285 -27.59399,-13.823c-2.26801,-2.84601 -5.29202,-4.47202 -8.694,-4.47202c-3.40201,0 -6.42599,1.62601 -8.694,4.47202c-6.80502,8.944 -17.38901,13.823 -28.729,13.823c-3.02402,0 -5.67001,-0.40601 -8.31601,-0.81302l-65.77301,-97.983c-7.18198,-10.56998 -17.00998,-17.48199 -28.34998,-20.32797l0,-44.72202l26.45999,0c32.508,0 62.74899,-19.922 77.491,-50.821c27.97299,-15.45 47.25101,-47.162 47.25101,-83.34599c0,-6.912 -4.914,-12.19701 -11.34,-12.19701l-37.80099,0l-102.061,0l0,-69.1166c0,-29.2728 -21.925,-52.8537 -49.14101,-52.8537c-27.21701,0 -49.14101,23.5809 -49.14101,52.8537l0,8.1313l-45.361,0c-6.42599,0 -11.34,5.2854 -11.34,12.197l0,4.0653c0,6.912 4.914,12.197 11.34,12.197c3.402,0 6.426,-1.626 8.316,-4.06499l37.045,0l0,89.44399c0,47.569 32.886,86.59901 75.601,92.69801l0,45.12799c-11.34,2.84601 -21.54599,10.16501 -28.34999,20.32901l-66.151,98.38898c-1.89,0.40701 -3.78,0.40701 -5.67,0.40701c-11.341,0 -21.925,-4.879 -28.729,-13.82401c-2.268,-2.84601 -5.292,-4.47198 -8.694,-4.47198c-3.4021,0 -6.4261,1.62598 -8.6941,4.47198c-6.8041,8.94501 -17.3883,13.82401 -28.7285,13.82401c-11.3402,0 -21.9243,-4.879 -28.7284,-13.82401c-4.1581,-5.285 -11.3402,-5.69199 -15.8763,-1.21899c-4.9141,4.47198 -5.2921,12.19699 -1.134,17.07501c11.3402,14.22998 27.9724,22.362 46.1167,22.362c13.9862,0 26.8384,-4.879 37.4226,-13.41702c10.584,8.944 23.436,13.41702 37.423,13.41702c13.98601,0 26.838,-4.879 37.422,-13.41702c10.58401,8.944 23.43701,13.41702 37.423,13.41702c13.608,0 26.838,-4.879 37.04401,-13.41702c10.58501,8.944 23.81499,14.23001 37.80101,14.23001c0.37799,0 0.37799,0 0.75598,0c13.98599,0 27.59399,-5.28601 38.17902,-14.23001c0,0 0.37799,0 0.37799,0.40601c0.37799,0.40701 0.75601,0.40701 1.134,0.814c1.134,0.81302 2.646,2.03201 3.78,2.845c0.37799,0.40701 1.134,0.814 1.51199,1.22c1.134,0.81302 2.646,1.62601 3.78,2.03302c0.37799,0.40698 1.134,0.40698 1.51199,0.81299c1.89001,0.81299 3.40201,1.62601 5.29202,2.44c0.37799,0 0.75598,0 0.75598,0.40601c1.51199,0.40698 3.02402,0.81299 4.914,1.22c0.75601,0 1.134,0.40598 1.89001,0.40598c1.51199,0.40701 2.646,0.40701 4.15799,0.81403c0.75601,0 1.134,0 1.89001,0.40598c1.88998,0.40701 4.15799,0.40701 6.04797,0.40701c13.98602,0 26.83902,-4.879 37.423,-13.41699c10.20602,8.53799 22.68002,13.41699 35.91,13.41699l0.37799,0c6.048,0 11.34003,-5.28601 11.34003,-11.79102c-0.75601,-7.31799 -5.67001,-13.00998 -12.09601,-13.00998zm-74.08899,-285.81601l0,0l0,28.459c0,5.692 -0.37802,10.978 -1.51202,16.263c-10.20599,7.72501 -22.67999,12.19701 -36.28799,12.19701c-31.75299,0 -57.83499,-24.80101 -63.12698,-56.91901l100.927,0zm-177.66301,28.459l0,-121.9696c0,-15.8561 11.71899,-28.4597 26.461,-28.4597c14.74199,0 26.45999,12.6036 26.45999,28.4597l0,93.5106c0,51.634 38.93501,93.51001 86.942,93.51001c1.134,0 2.26801,-12.19701 3.78,-12.19701c-11.341,10.16399 -26.08301,16.26299 -41.58099,16.26299l-37.80099,0c-35.53201,0 -64.261,-31.30598 -64.261,-69.11699zm102.43999,258.17c-10.96201,0 -21.54599,-5.285 -28.35098,-13.823l-0.75601,-0.81299c-2.26801,-2.84601 -5.29199,-4.47202 -8.694,-4.47202l0,0c-3.40199,0 -6.42599,1.62601 -8.694,4.47202c-6.804,8.53799 -17.388,13.823 -28.34999,13.823c-11.34001,0 -21.925,-4.879 -28.729,-13.823c-0.756,-0.81302 -1.134,-1.22 -1.89,-2.03302l45.739,-67.897c3.78,-5.69199 9.07201,-9.75699 15.12,-11.78998c0,0 0,0 0.37801,0c7.938,-2.03302 15.87601,2.84601 18.901,10.97699l30.996,84.97299c-1.51199,0 -3.02402,0.40601 -4.53601,0.40601c-1.134,0 -1.134,0 -1.134,0z',
            `reptile` = 'path://m399.78601,82.5471c-40.26001,26.6179 -32.591,77.63589 -57.51401,110.90889c-53.681,77.63602 -155.289,117.56302 -258.8152,128.65399c-21.0886,2.21802 -47.9287,19.96402 -57.5144,44.36401c19.1715,-6.655 49.8458,-2.21899 65.183,8.87201c0,13.30899 -38.3429,26.61798 -21.0886,51.01801c13.42001,8.87299 32.5912,8.87299 51.76321,2.21799c17.254,-13.30899 19.17099,-22.181 26.84,-39.927c82.437,19.96399 139.951,-2.21799 139.951,-2.21799c0,0 5.75198,26.61798 23.00598,39.927c19.17203,11.09097 44.095,8.87299 61.34903,0c17.254,-19.96301 -21.08902,-31.05402 -21.08902,-70.98102c0,-59.89099 15.33801,-102.036 57.51501,-146.39999c13.41998,26.618 51.763,22.18199 67.09998,-2.218c5.75101,-11.091 9.58603,-22.18201 9.58603,-35.491c0,-79.8542 -61.349,-104.2542 -86.272,-88.7269zm47.92899,77.63589c-7.66901,0 -13.41998,-6.65399 -13.41998,-15.52699c0,-8.873 5.75098,-15.52701 13.41998,-15.52701c7.668,0 13.42001,6.65401 13.42001,15.52701c0,8.873 -5.75201,15.52699 -13.42001,15.52699zm-159.12399,-2.218c-15.33701,-33.27299 -57.51401,-77.63609 -147.62001,-48.8c-99.69139,35.491 -97.77429,128.654 -82.43709,150.83601c0,0 -23.0058,11.091 -9.5857,33.27298c11.5028,15.52701 72.8518,4.436 126.5318,-15.52698c53.68001,-17.746 99.69099,-46.58202 124.614,-68.76401c23.00601,-19.964 13.42001,-55.45399 -11.50299,-51.01801z',
            `detritus` = 'path://m421.38,72.426c-46.56,-46.64 -108.52002,-72.356 -174.64401,-72.42c-135.93199,0 -246.61999,110.572 -246.73599,246.5c-0.064,65.916 25.548,127.90401 72.1,174.55998c46.568,46.62802 108.284,72.436 174.19601,72.436l0.57199,0l0,-0.02399c134.95601,0 246.53999,-110.59601 246.64,-246.51602c0.064,-65.91197 -25.58398,-127.89198 -72.12799,-174.53597zm-163.67999,304.7c-2.836,2.86401 -6.8,4.504 -10.87201,4.504c-4.088,-0.008 -8.064,-1.65601 -10.93199,-4.56c-2.84801,-2.82401 -4.48401,-6.79199 -4.48,-10.87601c0.008,-4.07199 1.664,-8.064 4.532,-10.92398c2.856,-2.84802 7.064,-4.48801 10.92,-4.48801c4.06,0 8.028,1.64801 10.85999,4.504c2.89603,2.92001 4.556,6.91599 4.548,10.93201c-0.004,4.03198 -1.672,8.00397 -4.57599,10.90799zm7.42398,-94.452c-1.76001,0.388 -3.01999,1.948 -3.02402,3.75198l-0.01999,18.12003c-0.008,8.48798 -6.916,15.40799 -15.43599,15.40799c-8.51201,-0.008 -15.412,-6.94 -15.40401,-15.436l0.036,-34.96399c0.00801,-8.48401 6.916,-15.08 15.416,-15.08l0.06801,0c29.48799,0 53.49998,-24.32001 53.532,-53.808c0.01199,-14.28801 -5.53601,-27.884 -15.64001,-38.024c-10.13998,-10.132 -23.56799,-15.78801 -37.88397,-15.804c-29.49202,0 -53.51201,23.95599 -53.54401,53.464c-0.008,8.49199 -6.924,15.38 -15.44,15.38c-4.12,0 -7.996,-1.62401 -10.89999,-4.54401c-2.916,-2.912 -4.508,-6.78799 -4.504,-10.90401c0.04399,-46.492 37.896,-84.32399 84.448,-84.32399c46.53198,0.048 84.34399,37.936 84.29999,84.46001c-0.03198,39.17198 -27.78,73.78796 -66.004,82.30399z',
            `unidentified` = 'path://m421.38,72.426c-46.56,-46.64 -108.52002,-72.356 -174.64401,-72.42c-135.93199,0 -246.61999,110.572 -246.73599,246.5c-0.064,65.916 25.548,127.90401 72.1,174.55998c46.568,46.62802 108.284,72.436 174.19601,72.436l0.57199,0l0,-0.02399c134.95601,0 246.53999,-110.59601 246.64,-246.51602c0.064,-65.91197 -25.58398,-127.89198 -72.12799,-174.53597zm-163.67999,304.7c-2.836,2.86401 -6.8,4.504 -10.87201,4.504c-4.088,-0.008 -8.064,-1.65601 -10.93199,-4.56c-2.84801,-2.82401 -4.48401,-6.79199 -4.48,-10.87601c0.008,-4.07199 1.664,-8.064 4.532,-10.92398c2.856,-2.84802 7.064,-4.48801 10.92,-4.48801c4.06,0 8.028,1.64801 10.85999,4.504c2.89603,2.92001 4.556,6.91599 4.548,10.93201c-0.004,4.03198 -1.672,8.00397 -4.57599,10.90799zm7.42398,-94.452c-1.76001,0.388 -3.01999,1.948 -3.02402,3.75198l-0.01999,18.12003c-0.008,8.48798 -6.916,15.40799 -15.43599,15.40799c-8.51201,-0.008 -15.412,-6.94 -15.40401,-15.436l0.036,-34.96399c0.00801,-8.48401 6.916,-15.08 15.416,-15.08l0.06801,0c29.48799,0 53.49998,-24.32001 53.532,-53.808c0.01199,-14.28801 -5.53601,-27.884 -15.64001,-38.024c-10.13998,-10.132 -23.56799,-15.78801 -37.88397,-15.804c-29.49202,0 -53.51201,23.95599 -53.54401,53.464c-0.008,8.49199 -6.924,15.38 -15.44,15.38c-4.12,0 -7.996,-1.62401 -10.89999,-4.54401c-2.916,-2.912 -4.508,-6.78799 -4.504,-10.90401c0.04399,-46.492 37.896,-84.32399 84.448,-84.32399c46.53198,0.048 84.34399,37.936 84.29999,84.46001c-0.03198,39.17198 -27.78,73.78796 -66.004,82.30399z',
            `invertebrate` = 'path://m76.6852,324.99301c0,-102.28601 54.3028,-144.78801 78.6318,-144.78801c13.90199,0 17.92799,94.744 177.425,94.744c34.42499,0 53.12399,-18.94901 58.47101,-18.94901c5.77197,0 15.72699,19.59299 15.72699,62.45499c0,115.19 -148.61499,120.32501 -172.09401,120.57101c-49.03499,0.53101 -47.85599,44.35999 -76.17899,44.35999c-14.53101,0 -81.9818,-74.33698 -81.9818,-158.39297zm110.0848,-163.73701c0,11.123 37.649,75.795 131.45699,75.795c36.89401,0 88.71301,-24.93599 88.71301,-59.53699c0,-15.67101 -3.38199,-25.73201 -7.974,-25.73201c-3.271,0 -20.177,9.474 -41.832,9.474c-67.35599,0 -71.93301,-56.84599 -76.00601,-56.84599c-38.78099,0 -94.35799,45.72299 -94.35799,56.84599zm220.17,-113.69279c0,-7.8448 -4.45099,-18.9488 -15.72699,-18.9488c-11.276,0 -14.24802,19.6878 -19.61102,27.4c-8.052,-1.6486 -16.76398,3.6571 -20.41299,12.4683c-0.534,1.3075 -1.022,2.72861 -2.013,3.5624c-1.336,1.118 -3.11301,0.7769 -4.733,0.56841c-11.52798,-1.4401 -31.862,7.5038 -31.862,12.8473c0,5.3436 1.62,37.8972 59.17902,37.8972c13.634,0 35.17999,-5.229 35.17999,-13.832c0,-4.794 0,-54.118 0,-61.9628z'
          )

          #Create a new column 'classified_column' based on the mapping from the classification list
          class = classification_list[match(qw, names(classification_list))]

          class <- data.frame(class)
          class = class %>% gather('name', 'path', 1:length(data2$category))
          qw2 = class$path


          # emojis
          classification_list2 <- list(
            `mammal` =  'path://m115.089,80.352c-19.93079,-0.4459 -42.68719,8.2031 -42.68719,20.219c0,21.361 35.9702,10.67 47.9692,32.03101c0.268,0.478 0.544,0.72 0.812,1.125c2.614,23.23399 11.959,52.28099 23.188,52.28099c11.233,0 20.60899,-29.073 23.218,-52.312c0.25999,-0.394 0.521,-0.631 0.782,-1.09399c11.998,-21.36101 48,-10.67001 48,-32.03101c0,-21.3614 -72,-32.042 -72,0c0,-14.0185 -13.78,-19.8722 -29.28201,-20.219zm360.93801,34.40601c-8.43701,0.501 -28.69101,20.521 -55.68802,28.531c-35.995,10.681 -83.96698,-21.361 -71.96799,0c11.064,19.69901 32.36801,48.42101 73.25,52.782c-3.27301,19.08 2.28201,42.03799 -25.28201,64.718c-24.09299,19.83398 -36.25198,13.96799 -95.96799,-21.40601c-35.996,-21.31799 -84.009,-42.687 -156,-42.687c-86.1498,0 -95.9692,52.61501 -95.9692,117.50002c0,28.41699 1.8916,54.46298 11.25,74.78098c0.0355,0.077 0.0893,0.142 0.125,0.21902c1.3751,2.961 2.9128,5.79498 4.625,8.5c0.6395,1.01099 1.40369,1.93298 2.0937,2.90598c1.2682,1.78802 2.553,3.564 4,5.21902c0.8195,0.93698 1.7453,1.79398 2.625,2.68698c1.4597,1.48199 2.9609,2.927 4.5938,4.28101c1.09019,0.905 2.26649,1.74799 3.4375,2.59399c1.7047,1.23199 3.492,2.397 5.375,3.5c1.2331,0.72299 2.4998,1.42801 3.8125,2.09399c2.0739,1.052 4.28239,2.00101 6.5625,2.90601c1.4617,0.58002 2.9191,1.17001 4.4692,1.68802c2.388,0.79797 4.958,1.47897 7.562,2.125c1.626,0.40198 3.193,0.84598 4.906,1.18698c3.011,0.60101 6.273,1.03201 9.563,1.43802c1.618,0.19897 3.125,0.474 4.812,0.625c5.08499,0.45499 10.41299,0.71799 16.157,0.71799c35.647,0.00101 127.55099,-0.31201 156,-0.31201c23.99701,0 62.888,-7.09998 95.96799,-31.71899c3.83301,-2.85199 7.38702,-5.92801 10.81302,-9.09399c1.272,-1.16501 2.49799,-2.358 3.71899,-3.56201c1.802,-1.798 3.53299,-3.65198 5.21799,-5.53098c22.86301,-25.108 35.854,-57.039 40.28201,-88.625c-0.02899,0.06299 -0.06601,0.12399 -0.09399,0.18698c6.84198,-39.457 2.97998,-77.679 -4.625,-99.937c29.62,-12.205 28.68698,-53.05499 28.68698,-71.125c0,-5.341 -1.5,-7.355 -4.31198,-7.188zm-374.90601,184.87499c9.118,0 16.5,7.802 16.5,17.43802c0,9.63599 -7.382,17.43698 -16.5,17.43698c-9.1191,0 -16.5317,-7.80099 -16.5317,-17.43698c0,-9.63602 7.4125,-17.43802 16.5317,-17.43802z',
            # Whale emoji: 🐋
            `fish` = 'path://m205.188,80.7812c-16.78,0.00011 -33.24001,30.4448 -36.84401,64.40681c-73.35699,19.08099 -110.96899,81.035 -111.09399,129.812c3.2441,3.03201 11.5988,8.65201 21.6875,15.18799c27.0765,17.539 68.1205,42.75803 67.59351,50.46802c-0.72301,10.58301 -28.394,-1.121 -38.687,-3.56201c-13.1782,-3.11301 -19.5259,-5.58798 -24.0002,-6.46899c-1.8088,-0.35599 -3.397,-0.51501 -4.875,-0.25c-10.4677,4.103 -6.9193,15.35199 -3.0313,21.78101c18.6673,33.35901 90.79449,59.59399 151.53149,59.59399c7.91901,0 15.81601,-0.73801 23.68701,-1.78101c19.91,12.02402 45.789,21.25 71.81299,21.25c22.51501,0 4.733,-18.909 -9.375,-39.31299c26.276,-11.57901 50.367,-27.004 70.125,-43.375c24.564,37.49298 63.78302,66.25 91.09302,66.25c18.97897,0 37.948,-17.92801 18.96899,-37.40601c-18.979,-19.453 -37.96899,-70.25 -37.96899,-95.81299c0,-12.78101 18.978,-79.40901 37.96899,-98.87401c18.96698,-19.466 0.00998,-40.46901 -18.96899,-40.46901c-25.48203,0 -61.345,31.856 -86,68.343c-3.70502,-3.093 -7.504,-6.166 -11.53101,-9.218c-35.54901,-74.81599 -123.078,-120.56269 -172.093,-120.5628zm-62.813,111.3128c13.757,0 24.938,11.42601 24.937,25.56201c0,14.123 -11.17999,25.56299 -24.937,25.56299c-13.77,0 -24.937,-11.452 -24.937,-25.56299c0,-14.136 11.16699,-25.56201 24.937,-25.56201z',
            # Fish emoji: 🐟
            `primary producer` = 'path://m159.25,40.6562c-24.94501,21.2956 -35.47,49.4967 -34.125,77.1558c0.126,2.633 0.598,5.228 0.937,7.844c0.26,1.989 0.339,3.99599 0.719,5.969c0.868,4.50999 2.04501,8.996 3.531,13.375c1.424,4.198 3.076,8.019 4.907,11.625c0.063,0.12399 0.09201,0.282 0.15601,0.40601c0.02699,0.05299 0.06599,0.10399 0.09399,0.157c0.931,1.797 1.92601,3.545 2.96901,5.218c0.043,0.071 0.08,0.14899 0.12399,0.21899c1.035,1.647 2.134,3.241 3.282,4.78101c2.071,2.78099 4.442,5.31499 6.90601,7.81299c0.392,0.39801 0.69099,0.858 1.09399,1.25c1.748,1.701 3.80101,3.26801 5.75,4.875c1.39801,1.15201 2.651,2.38301 4.15601,3.5c1.40199,1.039 3.065,2.01401 4.562,3.03101c2.30901,1.56799 4.55,3.179 7.09401,4.71899c2.69499,1.62901 5.74599,3.272 8.71899,4.90601c1.41,0.77499 2.651,1.562 4.125,2.34399c5.771,3.061 13.097,6.52701 19.90601,9.84401c4.381,2.133 7.946,4.026 12.782,6.343l0,-0.03101c0.383,0.18401 0.644,0.315 1.03099,0.5c-28.61899,25.597 -51.97299,49.418 -71,71.375c3.01901,-29.38699 3.09801,-46.612 -13.25,-64.53101c-18.298,-20.05299 -47.74369,-31.87599 -79.18779,-25.43799c-0.247,0.49699 -0.3609,1.002 -0.5937,1.5c-0.0053,-0.00401 -0.0259,0.00499 -0.0313,0c-0.1405,0.30099 -0.2083,0.605 -0.3437,0.90599c-1.3185,2.93201 -2.4697,5.858 -3.3125,8.813c-0.0777,0.271 -0.1136,0.541 -0.1875,0.813c-0.8244,3.04399 -1.4639,6.086 -1.8125,9.12399c-0.0024,0.021 0.0024,0.04201 0,0.063c-1.1121,9.782 0.1117,19.466 3.3438,28.53101c0.2314,0.653 0.5922,1.25999 0.8437,1.90599c0.9142,2.338 1.8339,4.66501 3,6.907c0.6007,1.159 1.366,2.245 2.0313,3.375c1.0156,1.72101 1.9671,3.478 3.125,5.125c1.8886,2.69 3.9429,5.25601 6.1874,7.71899c9.15591,10.026 18.8129,15.50201 31.25,18.90601c3.1098,0.85101 6.38181,1.55301 9.8748,2.18701c8.62,1.565 19.165,2.59 30.87501,3.65698c-58.5201,70.431 -72.36211,120.69302 -76.93721,147.53101c-1.2299,7.18802 9.3944,16.25702 17.375,17.375c7.99419,1.08099 24.28719,-4.84299 25.5312,-12.03198c2.92,-17.18402 10.168,-47.13202 30.812,-86.46802c32.181,33.46201 48.39801,50.207 83.157,52.5c34.87401,2.24802 70.96802,-11.142 90.90601,-41.34399c-0.01599,-0.034 -0.047,-0.06 -0.06299,-0.09399c-0.892,-1.939 -1.85202,-3.82101 -2.87402,-5.65601c-0.04498,-0.08099 -0.07999,-0.16901 -0.12598,-0.25c-1.05801,-1.88599 -2.186,-3.72501 -3.37402,-5.5c-0.017,-0.02399 -0.047,-0.03799 -0.06299,-0.06201c-1.19,-1.77399 -2.439,-3.526 -3.75,-5.18799c-0.01801,-0.02301 -0.04401,-0.039 -0.06299,-0.06201c-1.311,-1.65997 -2.668,-3.26498 -4.09302,-4.81299c-0.01999,-0.022 -0.043,-0.04099 -0.06299,-0.06299c-2.87701,-3.11801 -5.96402,-5.996 -9.25,-8.65601c-6.62201,-5.358 -14.03201,-9.78302 -21.90601,-13.25c-11.783,-5.18802 -24.65601,-8.241 -37.71899,-9.09399c-4.27,-0.27402 -8.304,-0.289 -12.15601,-0.06201c-1.62399,0.095 -3.12199,0.41101 -4.687,0.59399c-2.243,0.263 -4.541,0.43201 -6.688,0.875c-1.466,0.30099 -2.849,0.83401 -4.28101,1.21899c-2.01599,0.54102 -4.06099,1.01401 -6.03099,1.71802c-1.82401,0.65201 -3.632,1.52298 -5.438,2.31299c-1.612,0.70502 -3.231,1.311 -4.84399,2.125c-1.86101,0.94 -3.77301,2.103 -5.65601,3.18701c-1.513,0.871 -3.024,1.63199 -4.562,2.59399c-2.942,1.841 -5.996,3.952 -9.09401,6.125c-0.41199,0.289 -0.804,0.51801 -1.21899,0.81201c-5.35699,3.79999 -11.58501,8.65298 -17.75,13.40698c-2.229,1.71899 -4.037,2.97202 -6.40601,4.81201c0.017,-0.00101 0.04501,0.00198 0.06201,0c-0.61601,0.479 -1.061,0.79498 -1.68701,1.28101c16.718,-31.733 42.283,-69.54602 81.59401,-111.96802c30.33699,34.79501 47.01399,52.76001 82.718,56.68701c36.87799,4.01498 75.965,-8.423 99,-39.40601c0.082,-0.12299 0.19998,-0.22101 0.28198,-0.34399c-13.97998,-35.30101 -48.68597,-55.983 -85.71899,-60.06201c-4.474,-0.48999 -8.711,-0.679 -12.78101,-0.625c-1.57397,0.01901 -3.03699,0.24501 -4.56299,0.34401c-2.47198,0.162 -4.96899,0.257 -7.34399,0.62399c-1.668,0.257 -3.27301,0.73801 -4.90601,1.09401c-2.05301,0.45 -4.13901,0.83299 -6.15601,1.43799c-2.01401,0.60301 -4.03101,1.40001 -6.03101,2.15601c-1.59,0.601 -3.189,1.149 -4.78198,1.84399c-2.19699,0.959 -4.457,2.11301 -6.68701,3.25c-1.44098,0.73401 -2.88,1.44301 -4.34399,2.25c-2.325,1.283 -4.77699,2.72301 -7.187,4.18701c-1.30301,0.791 -2.63501,1.595 -3.96901,2.43799c-3.77699,2.388 -8.29599,5.483 -12.407,8.28101c25.15401,-25.59399 55.058,-52.614 91.157,-80.875c2.784,-2.18401 5.44,-4.649 7.125,-7.21899c1.58401,0.573 3.06302,1.07999 4.59399,1.625c4.979,1.77499 10.54602,3.82999 15.03101,5.28099c1.785,0.57701 3.46701,1.04201 5.18701,1.563c2.81598,0.854 5.67801,1.744 8.34399,2.437c0.61099,0.159 1.177,0.257 1.78101,0.407c7.68799,1.91 14.89099,3.175 21.90698,3.5c0.02002,0.00101 0.04202,-0.00099 0.06201,0c7.52399,0.34201 14.91901,-0.314 22.625,-2.157c3.854,-0.91899 7.79401,-2.12 11.875,-3.65599c4.16299,-1.57501 8.21399,-3.37401 12.125,-5.40601c27.32101,-14.17599 47.71201,-39.192 50.03101,-70.8438c-30.52802,-23.616 -70.73801,-25.9827 -104,-13.43739c-31.07901,11.7597 -41.742,31.7836 -58.75,68.9692c-3.24301,0.744 -6.621,2.767 -9.78101,5.093c-35.27399,25.85599 -65.123,50.22099 -91.09399,73.28099c25.95399,-43.84999 38.905,-66.912 27.25,-101.312c-11.97101,-35.3012 -43.576,-65.2006 -88.78101,-72.0938z',
            # Herb emoji: 🌿
            `bird` = 'path://m146.88901,185.386c-1.33301,20.91 21.23499,39.567 -8.552,37.453c-29.786,-2.114 -94.11541,-32.061 -93.29871,-44.68001c0.8168,-12.62 44.5357,-34.897 74.3227,-32.78299c29.786,2.101 28.87299,19.08699 27.52801,40.00999zm241.67899,203.13899c-2.42599,-0.405 -4.70801,0.19 -6.77399,1.202c-27.92502,2.93701 -38.73401,-23.85898 -38.73401,-23.85898c-5.27301,-4.25302 -11.78299,-25.42902 -19.08499,-15.379l2.246,17.74597c2.246,17.746 30.867,40.80701 30.867,40.80701l-14.59302,20.11301c-4.035,5.55701 -3.026,13.49301 2.246,17.746c5.27301,4.25299 12.80402,3.189 16.83899,-2.367l8.08301,-11.13901l-0.46799,3.15201c-1.04501,6.91101 3.423,13.392 9.98099,14.49301c6.55801,1.10098 12.707,-3.608 13.75201,-10.51901l5.64499,-37.50299c1.021,-6.91101 -3.44699,-13.392 -10.005,-14.49301zm-75.40298,7.88501c-2.354,-0.73401 -4.68402,-0.46802 -6.87,0.228c-28.04501,-1.03799 -35.35901,-29.112 -35.35901,-29.112c-4.685,-4.96201 -8.444,-26.87201 -16.96001,-17.935l-0.036,17.897c-0.036,17.89798 25.40298,44.79498 25.40298,44.79498l-17.01898,17.87201c-4.70801,4.936 -4.72,12.94901 -0.03601,17.89801c4.68399,4.961 12.28702,4.974 16.983,0.03799l9.42801,-9.89902l-0.87601,3.06403c-1.91,6.69498 1.69299,13.746 8.047,15.771c6.353,2.01199 13.05499,-1.785 14.965,-8.48102l10.353,-36.36499c1.94601,-6.70801 -1.65698,-13.758 -8.02298,-15.771zm147.11899,-288.88c-4.60001,-2.152 -9.104,-0.721 -12.61099,3.089c-0.64902,0.708 -50.745,79.817 -174.539,62.578c-4.08401,-0.57001 37.70099,151.48399 38.422,151.408c1.48901,-0.177 36.87299,-4.65802 73.745,-32.315c33.84702,-25.37802 75.47601,-75.83 81.63699,-172.11501c0.336,-5.291 -2.05399,-10.48 -6.65399,-12.645zm-6.38901,182.00101c-2.45099,-4.25299 -7.08698,-7.08801 -11.759,-5.96201c-15.53,3.73401 -38.39798,6.87299 -54.40799,5.73401c-76.35199,-5.41702 -112.43298,-52.26201 -112.80499,-52.65501c-3.30301,-3.569 5.59698,146.21901 9.80099,146.52299c110.42599,7.84702 166.492,-76.28699 168.83401,-79.86899c2.66699,-4.12601 2.79898,-9.505 0.33698,-13.771zm-118.798,-26.479c-4.45599,69.742 15.80603,124.815 -50.37299,120.10599c-66.179,-4.69598 -121.849,-62.27399 -117.39301,-132.02899c4.45601,-69.756 172.23401,-57.81999 167.76599,11.923zm-15.96298,-83.59c-4.23901,66.26199 -47.10501,117.16998 -109.96901,112.702c-62.87599,-4.46799 -110.41479,-61.79401 -106.175,-128.05501c4.24001,-66.2618 58.036,-106.87949 120.91199,-102.41139c48.054,3.4048 98.968,59.2744 95.23201,117.7644zm-175.2,-43.326c0,-13.981 10.75499,-25.315 24.02199,-25.315c13.26601,0 24.02101,11.334 24.02101,25.315c0,13.981 -10.755,25.315 -24.02101,25.315c-13.267,0 -24.02199,-11.334 -24.02199,-25.315zm114.21001,96.905c0,0 91.642,71.489 148.77698,-56.439c4.75601,-10.658 20.23801,10.037 1.189,52.67999c-19.04898,42.64299 -98.18799,81.51399 -144.60898,19.442c-9.789,-13.101 -5.35699,-15.683 -5.35699,-15.683zm-34.25401,-171.3561c0,0 75.01799,3.215 93.65901,-6.0375c18.64099,-9.2526 1.634,37.1115 -39.17902,47.9586c-40.812,10.848 -54.48,-41.9211 -54.48,-41.9211zm25.23399,33.9346c0,0 54.06,1.7214 72.71301,-7.5185c18.65298,-9.2399 1.633,37.112 -39.17902,47.959c-40.82399,10.847 -33.534,-40.4405 -33.534,-40.4405z',
            # Bird emoji: 🐦
            `reptile` = 'path://m175.714,126.065c-8.83501,0 -28.20201,25.733 -43.83301,11.806c-5.407,-4.808 22.341,-14.663 21.222,-23.141c-0.92099,-6.964 -34.923,-17.43871 -23.03999,-24.0815c11.882,-6.6312 29.713,9.6485 43.16899,9.9355c29.27101,0.631 51.759,-9.7863 52.078,-9.9355c6.649,-3.1435 14.685,-0.5965 17.991,5.6905c3.31801,6.276 0.627,13.917 -5.99699,17.049c-1.61,0.757 -27.342,12.677 -61.59,12.677zm196.34499,325.43701c-48.74799,0 -100.54398,-33.40903 -100.54398,-95.31601c0,-15.76401 -10.93701,-19.056 -20.11601,-19.056c-9.16701,0 -20.104,3.29199 -20.104,19.056c0,61.90698 -51.808,95.31601 -100.54399,95.31601c-48.7364,0 -100.53241,-31.78003 -100.53241,-95.31601c0,-152.496 174.2754,-173.54901 174.2754,-152.496c0,21.052 -93.83501,-12.701 -93.83501,139.79599c0,25.41202 10.937,31.76801 20.104,31.76801c9.179,0 20.116,-3.293 20.116,-19.056c0,-61.896 51.79601,-95.31601 100.545,-95.31601c48.73601,0 100.54399,33.40802 100.54399,95.31601c0,15.763 10.93701,19.056 20.11603,19.056c9.17999,0 20.10397,-3.293 20.10397,-19.056l0,-190.632c0,-44.228 -41.98999,-50.83599 -67.021,-50.83599c0,0 -40.20798,12.712 -80.42799,12.712c-40.22099,0 -53.627,-29.7836 -53.627,-50.8361c-0.02499,-21.0526 53.60201,-38.1241 134.03,-38.1241c80.44,0 147.46201,51.0654 147.46201,127.08419l0,190.62001c0,61.90698 -51.80801,95.31601 -100.54501,95.31601zm-120.64799,-378.60191c0,-6.3362 5.502,-11.4727 12.28902,-11.4727c6.78598,0 12.28799,5.13651 12.28799,11.4727c0,6.3363 -5.50201,11.4728 -12.28799,11.4728c-6.78702,0 -12.28902,-5.13651 -12.28902,-11.4728z',
            `detritus` = 'path://m452.76999,302.44199c4.13501,-17.08398 2.76001,-35.35797 -5.203,-53.54599c-7.70297,-17.592 -20.98297,-31.504 -37.15997,-40.847c3.61298,-12.905 2.65799,-26.795 -3.681,-40.59799c-9.55402,-20.78601 -30.21802,-34.65401 -53.52902,-38.563c2.82901,-6.192 3.737,-13.954 0.409,-23.46c-11.35999,-32.4782 -56.802,-10.8259 -90.88199,-54.1196c-27.71899,15.8495 -33.74001,39.4071 -32.69499,59.4026c-27.50301,4.461 -43.16901,10.134 -43.16901,10.134l0,0.021c-15.45,5.955 -26.379,20.386 -26.379,37.26401c0,9.51599 3.61299,18.144 9.40599,25.03l-7.86099,2.793l0.01199,0.032c-26.47,9.42999 -45.158,32.21899 -45.158,58.884c0,11.33501 3.409,21.94398 9.316,31.157c-32.0702,13.73901 -54.4613,43.55399 -54.4613,78.40298c0,47.83002 41.9303,86.60901 93.6543,86.60901c37.13699,0 74.51199,-7.61099 108.27499,-18.02499c25.48099,11.259 64.69598,18.02499 123.73599,18.02499c46.009,0 83.30499,-35.54199 83.30499,-79.388c0,-23.55798 -10.827,-44.65799 -27.935,-59.20801zm-267.43298,-83.33899c0,-26.90599 17.802,-48.718 39.761,-48.718c21.95999,0 39.761,21.81201 39.761,48.718c0,26.905 -17.80101,48.71701 -39.761,48.71701c-21.959,0 -39.761,-21.81201 -39.761,-48.71701zm113.603,0c0,-26.90599 17.802,-48.718 39.76099,-48.718c21.95901,0 39.76102,21.81201 39.76102,48.718c0,26.905 -17.802,48.71701 -39.76102,48.71701c-21.95898,0 -39.76099,-21.81201 -39.76099,-48.71701zm-90.882,0c0,-14.948 10.172,-27.06599 22.72101,-27.06599c12.54799,0 22.71999,12.118 22.71999,27.06599c0,14.94701 -10.172,27.065 -22.71999,27.065c-12.54901,0 -22.72101,-12.118 -22.72101,-27.065zm102.24199,0c0,-14.948 10.173,-27.06599 22.72101,-27.06599c12.548,0 22.72101,12.118 22.72101,27.06599c0,14.94701 -10.173,27.065 -22.72101,27.065c-12.548,0 -22.72101,-12.118 -22.72101,-27.065zm-131.245,101.711c-2.79399,-5.33701 0.03401,-9.689 6.28201,-9.689l204.48499,0c6.24802,0 9.077,4.35199 6.28302,9.689c0,0 -29.00302,55.267 -108.52502,55.267c-79.52199,0 -108.52499,-55.267 -108.52499,-55.267zm108.52499,11.96301c-31.47897,0 -58.58499,9.98099 -71.47899,24.42398c16.95,10.33801 40.27199,18.88 71.47899,18.88c31.207,0 54.54102,-8.54199 71.479,-18.88c-12.89398,-14.44299 -40,-24.42398 -71.479,-24.42398z',
            # Leaf emoji: 🍂
            `unidentified` = 'path://m258.09399,90.625c-77.72499,0 -143.40599,44.38 -143.40599,96.90601c0,17.84299 19.237,32.28099 43,32.28099c23.76199,0 43.03099,-14.438 43.03099,-32.28099c0,-10.76801 22.37001,-32.31201 57.375,-32.31201c43.021,0 71.68701,21.526 71.68701,43.06201c0,43.07199 -77.384,53.77899 -86.03101,53.84399c-23.76199,0 -43.03101,14.47 -43.03101,32.31299l0,43.06201c0,17.84201 19.26901,32.31201 43.03101,32.31201c23.76199,0.00098 43,-14.47 43,-32.31201l0,-14.34399c11.42899,-1.72299 24.18701,-4.28302 37.09399,-8.06201c59.31201,-17.30399 91.96802,-51.39899 91.96802,-96.032c0.00098,-54.03299 -42.99503,-118.437 -157.71802,-118.437zm-14.34399,290.71899c-23.75999,0 -43.03101,14.47101 -43.03101,32.31201c0,17.841 19.27101,32.28198 43.03101,32.28198c23.76001,-0.00098 43,-14.44098 43,-32.28198c0,-17.841 -19.23999,-32.31201 -43,-32.31201z',
            `invertebrate` = 'path://m100.844,109.563c-15.63461,-0.87 -21.8029,26.993 -11.969,26.993c13.521,0 20.639,13.31 17.125,34.457c-27.0613,6.286 -54.9375,28.226 -54.9375,43.379c0,21.10901 12.106,21.097 36.3125,31.651c24.207,10.55399 -12.1033,84.44199 0,126.659c8.8112,30.71201 36.296,63.32901 96.813,63.32901l278.37401,0c12.10397,0 24.21899,0.004 24.21899,-10.55002c0,-7.759 -32.716,-21.207 -64.46899,-31.987c20.86899,-14.332 35.672,-34.51398 42.12598,-57.88599c18.51801,-67.15601 -26.70499,-135.457 -100.81299,-152.24901c-89.48001,-20.29599 -180.55901,29.22701 -202.937,110.356c-1.127,4.08301 -0.826,8.16101 0.562,11.86902c-4.354,-6.263 -4.99899,-14.77802 -1.25,-27.86203c6.756,-23.56598 16.39,-57.51599 2.53101,-82.40999c5.45999,-32.88499 16.72699,-63.063 -2.53101,-79.856c-24.207,-21.1084 -36.322,21.1 -24.21899,21.1c15.556,0 22.644,17.548 14.75,44.502c-4.104,-3.336 -8.94,-6.362 -14.75,-8.895c-4.66,-2.032 -9.90001,-2.82899 -15.37501,-2.862c4.315,-22.16699 6.649,-41.671 -7.312,-53.84499c-4.539,-3.958 -8.642,-5.692 -12.25,-5.893z'      # Snail emoji: 🐌
          )


          class2 = classification_list2[match(qw, names(classification_list2))]

          class2 <- data.frame(class2)
          class2 = class2 %>% gather('name', 'path', 1:length(data2$category))
          qw3 = class2$path


        }


        if (input$ch1 == 'Nocturnal or Diurnal') {
          #gpt3 classification
          classify_category <- function(text) {
            prompt <- paste(
              "Please classify the following as Nocturnal, Diurnal or Unidentified:\n\n",
              text,
              "\n\nCategory:"
            )
            response <- gpt3_single_completion(
              prompt_input = prompt,
              temperature = 0.3,
              max_tokens = 3,
              n = 1,
              model = "gpt-3.5-turbo-instruct"
            )
            category <- response[[1]]$gpt3
          }
          qw = sapply(data2$name, classify_category) %>% tolower()

          standardize_word <- function(word) {
            target_words <- c('nocturnal', 'diurnal', 'unidentified')
            distances <- stringdistmatrix(word, target_words, method = 'jw')

            closest_match_index <- which.min(distances)
            closest_match_distance <- distances[closest_match_index]

            other_distances <- distances[-closest_match_index]
            if (closest_match_distance < 10 &&
                all(closest_match_distance < other_distances + 3)) {
              return(target_words[closest_match_index])
            } else {
              return(word)
            }
          }

          qw <- sapply(qw, standardize_word)


          classification_list <- list(
            `nocturnal` = 'path://m58.7766,224.431l12.8893,-7.85899l12.7605,8.12599l-2.3201,-16.95999l10.4565,-11.89401l-14.3072,-2.638l-6.3158,-15.47l-6.50909,15.37401l-14.3555,2.27499l10.2954,12.123l-2.594,16.923zm261.20341,25.144c-34.914,-71.76199 -32.41702,-156.7948 0.07999,-223.7769c-32.09399,-0.0574 -64.62399,9.3885 -94.431,29.8293c-64.22099,44.0365 -98.184,126.02861 -93.802,208.28859c15.226,0.59302 29.629,7.01801 41.23001,18.52902c10.972,-7.24701 23.12,-10.97601 35.784,-10.97601c33.722,0 62.884,26.94202 71.987,64.61099c23.78101,8.70102 40.55301,34.66702 40.55301,65.28101c0,31.97101 -18.64102,58.702 -43.66202,66.293c44.871,12.25702 93.59201,5.37402 136.62701,-24.09198c29.80701,-20.422 52.95898,-49.12302 68.974,-82.16501c-65.12302,-0.134 -128.42599,-40.078 -163.34,-111.82201zm-14.40402,151.74699c0,-25.94699 -16.77298,-47.01898 -38.08798,-49.371c-3.69,-34.763 -28.38901,-61.74298 -58.647,-61.74298c-14.468,0 -27.519,6.32898 -37.83,16.483c-9.683,-14.685 -24.58701,-24.30301 -41.504,-24.30301c-25.27901,0 -46.32121,21.052 -51.58971,49.142c-27.4866,2.27499 -49.2374,29.16 -49.2374,62.37302c0,34.64798 23.6842,62.73798 52.8947,62.73798c6.203,0 12.0999,-1.492 17.6263,-3.82498c9.6351,15.67999 25.1181,25.98599 42.7121,25.98599c10.763,0 20.752,-3.862 29.114,-10.42099c9.53801,10.97598 22.492,17.82098 36.847,17.82098c21.123,0 39.20001,-14.819 47.675,-36.082c2.59401,0.59302 5.252,0.995 8.007,0.995c23.20099,0.01901 42.01999,-22.29599 42.01999,-49.793zm115.311,-123.96298l7.54102,-19.69501l17.93198,-3.767l-13.43698,-14.62801l2.49701,-21.435l-15.83801,10.689l-16.38501,-9.446l3.65701,21.205l-12.63202,15.565l18.09402,2.44801l8.57098,19.064zm-69.345,-91.24701l5.88101,13.05901l5.172,-13.51801l12.293,-2.563l-9.216,-10.019l1.724,-14.685l-10.875,7.304l-11.246,-6.48201l2.513,14.55101l-8.668,10.651l12.422,1.702zm59.22702,-38.817l3.60898,8.03101l3.17401,-8.27901l7.556,-1.60699l-5.655,-6.157l1.03101,-8.987l-6.67001,4.513l-6.84698,-3.996l1.49799,8.91l-5.31699,6.53999l7.621,1.032zm-271.91701,-54.0177l3.60899,8.0307l3.174,-8.2984l7.556,-1.6062l-5.655,-6.157l1.047,-8.9871l-6.67,4.4935l-6.87999,-3.9772l1.53099,8.8914l-5.33299,6.5587l7.621,1.0516z',
            `diurnal` = 'path://m426.62701,415.82101c0,0 -104.83502,-32.737 -163.07703,-32.737c-58.24098,0 -163.07599,32.737 -163.07599,32.737c0,0 34.94501,-109.12201 34.94501,-152.77103c0,-43.64899 -34.94501,-152.77099 -34.94501,-152.77099c0,0 104.83501,32.73701 163.07599,32.73701c58.242,0 163.07703,-32.73701 163.07703,-32.73701c0,0 -34.94501,109.122 -34.94501,152.77099c0,43.64902 34.94501,152.77103 34.94501,152.77103zm-163.09003,-360.11041c0,0 -55.63699,89.73239 -90.59399,122.4684c-34.95599,32.737 -130.71839,84.87498 -130.71839,84.87498c-0.0001,0 89.94939,46.68301 130.71839,84.875c40.76901,38.19302 90.59399,122.43802 90.59399,122.43802c0,0 55.68002,-89.70102 90.625,-122.43802c34.94501,-32.73599 130.71902,-84.875 130.71902,-84.875c0,0 -95.78601,-52.13799 -130.71902,-84.87498c-34.93298,-32.73601 -90.625,-122.4684 -90.625,-122.4684zm0,98.2184c64.33401,0 116.5,48.84599 116.5,109.12498c0,60.27902 -52.16599,109.125 -116.5,109.125c-64.33398,0 -116.46899,-48.84598 -116.46899,-109.125c0,-60.27899 52.13501,-109.12498 116.46899,-109.12498z',
            `unidentified` = 'path://m421.38,72.426c-46.56,-46.64 -108.52002,-72.356 -174.64401,-72.42c-135.93199,0 -246.61999,110.572 -246.73599,246.5c-0.064,65.916 25.548,127.90401 72.1,174.55998c46.568,46.62802 108.284,72.436 174.19601,72.436l0.57199,0l0,-0.02399c134.95601,0 246.53999,-110.59601 246.64,-246.51602c0.064,-65.91197 -25.58398,-127.89198 -72.12799,-174.53597zm-163.67999,304.7c-2.836,2.86401 -6.8,4.504 -10.87201,4.504c-4.088,-0.008 -8.064,-1.65601 -10.93199,-4.56c-2.84801,-2.82401 -4.48401,-6.79199 -4.48,-10.87601c0.008,-4.07199 1.664,-8.064 4.532,-10.92398c2.856,-2.84802 7.064,-4.48801 10.92,-4.48801c4.06,0 8.028,1.64801 10.85999,4.504c2.89603,2.92001 4.556,6.91599 4.548,10.93201c-0.004,4.03198 -1.672,8.00397 -4.57599,10.90799zm7.42398,-94.452c-1.76001,0.388 -3.01999,1.948 -3.02402,3.75198l-0.01999,18.12003c-0.008,8.48798 -6.916,15.40799 -15.43599,15.40799c-8.51201,-0.008 -15.412,-6.94 -15.40401,-15.436l0.036,-34.96399c0.00801,-8.48401 6.916,-15.08 15.416,-15.08l0.06801,0c29.48799,0 53.49998,-24.32001 53.532,-53.808c0.01199,-14.28801 -5.53601,-27.884 -15.64001,-38.024c-10.13998,-10.132 -23.56799,-15.78801 -37.88397,-15.804c-29.49202,0 -53.51201,23.95599 -53.54401,53.464c-0.008,8.49199 -6.924,15.38 -15.44,15.38c-4.12,0 -7.996,-1.62401 -10.89999,-4.54401c-2.916,-2.912 -4.508,-6.78799 -4.504,-10.90401c0.04399,-46.492 37.896,-84.32399 84.448,-84.32399c46.53198,0.048 84.34399,37.936 84.29999,84.46001c-0.03198,39.17198 -27.78,73.78796 -66.004,82.30399z'
          )

          #Create a new column 'classified_column' based on the mapping from the classification list
          class = classification_list[match(qw, names(classification_list))]

          class <- data.frame(class)
          class = class %>% gather('name', 'path', 1:length(data2$category))
          qw2 = class$path
          qw3 = data2$grp

        }

        if (input$ch1 == 'Niche and Habitat (Ocean)') {
          #gpt3 classification
          classify_category <- function(text) {
            prompt <- paste(
              "Please classify the following as  Benthic, Pelagic, Terrestrial or Unidentified:\n\n",
              text,
              "\n\nCategory:"
            )
            response <- gpt3_single_completion(
              prompt_input = prompt,
              temperature = 0.9,
              max_tokens = 3,
              n = 1,
              model = "gpt-3.5-turbo-instruct"
            )
            category <- response[[1]]$gpt3
          }
          qw = sapply(data2$name, classify_category) %>% tolower()

          standardize_word <- function(word) {
            target_words <- c('benthic',
                              'pelagic',
                              'terrestrial',
                              'unidentified')
            distances <- stringdistmatrix(word, target_words, method = 'jw')

            closest_match_index <- which.min(distances)
            closest_match_distance <- distances[closest_match_index]

            other_distances <- distances[-closest_match_index]
            if (closest_match_distance < 10 &&
                all(closest_match_distance < other_distances + 3)) {
              return(target_words[closest_match_index])
            } else {
              return(word)
            }
          }

          qw <- sapply(qw, standardize_word)

          classification_list <- list(
            `benthic` = 'path://m58.7766,224.431l12.8893,-7.85899l12.7605,8.12599l-2.3201,-16.95999l10.4565,-11.89401l-14.3072,-2.638l-6.3158,-15.47l-6.50909,15.37401l-14.3555,2.27499l10.2954,12.123l-2.594,16.923zm261.20341,25.144c-34.914,-71.76199 -32.41702,-156.7948 0.07999,-223.7769c-32.09399,-0.0574 -64.62399,9.3885 -94.431,29.8293c-64.22099,44.0365 -98.184,126.02861 -93.802,208.28859c15.226,0.59302 29.629,7.01801 41.23001,18.52902c10.972,-7.24701 23.12,-10.97601 35.784,-10.97601c33.722,0 62.884,26.94202 71.987,64.61099c23.78101,8.70102 40.55301,34.66702 40.55301,65.28101c0,31.97101 -18.64102,58.702 -43.66202,66.293c44.871,12.25702 93.59201,5.37402 136.62701,-24.09198c29.80701,-20.422 52.95898,-49.12302 68.974,-82.16501c-65.12302,-0.134 -128.42599,-40.078 -163.34,-111.82201zm-14.40402,151.74699c0,-25.94699 -16.77298,-47.01898 -38.08798,-49.371c-3.69,-34.763 -28.38901,-61.74298 -58.647,-61.74298c-14.468,0 -27.519,6.32898 -37.83,16.483c-9.683,-14.685 -24.58701,-24.30301 -41.504,-24.30301c-25.27901,0 -46.32121,21.052 -51.58971,49.142c-27.4866,2.27499 -49.2374,29.16 -49.2374,62.37302c0,34.64798 23.6842,62.73798 52.8947,62.73798c6.203,0 12.0999,-1.492 17.6263,-3.82498c9.6351,15.67999 25.1181,25.98599 42.7121,25.98599c10.763,0 20.752,-3.862 29.114,-10.42099c9.53801,10.97598 22.492,17.82098 36.847,17.82098c21.123,0 39.20001,-14.819 47.675,-36.082c2.59401,0.59302 5.252,0.995 8.007,0.995c23.20099,0.01901 42.01999,-22.29599 42.01999,-49.793zm115.311,-123.96298l7.54102,-19.69501l17.93198,-3.767l-13.43698,-14.62801l2.49701,-21.435l-15.83801,10.689l-16.38501,-9.446l3.65701,21.205l-12.63202,15.565l18.09402,2.44801l8.57098,19.064zm-69.345,-91.24701l5.88101,13.05901l5.172,-13.51801l12.293,-2.563l-9.216,-10.019l1.724,-14.685l-10.875,7.304l-11.246,-6.48201l2.513,14.55101l-8.668,10.651l12.422,1.702zm59.22702,-38.817l3.60898,8.03101l3.17401,-8.27901l7.556,-1.60699l-5.655,-6.157l1.03101,-8.987l-6.67001,4.513l-6.84698,-3.996l1.49799,8.91l-5.31699,6.53999l7.621,1.032zm-271.91701,-54.0177l3.60899,8.0307l3.174,-8.2984l7.556,-1.6062l-5.655,-6.157l1.047,-8.9871l-6.67,4.4935l-6.87999,-3.9772l1.53099,8.8914l-5.33299,6.5587l7.621,1.0516z',
            `pelagic` = 'path://m426.62701,415.82101c0,0 -104.83502,-32.737 -163.07703,-32.737c-58.24098,0 -163.07599,32.737 -163.07599,32.737c0,0 34.94501,-109.12201 34.94501,-152.77103c0,-43.64899 -34.94501,-152.77099 -34.94501,-152.77099c0,0 104.83501,32.73701 163.07599,32.73701c58.242,0 163.07703,-32.73701 163.07703,-32.73701c0,0 -34.94501,109.122 -34.94501,152.77099c0,43.64902 34.94501,152.77103 34.94501,152.77103zm-163.09003,-360.11041c0,0 -55.63699,89.73239 -90.59399,122.4684c-34.95599,32.737 -130.71839,84.87498 -130.71839,84.87498c-0.0001,0 89.94939,46.68301 130.71839,84.875c40.76901,38.19302 90.59399,122.43802 90.59399,122.43802c0,0 55.68002,-89.70102 90.625,-122.43802c34.94501,-32.73599 130.71902,-84.875 130.71902,-84.875c0,0 -95.78601,-52.13799 -130.71902,-84.87498c-34.93298,-32.73601 -90.625,-122.4684 -90.625,-122.4684zm0,98.2184c64.33401,0 116.5,48.84599 116.5,109.12498c0,60.27902 -52.16599,109.125 -116.5,109.125c-64.33398,0 -116.46899,-48.84598 -116.46899,-109.125c0,-60.27899 52.13501,-109.12498 116.46899,-109.12498z',
            `terrestrial` = 'path://m421.38,72.426c-46.56,-46.64 -108.52002,-72.356 -174.64401,-72.42c-135.93199,0 -246.61999,110.572 -246.73599,246.5c-0.064,65.916 25.548,127.90401 72.1,174.55998c46.568,46.62802 108.284,72.436 174.19601,72.436l0.57199,0l0,-0.02399c134.95601,0 246.53999,-110.59601 246.64,-246.51602c0.064,-65.91197 -25.58398,-127.89198 -72.12799,-174.53597zm-163.67999,304.7c-2.836,2.86401 -6.8,4.504 -10.87201,4.504c-4.088,-0.008 -8.064,-1.65601 -10.93199,-4.56c-2.84801,-2.82401 -4.48401,-6.79199 -4.48,-10.87601c0.008,-4.07199 1.664,-8.064 4.532,-10.92398c2.856,-2.84802 7.064,-4.48801 10.92,-4.48801c4.06,0 8.028,1.64801 10.85999,4.504c2.89603,2.92001 4.556,6.91599 4.548,10.93201c-0.004,4.03198 -1.672,8.00397 -4.57599,10.90799zm7.42398,-94.452c-1.76001,0.388 -3.01999,1.948 -3.02402,3.75198l-0.01999,18.12003c-0.008,8.48798 -6.916,15.40799 -15.43599,15.40799c-8.51201,-0.008 -15.412,-6.94 -15.40401,-15.436l0.036,-34.96399c0.00801,-8.48401 6.916,-15.08 15.416,-15.08l0.06801,0c29.48799,0 53.49998,-24.32001 53.532,-53.808c0.01199,-14.28801 -5.53601,-27.884 -15.64001,-38.024c-10.13998,-10.132 -23.56799,-15.78801 -37.88397,-15.804c-29.49202,0 -53.51201,23.95599 -53.54401,53.464c-0.008,8.49199 -6.924,15.38 -15.44,15.38c-4.12,0 -7.996,-1.62401 -10.89999,-4.54401c-2.916,-2.912 -4.508,-6.78799 -4.504,-10.90401c0.04399,-46.492 37.896,-84.32399 84.448,-84.32399c46.53198,0.048 84.34399,37.936 84.29999,84.46001c-0.03198,39.17198 -27.78,73.78796 -66.004,82.30399z',
            `unidentified` = 'path://m421.38,72.426c-46.56,-46.64 -108.52002,-72.356 -174.64401,-72.42c-135.93199,0 -246.61999,110.572 -246.73599,246.5c-0.064,65.916 25.548,127.90401 72.1,174.55998c46.568,46.62802 108.284,72.436 174.19601,72.436l0.57199,0l0,-0.02399c134.95601,0 246.53999,-110.59601 246.64,-246.51602c0.064,-65.91197 -25.58398,-127.89198 -72.12799,-174.53597zm-163.67999,304.7c-2.836,2.86401 -6.8,4.504 -10.87201,4.504c-4.088,-0.008 -8.064,-1.65601 -10.93199,-4.56c-2.84801,-2.82401 -4.48401,-6.79199 -4.48,-10.87601c0.008,-4.07199 1.664,-8.064 4.532,-10.92398c2.856,-2.84802 7.064,-4.48801 10.92,-4.48801c4.06,0 8.028,1.64801 10.85999,4.504c2.89603,2.92001 4.556,6.91599 4.548,10.93201c-0.004,4.03198 -1.672,8.00397 -4.57599,10.90799zm7.42398,-94.452c-1.76001,0.388 -3.01999,1.948 -3.02402,3.75198l-0.01999,18.12003c-0.008,8.48798 -6.916,15.40799 -15.43599,15.40799c-8.51201,-0.008 -15.412,-6.94 -15.40401,-15.436l0.036,-34.96399c0.00801,-8.48401 6.916,-15.08 15.416,-15.08l0.06801,0c29.48799,0 53.49998,-24.32001 53.532,-53.808c0.01199,-14.28801 -5.53601,-27.884 -15.64001,-38.024c-10.13998,-10.132 -23.56799,-15.78801 -37.88397,-15.804c-29.49202,0 -53.51201,23.95599 -53.54401,53.464c-0.008,8.49199 -6.924,15.38 -15.44,15.38c-4.12,0 -7.996,-1.62401 -10.89999,-4.54401c-2.916,-2.912 -4.508,-6.78799 -4.504,-10.90401c0.04399,-46.492 37.896,-84.32399 84.448,-84.32399c46.53198,0.048 84.34399,37.936 84.29999,84.46001c-0.03198,39.17198 -27.78,73.78796 -66.004,82.30399z'
          )

          #Create a new column 'classified_column' based on the mapping from the classification list
          class = classification_list[match(qw, names(classification_list))]

          class <- data.frame(class)
          class = class %>% gather('name', 'path', 1:length(data2$category))
          qw2 = class$path
          qw3 = data2$grp


        }
        if (input$ch1 == 'Niche and Habitat (River)') {
          #gpt3 classification
          classify_category <- function(text) {
            prompt <- paste(
              "Please classify the following as  Benthic, Littoral, Demersal or Unidentified:\n\n",
              text,
              "\n\nCategory:"
            )
            response <- gpt3_single_completion(
              prompt_input = prompt,
              temperature = 0.9,
              max_tokens = 3,
              n = 1,
              model = "gpt-3.5-turbo-instruct"
            )
            category <- response[[1]]$gpt3
          }
          qw = sapply(data2$name, classify_category) %>% tolower()

          standardize_word <- function(word) {
            target_words <- c('benthic', 'littoral', 'demersal', 'unidentified')
            distances <- stringdistmatrix(word, target_words, method = 'jw')

            closest_match_index <- which.min(distances)
            closest_match_distance <- distances[closest_match_index]

            other_distances <- distances[-closest_match_index]
            if (closest_match_distance < 10 &&
                all(closest_match_distance < other_distances + 3)) {
              return(target_words[closest_match_index])
            } else {
              return(word)
            }
          }

          qw <- sapply(qw, standardize_word)

          classification_list <- list(
            `benthic` = 'path://m58.7766,224.431l12.8893,-7.85899l12.7605,8.12599l-2.3201,-16.95999l10.4565,-11.89401l-14.3072,-2.638l-6.3158,-15.47l-6.50909,15.37401l-14.3555,2.27499l10.2954,12.123l-2.594,16.923zm261.20341,25.144c-34.914,-71.76199 -32.41702,-156.7948 0.07999,-223.7769c-32.09399,-0.0574 -64.62399,9.3885 -94.431,29.8293c-64.22099,44.0365 -98.184,126.02861 -93.802,208.28859c15.226,0.59302 29.629,7.01801 41.23001,18.52902c10.972,-7.24701 23.12,-10.97601 35.784,-10.97601c33.722,0 62.884,26.94202 71.987,64.61099c23.78101,8.70102 40.55301,34.66702 40.55301,65.28101c0,31.97101 -18.64102,58.702 -43.66202,66.293c44.871,12.25702 93.59201,5.37402 136.62701,-24.09198c29.80701,-20.422 52.95898,-49.12302 68.974,-82.16501c-65.12302,-0.134 -128.42599,-40.078 -163.34,-111.82201zm-14.40402,151.74699c0,-25.94699 -16.77298,-47.01898 -38.08798,-49.371c-3.69,-34.763 -28.38901,-61.74298 -58.647,-61.74298c-14.468,0 -27.519,6.32898 -37.83,16.483c-9.683,-14.685 -24.58701,-24.30301 -41.504,-24.30301c-25.27901,0 -46.32121,21.052 -51.58971,49.142c-27.4866,2.27499 -49.2374,29.16 -49.2374,62.37302c0,34.64798 23.6842,62.73798 52.8947,62.73798c6.203,0 12.0999,-1.492 17.6263,-3.82498c9.6351,15.67999 25.1181,25.98599 42.7121,25.98599c10.763,0 20.752,-3.862 29.114,-10.42099c9.53801,10.97598 22.492,17.82098 36.847,17.82098c21.123,0 39.20001,-14.819 47.675,-36.082c2.59401,0.59302 5.252,0.995 8.007,0.995c23.20099,0.01901 42.01999,-22.29599 42.01999,-49.793zm115.311,-123.96298l7.54102,-19.69501l17.93198,-3.767l-13.43698,-14.62801l2.49701,-21.435l-15.83801,10.689l-16.38501,-9.446l3.65701,21.205l-12.63202,15.565l18.09402,2.44801l8.57098,19.064zm-69.345,-91.24701l5.88101,13.05901l5.172,-13.51801l12.293,-2.563l-9.216,-10.019l1.724,-14.685l-10.875,7.304l-11.246,-6.48201l2.513,14.55101l-8.668,10.651l12.422,1.702zm59.22702,-38.817l3.60898,8.03101l3.17401,-8.27901l7.556,-1.60699l-5.655,-6.157l1.03101,-8.987l-6.67001,4.513l-6.84698,-3.996l1.49799,8.91l-5.31699,6.53999l7.621,1.032zm-271.91701,-54.0177l3.60899,8.0307l3.174,-8.2984l7.556,-1.6062l-5.655,-6.157l1.047,-8.9871l-6.67,4.4935l-6.87999,-3.9772l1.53099,8.8914l-5.33299,6.5587l7.621,1.0516z',
            `littoral` = 'path://m426.62701,415.82101c0,0 -104.83502,-32.737 -163.07703,-32.737c-58.24098,0 -163.07599,32.737 -163.07599,32.737c0,0 34.94501,-109.12201 34.94501,-152.77103c0,-43.64899 -34.94501,-152.77099 -34.94501,-152.77099c0,0 104.83501,32.73701 163.07599,32.73701c58.242,0 163.07703,-32.73701 163.07703,-32.73701c0,0 -34.94501,109.122 -34.94501,152.77099c0,43.64902 34.94501,152.77103 34.94501,152.77103zm-163.09003,-360.11041c0,0 -55.63699,89.73239 -90.59399,122.4684c-34.95599,32.737 -130.71839,84.87498 -130.71839,84.87498c-0.0001,0 89.94939,46.68301 130.71839,84.875c40.76901,38.19302 90.59399,122.43802 90.59399,122.43802c0,0 55.68002,-89.70102 90.625,-122.43802c34.94501,-32.73599 130.71902,-84.875 130.71902,-84.875c0,0 -95.78601,-52.13799 -130.71902,-84.87498c-34.93298,-32.73601 -90.625,-122.4684 -90.625,-122.4684zm0,98.2184c64.33401,0 116.5,48.84599 116.5,109.12498c0,60.27902 -52.16599,109.125 -116.5,109.125c-64.33398,0 -116.46899,-48.84598 -116.46899,-109.125c0,-60.27899 52.13501,-109.12498 116.46899,-109.12498z',
            `demersal` = 'path://m421.38,72.426c-46.56,-46.64 -108.52002,-72.356 -174.64401,-72.42c-135.93199,0 -246.61999,110.572 -246.73599,246.5c-0.064,65.916 25.548,127.90401 72.1,174.55998c46.568,46.62802 108.284,72.436 174.19601,72.436l0.57199,0l0,-0.02399c134.95601,0 246.53999,-110.59601 246.64,-246.51602c0.064,-65.91197 -25.58398,-127.89198 -72.12799,-174.53597zm-163.67999,304.7c-2.836,2.86401 -6.8,4.504 -10.87201,4.504c-4.088,-0.008 -8.064,-1.65601 -10.93199,-4.56c-2.84801,-2.82401 -4.48401,-6.79199 -4.48,-10.87601c0.008,-4.07199 1.664,-8.064 4.532,-10.92398c2.856,-2.84802 7.064,-4.48801 10.92,-4.48801c4.06,0 8.028,1.64801 10.85999,4.504c2.89603,2.92001 4.556,6.91599 4.548,10.93201c-0.004,4.03198 -1.672,8.00397 -4.57599,10.90799zm7.42398,-94.452c-1.76001,0.388 -3.01999,1.948 -3.02402,3.75198l-0.01999,18.12003c-0.008,8.48798 -6.916,15.40799 -15.43599,15.40799c-8.51201,-0.008 -15.412,-6.94 -15.40401,-15.436l0.036,-34.96399c0.00801,-8.48401 6.916,-15.08 15.416,-15.08l0.06801,0c29.48799,0 53.49998,-24.32001 53.532,-53.808c0.01199,-14.28801 -5.53601,-27.884 -15.64001,-38.024c-10.13998,-10.132 -23.56799,-15.78801 -37.88397,-15.804c-29.49202,0 -53.51201,23.95599 -53.54401,53.464c-0.008,8.49199 -6.924,15.38 -15.44,15.38c-4.12,0 -7.996,-1.62401 -10.89999,-4.54401c-2.916,-2.912 -4.508,-6.78799 -4.504,-10.90401c0.04399,-46.492 37.896,-84.32399 84.448,-84.32399c46.53198,0.048 84.34399,37.936 84.29999,84.46001c-0.03198,39.17198 -27.78,73.78796 -66.004,82.30399z',
            `unidentified` = 'path://m421.38,72.426c-46.56,-46.64 -108.52002,-72.356 -174.64401,-72.42c-135.93199,0 -246.61999,110.572 -246.73599,246.5c-0.064,65.916 25.548,127.90401 72.1,174.55998c46.568,46.62802 108.284,72.436 174.19601,72.436l0.57199,0l0,-0.02399c134.95601,0 246.53999,-110.59601 246.64,-246.51602c0.064,-65.91197 -25.58398,-127.89198 -72.12799,-174.53597zm-163.67999,304.7c-2.836,2.86401 -6.8,4.504 -10.87201,4.504c-4.088,-0.008 -8.064,-1.65601 -10.93199,-4.56c-2.84801,-2.82401 -4.48401,-6.79199 -4.48,-10.87601c0.008,-4.07199 1.664,-8.064 4.532,-10.92398c2.856,-2.84802 7.064,-4.48801 10.92,-4.48801c4.06,0 8.028,1.64801 10.85999,4.504c2.89603,2.92001 4.556,6.91599 4.548,10.93201c-0.004,4.03198 -1.672,8.00397 -4.57599,10.90799zm7.42398,-94.452c-1.76001,0.388 -3.01999,1.948 -3.02402,3.75198l-0.01999,18.12003c-0.008,8.48798 -6.916,15.40799 -15.43599,15.40799c-8.51201,-0.008 -15.412,-6.94 -15.40401,-15.436l0.036,-34.96399c0.00801,-8.48401 6.916,-15.08 15.416,-15.08l0.06801,0c29.48799,0 53.49998,-24.32001 53.532,-53.808c0.01199,-14.28801 -5.53601,-27.884 -15.64001,-38.024c-10.13998,-10.132 -23.56799,-15.78801 -37.88397,-15.804c-29.49202,0 -53.51201,23.95599 -53.54401,53.464c-0.008,8.49199 -6.924,15.38 -15.44,15.38c-4.12,0 -7.996,-1.62401 -10.89999,-4.54401c-2.916,-2.912 -4.508,-6.78799 -4.504,-10.90401c0.04399,-46.492 37.896,-84.32399 84.448,-84.32399c46.53198,0.048 84.34399,37.936 84.29999,84.46001c-0.03198,39.17198 -27.78,73.78796 -66.004,82.30399z'
          )

          #Create a new column 'classified_column' based on the mapping from the classification list
          class = classification_list[match(qw, names(classification_list))]

          class <- data.frame(class)
          class = class %>% gather('name', 'path', 1:length(data2$category))
          qw2 = class$path
          qw3 = data2$grp


        }
        if (input$ch1 == 'Migration Patterns') {
          #gpt3 classification
          classify_category <- function(text) {
            prompt <- paste(
              "Please classify the following as Migratory, Non-Migratory or Unidentified:\n\n",
              text,
              "\n\nCategory:"
            )
            response <- gpt3_single_completion(
              prompt_input = prompt,
              temperature = 0.9,
              max_tokens = 5,
              n = 1,
              model = "gpt-3.5-turbo-instruct"
            )
            category <- response[[1]]$gpt3
          }
          qw = sapply(data2$name, classify_category) %>% tolower()

          standardize_word <- function(word) {
            target_words <- c('migratory', 'non-migratory', 'unidentified')
            distances <- stringdistmatrix(word, target_words, method = 'jw')

            closest_match_index <- which.min(distances)
            closest_match_distance <- distances[closest_match_index]

            other_distances <- distances[-closest_match_index]
            if (closest_match_distance < 10 &&
                all(closest_match_distance < other_distances + 3)) {
              return(target_words[closest_match_index])
            } else {
              return(word)
            }
          }

          qw <- sapply(qw, standardize_word)

          classification_list <- list(
            `migratory` = 'path://m58.7766,224.431l12.8893,-7.85899l12.7605,8.12599l-2.3201,-16.95999l10.4565,-11.89401l-14.3072,-2.638l-6.3158,-15.47l-6.50909,15.37401l-14.3555,2.27499l10.2954,12.123l-2.594,16.923zm261.20341,25.144c-34.914,-71.76199 -32.41702,-156.7948 0.07999,-223.7769c-32.09399,-0.0574 -64.62399,9.3885 -94.431,29.8293c-64.22099,44.0365 -98.184,126.02861 -93.802,208.28859c15.226,0.59302 29.629,7.01801 41.23001,18.52902c10.972,-7.24701 23.12,-10.97601 35.784,-10.97601c33.722,0 62.884,26.94202 71.987,64.61099c23.78101,8.70102 40.55301,34.66702 40.55301,65.28101c0,31.97101 -18.64102,58.702 -43.66202,66.293c44.871,12.25702 93.59201,5.37402 136.62701,-24.09198c29.80701,-20.422 52.95898,-49.12302 68.974,-82.16501c-65.12302,-0.134 -128.42599,-40.078 -163.34,-111.82201zm-14.40402,151.74699c0,-25.94699 -16.77298,-47.01898 -38.08798,-49.371c-3.69,-34.763 -28.38901,-61.74298 -58.647,-61.74298c-14.468,0 -27.519,6.32898 -37.83,16.483c-9.683,-14.685 -24.58701,-24.30301 -41.504,-24.30301c-25.27901,0 -46.32121,21.052 -51.58971,49.142c-27.4866,2.27499 -49.2374,29.16 -49.2374,62.37302c0,34.64798 23.6842,62.73798 52.8947,62.73798c6.203,0 12.0999,-1.492 17.6263,-3.82498c9.6351,15.67999 25.1181,25.98599 42.7121,25.98599c10.763,0 20.752,-3.862 29.114,-10.42099c9.53801,10.97598 22.492,17.82098 36.847,17.82098c21.123,0 39.20001,-14.819 47.675,-36.082c2.59401,0.59302 5.252,0.995 8.007,0.995c23.20099,0.01901 42.01999,-22.29599 42.01999,-49.793zm115.311,-123.96298l7.54102,-19.69501l17.93198,-3.767l-13.43698,-14.62801l2.49701,-21.435l-15.83801,10.689l-16.38501,-9.446l3.65701,21.205l-12.63202,15.565l18.09402,2.44801l8.57098,19.064zm-69.345,-91.24701l5.88101,13.05901l5.172,-13.51801l12.293,-2.563l-9.216,-10.019l1.724,-14.685l-10.875,7.304l-11.246,-6.48201l2.513,14.55101l-8.668,10.651l12.422,1.702zm59.22702,-38.817l3.60898,8.03101l3.17401,-8.27901l7.556,-1.60699l-5.655,-6.157l1.03101,-8.987l-6.67001,4.513l-6.84698,-3.996l1.49799,8.91l-5.31699,6.53999l7.621,1.032zm-271.91701,-54.0177l3.60899,8.0307l3.174,-8.2984l7.556,-1.6062l-5.655,-6.157l1.047,-8.9871l-6.67,4.4935l-6.87999,-3.9772l1.53099,8.8914l-5.33299,6.5587l7.621,1.0516z',
            `non-migratory` = 'path://m426.62701,415.82101c0,0 -104.83502,-32.737 -163.07703,-32.737c-58.24098,0 -163.07599,32.737 -163.07599,32.737c0,0 34.94501,-109.12201 34.94501,-152.77103c0,-43.64899 -34.94501,-152.77099 -34.94501,-152.77099c0,0 104.83501,32.73701 163.07599,32.73701c58.242,0 163.07703,-32.73701 163.07703,-32.73701c0,0 -34.94501,109.122 -34.94501,152.77099c0,43.64902 34.94501,152.77103 34.94501,152.77103zm-163.09003,-360.11041c0,0 -55.63699,89.73239 -90.59399,122.4684c-34.95599,32.737 -130.71839,84.87498 -130.71839,84.87498c-0.0001,0 89.94939,46.68301 130.71839,84.875c40.76901,38.19302 90.59399,122.43802 90.59399,122.43802c0,0 55.68002,-89.70102 90.625,-122.43802c34.94501,-32.73599 130.71902,-84.875 130.71902,-84.875c0,0 -95.78601,-52.13799 -130.71902,-84.87498c-34.93298,-32.73601 -90.625,-122.4684 -90.625,-122.4684zm0,98.2184c64.33401,0 116.5,48.84599 116.5,109.12498c0,60.27902 -52.16599,109.125 -116.5,109.125c-64.33398,0 -116.46899,-48.84598 -116.46899,-109.125c0,-60.27899 52.13501,-109.12498 116.46899,-109.12498z',
            `unidentified` = 'path://m421.38,72.426c-46.56,-46.64 -108.52002,-72.356 -174.64401,-72.42c-135.93199,0 -246.61999,110.572 -246.73599,246.5c-0.064,65.916 25.548,127.90401 72.1,174.55998c46.568,46.62802 108.284,72.436 174.19601,72.436l0.57199,0l0,-0.02399c134.95601,0 246.53999,-110.59601 246.64,-246.51602c0.064,-65.91197 -25.58398,-127.89198 -72.12799,-174.53597zm-163.67999,304.7c-2.836,2.86401 -6.8,4.504 -10.87201,4.504c-4.088,-0.008 -8.064,-1.65601 -10.93199,-4.56c-2.84801,-2.82401 -4.48401,-6.79199 -4.48,-10.87601c0.008,-4.07199 1.664,-8.064 4.532,-10.92398c2.856,-2.84802 7.064,-4.48801 10.92,-4.48801c4.06,0 8.028,1.64801 10.85999,4.504c2.89603,2.92001 4.556,6.91599 4.548,10.93201c-0.004,4.03198 -1.672,8.00397 -4.57599,10.90799zm7.42398,-94.452c-1.76001,0.388 -3.01999,1.948 -3.02402,3.75198l-0.01999,18.12003c-0.008,8.48798 -6.916,15.40799 -15.43599,15.40799c-8.51201,-0.008 -15.412,-6.94 -15.40401,-15.436l0.036,-34.96399c0.00801,-8.48401 6.916,-15.08 15.416,-15.08l0.06801,0c29.48799,0 53.49998,-24.32001 53.532,-53.808c0.01199,-14.28801 -5.53601,-27.884 -15.64001,-38.024c-10.13998,-10.132 -23.56799,-15.78801 -37.88397,-15.804c-29.49202,0 -53.51201,23.95599 -53.54401,53.464c-0.008,8.49199 -6.924,15.38 -15.44,15.38c-4.12,0 -7.996,-1.62401 -10.89999,-4.54401c-2.916,-2.912 -4.508,-6.78799 -4.504,-10.90401c0.04399,-46.492 37.896,-84.32399 84.448,-84.32399c46.53198,0.048 84.34399,37.936 84.29999,84.46001c-0.03198,39.17198 -27.78,73.78796 -66.004,82.30399z'
          )

          #Create a new column 'classified_column' based on the mapping from the classification list
          class = classification_list[match(qw, names(classification_list))]

          class <- data.frame(class)
          class = class %>% gather('name', 'path', 1:length(data2$category))
          qw2 = class$path
          qw3 = data2$grp



        }

        if (input$ch1 == 'Conservation Status') {
          #gpt3 classification
          classify_category <- function(text) {
            prompt <- paste(
              "Please classify the following according to IUCN redlist as Extinct, Endangered, Vulnerable, Least Concern, or Not Evaluated:\n\n",
              text,
              "\n\nCategory:"
            )
            response <- gpt3_single_completion(
              prompt_input = prompt,
              temperature = 0.1,
              max_tokens = 3,
              n = 1,
              model = "gpt-3.5-turbo-instruct"
            )
            category <- response[[1]]$gpt3
          }
          qw = sapply(data2$name, classify_category) %>% tolower()


          standardize_word <- function(word) {
            target_words <- c('extinct',
                              'endangered',
                              'vulnerable',
                              'least concern',
                              'not evaluated')
            distances <- stringdistmatrix(word, target_words, method = 'jw')

            closest_match_index <- which.min(distances)
            closest_match_distance <- distances[closest_match_index]

            other_distances <- distances[-closest_match_index]
            if (closest_match_distance < 10 &&
                all(closest_match_distance < other_distances + 3)) {
              return(target_words[closest_match_index])
            } else {
              return(word)
            }
          }

          qw <- sapply(qw, standardize_word)


          classification_list <- list(
            `extinct` = 'path://m282.31201,93.7812c-10.91901,0.00011 -21.94501,2.5816 -33.12401,7.7808c-11.96001,5.46001 -17.562,11.177 -16.782,17.15701c0.51999,3.12 2.78299,5.471 6.81299,7.031c4.03,1.56 6.43901,2.981 7.21901,4.28101l63.187,105.31299l-66.313,116.59399c-1.039,1.55902 -3.245,3.242 -6.62399,5.06201c-3.38,1.82001 -5.586,4.02499 -6.62601,6.625c-0.77899,1.82001 -1.15599,3.534 -1.15599,5.09399c0,6.759 5.04799,12.47601 15.18799,17.15601c9.35901,4.67999 19.37201,7 30.03101,7c9.099,0 15.74701,-1.798 19.90601,-5.43701c3.12,-2.85999 4.16501,-6.37198 3.125,-10.53198c-1.04001,-5.71899 -0.77802,-10.16101 0.78198,-13.28101l44.43701,-82.65601l46.81299,72.125c0.77902,1.30002 1.15601,2.60602 1.15601,3.90601c0,1.56 -0.72699,3.76501 -2.15601,6.625c-1.42999,2.85999 -2.12598,5.211 -2.12598,7.03101c0.00098,2.60001 1.04599,5.18201 3.12598,7.78198c3.379,4.159 9.09601,7.93201 17.15601,11.31201c8.05902,3.38 16.09601,5.09399 24.15601,5.09399c20.01901,0 30.70001,-9.89798 32,-29.65601c0.26001,-4.41998 -1.94501,-7.93198 -6.625,-10.53198c-6.23999,-3.64001 -9.75101,-6.22101 -10.53101,-7.78101l-74.09399,-111.53101l50.68799,-94c1.039,-2.07999 4.66602,-4.43199 10.90601,-7.032c4.939,-2.33899 7.814,-6.604 8.59399,-12.84299c0.77902,-7.28 -3.25497,-13.519 -12.09399,-18.719c-8.06,-4.4197 -17.173,-6.625 -27.31299,-6.625c-8.57901,0 -14.93402,1.6827 -19.09302,5.063c-2.85999,2.599 -4.80399,6.487 -5.84399,11.687c-1.29999,6.5 -2.492,10.795 -3.53198,12.875l-31.96802,63.96899c-25.99899,-46.797 -39.784,-74.25299 -41.34399,-82.313c-1.04001,-5.979 -3.62201,-9.8674 -7.78101,-11.68719c-2.60001,-1.3 -5.99701,-1.93761 -10.15698,-1.93761zm-104.50002,0.375c-4.41899,0 -8.30699,0.8989 -11.687,2.7188c-4.94,2.5998 -7.929,4.053 -8.96899,4.313l-46.812,13.25c-3.12,-1.3 -6.37,-2.722 -9.75,-4.28201c-5.19991,-2.08 -9.4955,-3.00999 -12.8752,-2.75c-15.8591,2.34 -23.7813,7.304 -23.7813,14.844c0,2.34 0.8989,4.66 2.7187,7c-1.81979,76.955 -1.29729,149.509 1.56261,217.625c-2.8599,8.83899 -4.2813,13.51099 -4.2813,14.03101c0,1.82001 0.3763,3.242 1.1563,4.28198c11.1793,15.599 23.65829,25.35001 37.43719,29.25c1.3,0.26001 2.492,0.40601 3.531,0.40601c3.12,0 6.632,-1.56799 10.53201,-4.68799c5.199,-3.89999 8.56499,-6.25101 10.125,-7.03101l36.656,-16.375c14.039,0.78 24.052,-0.323 30.03101,-3.31201c5.98,-2.98999 8.96899,-7.60498 8.96899,-13.84399c0,-7.28 -3.888,-14.418 -11.687,-21.43799c-7.8,-7.01901 -15.34601,-10.79199 -22.62601,-11.31201c-6.759,-0.51999 -11.431,0.52499 -14.03099,3.125c-1.3,1.30002 -2.606,2.836 -3.90601,4.65601c-7.28,3.12 -16.39301,5.84799 -27.313,8.18701c-1.559,-5.979 -2.34299,-19.47202 -2.34299,-40.53101c8.579,-3.63901 15.86399,-6.77499 21.84299,-9.375c2.08,-0.78 6.89801,-0.89502 14.438,-0.375c7.53999,0.51999 13.256,0.259 17.15601,-0.78101c6.5,-1.82001 11.31799,-6.26199 14.43799,-13.28101c0.78,-1.82001 1.15601,-3.50299 1.15601,-5.06299c0,-6.23901 -4.991,-12.683 -15,-19.31201c-10.009,-6.62999 -18.804,-9.93799 -26.34399,-9.93799c-7.539,0 -12.849,2.467 -15.968,7.40599c-6.24001,1.04001 -10.159,1.97101 -11.719,2.75c-1.56001,-31.198 -1.56001,-59.03 0,-83.468c4.679,-3.37999 14.316,-7.52899 28.87499,-12.46899c5.979,-2.08 12.74101,-4.17 20.28101,-6.25c5.2,0.52 9.756,0.78101 13.65601,0.78101c9.36,0 17.021,-2.205 23,-6.625c2.86,-2.08 4.28099,-5.069 4.28099,-8.96901c0,-6.239 -2.785,-12.944 -8.37399,-20.09299c-5.59,-7.15 -11.25,-11.2416 -16.96901,-12.2815c-2.86,-0.52 -5.327,-0.7813 -7.407,-0.7813z',
            `endangered` = 'path://m399.90601,93c-5.979,0 -10.39001,1.2752 -13.25,3.875c-5.19901,4.68 -7.81201,8.599 -7.81201,11.719c0,1.56 0.89902,3.561 2.71802,6.031c1.81998,2.47 2.75,4.764 2.75,6.844l4.65698,171.59301c-49.397,-76.43501 -76.67599,-126.61201 -81.875,-150.53101c-0.25998,-0.52 -0.40601,-1.18901 -0.40601,-1.96901c-0.00098,-1.039 0.26102,-2.722 0.78101,-5.062c0.52002,-2.34 0.78101,-4.16901 0.78101,-5.46899c0,-3.38 -1.16,-6.22201 -3.5,-8.562c-8.319,-9.1 -22.22,-13.65701 -41.71899,-13.65701c-7.27901,0 -12.93901,1.103 -16.96901,3.313c-4.02899,2.21 -6.062,4.995 -6.062,8.375c0,1.3 0.261,3.129 0.78101,5.469c0.51999,2.34 0.78099,4.022 0.78099,5.062l11.71901,214.875c0.25999,2.34 -1.71501,5.00998 -5.875,8c-4.15901,2.98999 -5.84201,7.34299 -5.06201,13.06299c1.04001,7.01901 6.06201,13.14401 15.03101,18.34302c8.96899,5.19998 18.10901,7.78198 27.46899,7.78198c8.83902,0 15.48599,-2.46698 19.90601,-7.40601c3.12,-3.63998 4.68799,-7.52798 4.68799,-11.68799c0,-3.38 -1.30698,-7.56 -3.90698,-12.5c-2.60001,-4.94 -3.90601,-8.04401 -3.90601,-9.34399c-5.20001,-66.03601 -7.29001,-111.01901 -6.25,-134.93701c9.35901,20.27901 23.92899,45.383 43.68701,75.28101c8.06,12.479 16.91199,25.33499 26.53198,38.59399c2.08002,3.63901 3.35501,8.19601 3.875,13.65601c0.26001,6.23999 1.04401,10.79599 2.34302,13.65601c8.06,18.19901 23.15198,27.94998 45.25,29.25c8.84,0.51999 16.23999,-2.09302 22.21899,-7.81201c5.97998,-5.72 9.22998,-12.858 9.75,-21.43799c0.25998,-3.38 -1.48001,-7.61801 -5.25,-12.68701c-3.77002,-5.07001 -5.65601,-9.30798 -5.65601,-12.68799l-5.46899,-192.25c0,-2.60001 2.14798,-5.12401 6.43799,-7.593c4.29001,-2.47 6.29102,-6.04 6.03101,-10.719c-0.26001,-7.02 -5.45401,-13.521 -15.59399,-19.5c-10.13901,-5.9799 -20.005,-8.969 -29.625,-8.969zm-213.31201,1.1562c-4.42,0 -8.33899,0.8989 -11.71899,2.7188c-4.94,2.5998 -7.929,4.053 -8.96899,4.313l-46.78101,13.25c-3.12,-1.3 -6.37,-2.722 -9.75,-4.28201c-5.2,-2.08 -9.4952,-3.00999 -12.875,-2.75c-15.859,2.34 -23.7812,7.304 -23.7812,14.844c-0.00011,2.34 0.8988,4.66 2.7187,7c-1.8199,76.955 -1.2973,149.509 1.5625,217.625c-2.8598,8.83899 -4.2812,13.51099 -4.2812,14.03101c-0.00011,1.82001 0.3762,3.242 1.1562,4.28198c11.1793,15.599 23.6583,25.35001 37.437,29.25c1.3,0.26001 2.492,0.40601 3.53201,0.40601c3.12,0 6.6,-1.56799 10.5,-4.68799c5.199,-3.89999 8.596,-6.25101 10.156,-7.03101l36.65601,-16.375c14.039,0.78 24.05199,-0.323 30.032,-3.31201c5.979,-2.98999 8.968,-7.60498 8.968,-13.84399c0,-7.28 -3.888,-14.418 -11.68701,-21.43799c-7.79999,-7.01901 -15.34599,-10.79199 -22.625,-11.31201c-6.75999,-0.51999 -11.463,0.52499 -14.06299,3.125c-1.3,1.30002 -2.57501,2.836 -3.875,4.65601c-7.27901,3.12 -16.39301,5.84799 -27.31201,8.18701c-1.56,-5.979 -2.34399,-19.47202 -2.34399,-40.53101c8.57899,-3.63901 15.864,-6.77499 21.84399,-9.375c2.08,-0.78 6.89801,-0.89502 14.43701,-0.375c7.53999,0.51999 13.25699,0.259 17.157,-0.78101c6.49899,-1.82001 11.317,-6.26199 14.437,-13.28101c0.78,-1.82001 1.15601,-3.50299 1.15601,-5.06299c0,-6.23901 -4.99001,-12.683 -15,-19.31201c-10.009,-6.62999 -18.804,-9.93799 -26.343,-9.93799c-7.54001,0 -12.849,2.467 -15.96901,7.40599c-6.23999,1.04001 -10.159,1.97101 -11.71899,2.75c-1.56,-31.198 -1.56,-59.03 0,-83.468c4.67999,-3.37999 14.31599,-7.52899 28.875,-12.46899c5.98,-2.08 12.742,-4.17 20.28101,-6.25c5.2,0.52 9.72499,0.78101 13.625,0.78101c9.36,0 17.05199,-2.205 23.03099,-6.625c2.86,-2.08 4.282,-5.069 4.282,-8.96901c0,-6.239 -2.786,-12.944 -8.375,-20.09299c-5.59,-7.15 -11.24899,-11.2416 -16.96899,-12.2815c-2.86,-0.52 -5.326,-0.7813 -7.40601,-0.7813z',
            `vulnerable` = 'path://m209.21899,106.781c-6.75999,0 -12.50899,1.191 -17.18799,3.531c-7.28,4.42001 -10.90601,10.25301 -10.90601,17.53201c0,0.77999 0,2.143 0,4.094c0,1.95 0,3.57399 0,4.87399c0,2.85901 -0.261,5.32701 -0.78101,7.407l-39.782,140.40601l-28.062,-132.21899c-0.519,-2.34001 0.264,-5.50101 2.344,-9.53101c2.08,-4.03 3.094,-7.108 3.094,-9.187c-0.00101,-1.56 -0.262,-2.98201 -0.78201,-4.282c-1.82,-4.94 -6.695,-8.77 -14.625,-11.50001c-7.9292,-2.73 -16.69279,-4.094 -26.31219,-4.094c-22.09871,0 -33.1563,5.19501 -33.1563,15.59401c0,3.89999 2.5554,7.616 7.625,11.125c5.0697,3.50999 7.74,6.14899 8,7.96899l44.4375,200.06201c0.52,2.07999 0.259,4.547 -0.781,7.40698c-1.3,3.89999 -1.938,6.51199 -1.938,7.81201c0,8.57898 5.717,17.48999 17.156,26.71899c11.43901,9.23001 21.97501,13.84399 31.59401,13.84399c6.5,0 12.01399,-2.20599 16.56299,-6.625c4.55,-4.41998 6.81201,-10.138 6.81201,-17.15698c0,-2.34003 -0.31801,-5.59003 -0.96901,-9.75c-0.64999,-4.15802 -0.968,-7.03302 -0.968,-8.59302c0,-1.29999 0.14601,-2.345 0.40601,-3.125l63.15601,-206.68799c0.78,-2.34001 3.45,-4.748 8,-7.218c4.549,-2.47101 7.33499,-4.79001 8.375,-7c1.03999,-2.21001 1.56299,-4.358 1.56299,-6.438c0,-6.76 -4.55699,-12.622 -13.65599,-17.562c-9.10001,-4.941 -18.82001,-7.40701 -29.21901,-7.40701zm219.53101,0c-14.55899,0 -24.57101,3.511 -30.03101,10.531c-3.63998,4.68 -5.43799,9.091 -5.43799,13.25c0,3.901 2.20499,8.776 6.625,14.62601c4.41998,5.849 6.36398,10.34799 5.84399,13.468c0.51999,2.86 0.78101,7.532 0.78101,14.032c0,33.27699 -3.13501,69.554 -9.375,108.812c-7.79901,48.617 -17.51901,73.168 -29.21802,73.68799c-6.76099,0.26001 -12.884,-15.84598 -18.34399,-48.34399c-4.16,-24.95801 -7.526,-55.78 -10.125,-92.43799c-2.07999,-32.75801 -2.603,-50.692 -1.56299,-53.81201c-0.52002,-3.12 0.698,-6.89299 3.68799,-11.31299c2.98901,-4.42001 4.353,-8.57001 4.09399,-12.46901c-0.51999,-7.799 -5.453,-14.154 -14.81299,-19.09299c-8.05899,-4.16 -17.173,-6.25 -27.31299,-6.25c-8.319,0 -14.151,1.682 -17.53101,5.062c-5.20001,4.94 -7.81201,11.064 -7.81201,18.344c0,4.939 1.306,11.032 3.90601,18.313c-1.04001,9.618 -1.56299,24.30299 -1.56299,44.062c0.00098,53.55701 5.341,98.017 16,133.375c15.34,51.47699 40.81998,76.32001 76.43799,74.5c30.418,-1.29999 53.43201,-22.108 69.03101,-62.40601c11.17999,-29.11798 18.17099,-67.97699 21.03101,-116.59399c0.51999,-26.258 0.92798,-52.638 1.18799,-79.15601l4.68799,-12.5c-0.00098,-3.12 -1.453,-7.008 -4.31299,-11.688c-6.23999,-10.659 -18.19601,-16 -35.875,-16z',
            `least concern` = 'path://m118.344,94.5625c-10.14,0 -17.947,2.2053 -23.4065,6.6255c-3.8998,3.119 -5.8437,6.37 -5.8437,9.75c-0.00011,2.339 1.3639,5.182 4.0937,8.562c2.7298,3.38 4.0937,5.47 4.0937,6.25l16.3748,212.93799c0.26,2.599 -1.48,5.76102 -5.25,9.53101c-3.77,3.77002 -5.656,7.224 -5.656,10.34302c0,1.29999 0.261,2.86798 0.781,4.68799c2.86,8.05899 8.169,14.879 15.969,20.46899c7.8,5.58902 15.492,7.99802 23.03101,7.21899c12.22,-1.81998 20.77899,-5.07098 25.71899,-9.75c5.72,-6.23999 10.799,-9.95599 15.21899,-11.12598c4.41901,-1.16901 11.558,-1.75 21.43701,-1.75c9.87999,0.00098 17.483,-0.841 22.81299,-2.53101c5.32901,-1.69 10.03201,-5.259 14.06201,-10.71899c4.03,-5.45901 6.03099,-11.061 6.03099,-16.78101c0,-3.64001 -0.78299,-6.89001 -2.343,-9.75c-8.57999,-14.819 -17.547,-22.21899 -26.907,-22.21899c-3.379,0.00098 -7.61699,0.957 -12.687,2.90698c-5.07001,1.95001 -10.06,3.98199 -15,6.06201l-23.40601,8.56299l-14.03099,-193.81299c-0.26001,-1.82001 0.785,-3.76401 3.12399,-5.843c2.34,-2.08 3.5,-4.17101 3.5,-6.25c0.00101,-2.08 -0.63699,-4.401 -1.937,-7c-2.08,-4.42001 -7.10201,-8.25101 -15.03101,-11.5005c-7.92999,-3.2498 -16.171,-4.875 -24.74999,-4.875zm226.96801,3.5c-3.11902,0 -6.37003,0.115 -9.75,0.375c-23.138,2.3395 -41.48001,22.3645 -55,60.0625c-11.69901,32.23801 -17.41602,67.992 -17.15601,107.25c0.25998,34.83801 5.716,63.04599 16.375,84.625c13.77899,28.078 35.633,41.979 65.53101,41.71899c24.69897,-0.25998 49.396,-28.061 74.09399,-83.43799c7.28,-5.45901 10.90601,-11.95999 10.90601,-19.5c0,-9.099 -6.354,-14.81601 -19.09302,-17.15601c-4.16,-0.78 -8.341,-1.18799 -12.5,-1.18799c-18.71899,0.00098 -28.06299,6.909 -28.06299,20.68799c0,2.07999 0.26199,4.285 0.78198,6.625c-4.15997,14.039 -9.35498,26.25699 -15.59399,36.65601c-6.5,11.17999 -12.10199,16.37399 -16.78198,15.59399c-7.79901,-1.29999 -13.63101,-12.09601 -17.53101,-32.375c-3.38,-17.939 -4.686,-37.29501 -3.90601,-58.09399c1.04001,-27.558 3.883,-52.77701 8.56299,-75.65601c5.45901,-27.81799 11.845,-40.82001 19.12402,-39c4.67999,0.78 8.82898,5.771 12.46899,15c3.63998,9.229 5.72998,19.069 6.25,29.46899c-3.63901,8.319 -5.46899,12.845 -5.46899,13.625c0.00098,6.239 5.341,11.841 16,16.78101c9.09998,4.42 17.39798,6.625 24.93799,6.625c3.12,0 5.84799,-0.37601 8.18799,-1.15601c10.659,-4.15999 15.99902,-10.138 16,-17.93799c0,-2.60001 -2.20599,-9.623 -6.62598,-21.06201c-5.979,-28.599 -13.26401,-49.407 -21.84302,-62.40599c-11.69901,-17.41901 -28.328,-26.1255 -49.90698,-26.1255z',
            `not evaluated` = 'path://m227.53101,104.438c-5.979,-0.00101 -10.39,1.306 -13.25,3.906c-5.19901,4.679 -7.81201,8.567 -7.81201,11.687c0,1.56001 0.899,3.562 2.71901,6.031c1.819,2.47 2.75,4.76401 2.75,6.84401l4.687,171.59399c-49.397,-76.435 -76.707,-126.61301 -81.90601,-150.53101c-0.25999,-0.51999 -0.407,-1.189 -0.407,-1.96899c0,-1.03999 0.26201,-2.72301 0.782,-5.062c0.52,-2.34 0.78101,-4.16901 0.78101,-5.46901c0,-3.37999 -1.16,-6.22299 -3.5,-8.56299c-8.32,-9.09901 -22.22,-13.65601 -41.7188,-13.65601c-7.2795,0 -12.9389,1.103 -16.9687,3.312c-4.0298,2.21001 -6.0313,4.996 -6.0313,8.37601c0.00011,1.299 0.2301,3.12799 0.75,5.468c0.52,2.34 0.7813,4.02299 0.7813,5.06299l11.7187,214.875c0.26,2.34 -1.684,5.01001 -5.8437,8c-4.1597,2.99002 -5.8737,7.34302 -5.0937,13.06201c1.03989,7.01999 6.0617,13.14398 15.0312,18.34399c8.9695,5.20001 18.141,7.78101 27.5,7.78101c8.839,0 15.455,-2.466 19.875,-7.40601c3.12,-3.64001 4.687,-7.52802 4.687,-11.68701c0.00101,-3.37997 -1.306,-7.53 -3.90599,-12.46899c-2.60001,-4.94 -3.90601,-8.07498 -3.90601,-9.375c-5.2,-66.03598 -7.259,-111.019 -6.219,-134.93799c9.36001,20.27899 23.898,45.383 43.65701,75.28198c8.05899,12.479 16.911,25.33401 26.53099,38.59302c2.08,3.63998 3.386,8.19699 3.90601,13.65698c0.25999,6.23901 1.04401,10.79602 2.34399,13.65601c8.05901,18.19901 23.12001,27.95001 45.21901,29.25c8.83899,0.52002 16.239,-2.09299 22.218,-7.81299c5.97998,-5.71899 9.22998,-12.858 9.75,-21.43701c0.25998,-3.38 -1.48001,-7.61798 -5.25,-12.68799c-3.77002,-5.069 -5.65601,-9.276 -5.65601,-12.65601l-5.46899,-192.28101c0,-2.59999 2.14798,-5.12399 6.43799,-7.59399c4.289,-2.47 6.32199,-6.039 6.06201,-10.71899c-0.26001,-7.019 -5.48502,-13.52 -15.625,-19.50001c-10.13901,-5.979 -20.005,-8.96799 -29.625,-8.96799zm197.71899,1.156c-4.42001,0 -8.30801,0.93 -11.68799,2.75c-4.93903,2.6 -7.92801,4.021 -8.96802,4.281l-46.81299,13.25c-3.12,-1.3 -6.37,-2.721 -9.75,-4.281c-5.19901,-2.08 -9.495,-2.979 -12.875,-2.719c-15.85901,2.34 -23.78101,7.273 -23.78101,14.813c0,2.33899 0.89899,4.66 2.71899,7c-1.82001,76.955 -1.298,149.50899 1.56201,217.62401c-2.86002,8.84 -4.28101,13.51199 -4.28101,14.03198c0,1.82001 0.37601,3.241 1.15601,4.28101c11.17999,15.599 23.659,25.35001 37.43799,29.25c1.30002,0.26001 2.491,0.40601 3.53101,0.40601c3.12,0 6.63101,-1.56702 10.53101,-4.68701c5.19998,-3.89999 8.565,-6.25198 10.125,-7.03198l36.65601,-16.37402c14.03998,0.78 24.052,-0.323 30.03198,-3.31299c5.979,-2.98999 8.96802,-7.604 8.96802,-13.84399c0,-7.27899 -3.88702,-14.418 -11.68701,-21.43701c-7.79901,-7.01999 -15.345,-10.793 -22.625,-11.31299c-6.76001,-0.52002 -11.431,0.52499 -14.03101,3.125c-1.29999,1.29999 -2.60699,2.83701 -3.90698,4.65601c-7.27902,3.12 -16.39301,5.879 -27.31201,8.21899c-1.56,-5.979 -2.31201,-19.504 -2.31201,-40.56201c8.57901,-3.63998 15.832,-6.77499 21.81201,-9.375c2.07999,-0.78 6.89801,-0.89499 14.43799,-0.375c7.539,0.52002 13.25601,0.258 17.15601,-0.78101c6.49899,-1.81998 11.31702,-6.26199 14.43701,-13.28198c0.78,-1.82001 1.15698,-3.50201 1.15698,-5.06201c0,-6.23999 -4.991,-12.65201 -15,-19.282c-10.00998,-6.629 -18.77298,-9.968 -26.31299,-9.968c-7.539,0 -12.88,2.466 -16,7.40601c-6.23999,1.03999 -10.12799,1.97 -11.68701,2.75c-1.56,-31.198 -1.56,-59.03 0,-83.46899c4.67902,-3.38 14.284,-7.52901 28.84302,-12.46901c5.97998,-2.07899 12.742,-4.17 20.28101,-6.25c5.19998,0.52 9.75699,0.782 13.65698,0.782c9.35901,0 17.02002,-2.20599 23,-6.625c2.86002,-2.07999 4.28101,-5.069 4.28101,-8.96899c0,-6.24001 -2.785,-12.944 -8.375,-20.094c-5.59,-7.14899 -11.24899,-11.241 -16.96899,-12.281c-2.86002,-0.52 -5.32602,-0.781 -7.40601,-0.781z'

          )

          #Create a new column 'classified_column' based on the mapping from the classification list
          class = classification_list[match(qw, names(classification_list))]

          class <- data.frame(class)
          class = class %>% gather('name', 'path', 1:length(data2$category))
          qw2 = class$path
          qw3 = data2$grp



        }




      }






      table_data3_1 <- data.frame(
        name = data2$name,
        t_level = data2$t_level,
        value = data2$value,
        size = data2$size,
        grp = floor(data2$t_level),
        category = qw,
        symbol = qw2,
        symbol2 = qw3
      )


      table_data4_1 <- data.frame(from = data$from,
                                  to = data$to,
                                  weight = data$weight)
      table_data3(table_data3_1)
      table_data4(table_data4_1)


      output$editableTable3 <- renderRHandsontable({
        rhandsontable(table_data3(), rowHeaders = NULL) %>%
          hot_cols(width = c(100, 100, 0.1, 100, 0.1, 100, 0.1, 0.1)) %>%
          hot_cols(
            renderer = "
        function(instance, td, row, col, prop, value, cellProperties) {
          Handsontable.renderers.TextRenderer.apply(this, arguments);
          if (col === 6|| col === 7) { // Adjust the column index (zero-based) you want to change the font size
            td.style.fontSize = '0px'; // Set the desired font size
            td.style.textAlign = 'right'; // Center the content
          }
        }
      "
          )


      })

      output$editableTable4 <- renderRHandsontable({
        rhandsontable(
          table_data4(),
          stretchH = "all",
          rowHeaders = NULL,
          width = "100%",
          allowRowAdd = TRUE
        )
      })

      # Observe changes in the tables and update the reactive values





      output$my_chartR <- renderEcharts4r({
        les <- list(nodes = table_data3(), edges = table_data4())



        les$nodes$size <- scales::rescale(les$nodes$size, to = c(10, 50))
        les$edges$weight <- scales::rescale(les$edges$weight, to = c(1, 6))


        if (input$ch3 == 'Icons') {
          a <- e_charts() |>
            e_graph(
              emphasis = list(focus = 'adjacency', label = list(show = TRUE)),
              roam = TRUE,
              zoom = input$ch20,
              left = '30%',
              right = '10%',
              lineStyle = list(color = "source", curveness = 0.3),
              draggable = FALSE
            ) |>
            e_graph_nodes(
              nodes = les$nodes,
              names = name,
              value = value,
              size = size,
              legend = TRUE,
              category = category,
              symbol = symbol
            ) |>
            e_graph_edges(
              edges = les$edges,
              source = from,
              target = to,
              value = weight,
              size = weight
            ) |>
            e_tooltip() |>
            e_theme(name = input$ch2) |>
            e_toolbox() |>
            e_toolbox_feature(feature = c("saveAsImage"))
        } else {
          if (input$ch3 == 'Emoji') {
            a <- e_charts() |>
              e_graph(
                emphasis = list(focus = 'adjacency', label = list(show = TRUE)),
                roam = TRUE,
                zoom = input$ch20,
                left = '30%',
                right = '10%',
                lineStyle = list(color = "source", curveness = 0.3),
                draggable = FALSE
              ) |>
              e_graph_nodes(
                nodes = les$nodes,
                names = name,
                value = value,
                size = size,
                legend = TRUE,
                category = category,
                symbol = symbol2
              ) |>
              e_graph_edges(
                edges = les$edges,
                source = from,
                target = to,
                value = weight,
                size = weight
              ) |>
              e_tooltip() |>
              e_theme(name = input$ch2) |>
              e_toolbox() |>
              e_toolbox_feature(feature = c("saveAsImage"))
          }
          if (input$ch3 != 'Icons' && input$ch3 != 'Emoji') {
            les$nodes$symbol = rep(input$ch3, length(les$nodes$category))

            a <- e_charts() |>
              e_graph(
                emphasis = list(focus = 'adjacency', label = list(show = TRUE)),
                roam = TRUE,
                left = '30%',
                right = '10%',
                zoom = input$ch20,
                lineStyle = list(color = "source", curveness = 0.3),
                draggable = FALSE,
                symbolSize = 20
              ) |>
              e_graph_nodes(
                nodes = les$nodes,
                names = name,
                value = value,
                size = size,
                legend = TRUE,
                category = category,
                symbol = symbol
              ) |>
              e_graph_edges(
                edges = les$edges,
                source = from,
                target = to,
                value = weight,
                size = weight
              ) |>
              e_tooltip() |>
              e_theme(name = input$ch2) |>
              e_toolbox() |>
              e_toolbox_feature(feature = c("saveAsImage"))
          }
        }

        for (i in 1:length(levels(as.factor(data2$name)))) {
          a$x$opts$series[[1]]$data[[i]]$y <- les$nodes$t_level[i] * -150
        }

        for (i in 1:length(levels(as.factor(data2$name)))) {
          pattern <- ((i - 1) %/% 10) * 50
          offset <- ((i - 1) %% 10) * 66
          a$x$opts$series[[1]]$data[[i]]$x <- pattern + offset
        }

        a$x$opts$series[[1]]$layout <- input$ch6
        a$x$opts$series[[1]]$draggable <- TRUE
        a$x$opts$series[[1]]$label <- list(
          show = TRUE,
          fontSize = input$fontsize,
          position = "bottom",
          borderColor = 'transparent',
          borderWidth = 0
        )
        a$x$opts$series[[1]]$itemStyle <- list(borderWidth = 1,
                                               borderColor = 'black')
        a$x$opts$legend <- list(show = TRUE)
        a$x$opts$itemStyle = list(borderColor = 'transparent', borderWidth =
                                    0)

        for (i in 1:length(les$nodes$grp)) {
          a$x$opts$series[[1]]$data[[i]]$symbolSize = as.numeric(a$x$opts$series[[1]]$data[[i]]$symbolSize) * input$ch4
        }

        # Return the chart using echartOutput
        a

      })

    }
  })


  output$text1 <- renderEcharts4r({
    num_species <- length(unique(c(table_data3()$name)))
    num_links <- length(table_data4()$weight[table_data4()$weight > 0])

    # Calculate connectance
    connectance <- num_links / (num_species * (num_species - 1))

    liquid <- data.frame(val = c(connectance, connectance, connectance))
    liquid |>
      e_charts() |>
      e_liquid(val)

  })

  output$text2 <- renderEcharts4r({
    w = setNames(table_data3()$grp, table_data3()$name)

    matched_species_from <- w[match(table_data4()$from, names(w))]
    matched_species_to <- w[match(table_data4()$to, names(w))]

    dataw = table_data4()
    dataw$from = matched_species_from
    dataw$to = matched_species_to
    rr = dataw %>% group_by(from, to) %>%
      summarise(soma = sum(weight)) %>%
      na.exclude()
    rr = rr %>% filter(from != to)
    rr$from = as.factor(rr$from)
    rr$to = as.factor(rr$to)
    rr2 = data.frame(name = unique(rr$from), value = rep(1, length(unique(rr$from))))
    les_mini = list(nodes = rr2, edges = rr)
    les_mini$nodes$group = as.factor(les_mini$nodes$name)
    les_mini$edges$weight <- scales::rescale(les_mini$edges$soma, to = c(1, 6))
    les_mini$nodes$size <- scales::rescale(les_mini$nodes$value, to = c(10, 30))
    a <- e_charts() |>
      e_graph(
        emphasis = list(focus = 'adjacency', label = list(show = TRUE)),
        roam = TRUE,
        zoom = 2,

        right = '35%',
        lineStyle = list(color = "source", curveness = 0.310),
        draggable = FALSE
      ) |>
      e_graph_nodes(
        nodes = les_mini$nodes,
        name = "name",
        # Column name for the node names
        value = "value",
        size = size,
        category = group,

        legend = TRUE
      ) |>
      e_graph_edges(
        edges = les_mini$edges,
        source = from,
        target = to,
        value = soma,
        size = weight
      ) |>
      e_tooltip() |>
      e_toolbox() |>
      e_toolbox_feature(feature = c("saveAsImage"))

  })





  observeEvent(input$editableTable4, {
    table_data4(hot_to_r(input$editableTable4))
  })

  output$dwntable2 <- downloadHandler(
    filename = function() {
      paste('csv-files-', Sys.Date(), '.zip', sep = '')
    },
    content = function(zipfile) {
      # Create a temporary directory to store the CSV files
      tmpdir <- tempdir()
      setwd(tmpdir)

      # Create some example CSV data frames
      df1 <- table_data4()
      df2 <- table_data3()

      # Write the data frames to CSV files
      write.csv(df2, file = "basic_estimates.csv", row.names = FALSE)
      write.csv(df1, file = "consumption.csv", row.names = FALSE)

      # Zip the CSV files
      zip(zipfile,
          files = c("basic_estimates.csv", "consumption.csv"))
    },
    contentType = "application/zip"
  )









  observeEvent(input$editableTable3, {
    if (input$ch1 == 'Groups') {
      data <- hot_to_r(input$editableTable3)

      classification_list <- list(
        mammal = 'path://m439.56,144.813c-4.522,-39.83599 -45.271,-56.241 -45.271,-56.241s-11.198,32.337 -6.79001,63.26701c5.35101,37.51399 -41.853,77.83699 -141.994,77.83699c0,0 -192.82299,0 -231.951,0c-39.12,0 5.032,133.035 150.90901,138.85101c11.23599,0.44901 21.924,0.13699 32.155,-0.76199c18.55199,18.72699 46.42799,40.01898 86.75099,55.43399c15.27802,5.086 36.43298,-75.39301 -47.79102,-131.25302l2.634,-2.26898c28.08301,11.50998 47.63101,26.65198 60.86902,42.43198c51.55099,-34.32397 78.332,-82.633 90.68698,-98.26199c20.371,-25.77499 40.17001,-29.14799 70.172,-32.802c38.47202,-4.68799 52.06003,-32.80199 52.06003,-32.80199s-40.75,-25.77499 -72.44,-23.42999z',
        fish = 'path://m473.47198,266.47699l38.172,-98.60899c0.84399,-2.203 0.14102,-4.688 -1.71899,-6.10901c-1.875,-1.438 -4.453,-1.453 -6.34399,-0.063l-99.09402,73.09401c-21.32797,-2.51601 -44.39099,-53.46901 -145.92197,-78.75l29.672,-4.23401c4.73398,-0.672 8.89099,-3.43799 11.35898,-7.547c2.453,-4.09399 2.922,-9.078 1.297,-13.563l-14.922,-41.03099c-1.828,-5.01601 -6.047,-8.78101 -11.23398,-10.01601s-10.64102,0.219 -14.53101,3.875l-67.922,63.938c-109.89,2.40501 -192.281,90.85802 -192.281,119.015c3.734,23.60901 48.891,77.875 117.25,104.25c7.141,-9.96899 12.906,-19.59399 17.516,-28.76599c13.453,-26.828 17.23401,-49.875 17.23401,-65.73401c0,-6.39099 -0.625,-11.60901 -1.42201,-15.26599c-1.28099,-6.04701 2.563,-11.98401 8.60901,-13.26601c6.047,-1.297 11.98399,2.563 13.28099,8.59401c1.15601,5.453 1.89101,12.10898 1.89101,19.93799c0,19.34399 -4.578,45.81299 -19.60899,75.76599c-4.21901,8.422 -9.313,17.125 -15.328,26.01602c23.5,6.40598 49.203,9.297 76.48399,6.70297l20.25,39.453c2.047,4 5.688,6.93802 10.03101,8.09402c4.34399,1.14099 8.96899,0.40598 12.75,-2.06302l15.453,-10.10901c4.26599,-2.78098 6.90601,-7.422 7.172,-12.48398c0.23401,-5.06302 -1.93799,-9.953 -5.89099,-13.14102l-20.70302,-16.672c104.59401,-24.93799 127.95302,-77.078 149.51601,-79.625l99.09402,73.09402c1.89099,1.39099 4.46899,1.375 6.34399,-0.04703c1.85898,-1.422 2.56302,-3.922 1.71899,-6.10898l-38.17203,-98.62601zm-397.04698,7.46802c-9.26601,0 -16.781,-7.53101 -16.781,-16.78101c0,-9.26599 7.516,-16.78099 16.781,-16.78099s16.781,7.51601 16.781,16.78099c0,9.25 -7.516,16.78101 -16.781,16.78101z',
        'primary producer' = 'path://m176.692,9.90914c-0.87,0.86836 -3.327,-0.0956 -4.576,0.40346c-2.81999,1.1269 -5.842,1.8909 -8.265,4.3034c-20.717,20.623 -41.459,41.2699 -62.139,61.9286c-3.0002,2.9966 -3.9965,7.6413 -4.5023,11.431c-0.0134,0.1008 -0.1204,0.2555 -0.22141,0.2689c-1.3557,0.1806 -2.9412,0.0434 -4.2065,0.6052c-2.4825,1.1021 -5.276,2.0682 -7.4537,4.2361c-20.6083,20.5152 -41.1976,41.04221 -61.7701,61.59219c-2.2604,2.25801 -3.7738,5.73901 -4.1328,8.60701c-0.1319,1.05499 -0.4115,2.89 -0.6642,3.89999c-0.2363,0.94501 0.191,1.918 0.2214,2.89101c0.1537,4.914 3.2081,9.625 6.9372,12.978c0.0496,-0.03999 0.0981,0.03 0.1476,0c6.4839,6.297 19.171,6.55499 25.7559,0c20.7163,-20.623 41.4586,-41.27 62.1389,-61.929c2.07301,-2.07 2.481,-4.607 3.543,-6.993c0.131,-0.29601 0.635,-0.916 0.664,-1.21001c0.123,-1.271 -0.678,-3.60699 0.59,-3.766c1.036,-0.129 2.134,0.098 3.174,0c0.293,-0.027 0.884,-0.545 1.18,-0.672c2.552,-1.093 4.988,-1.601 7.159,-3.766c20.554,-20.4966 41.086,-40.9426 61.62199,-61.4575c4.86101,-4.8555 6.382,-14.7692 3.543,-20.4411c-0.88699,-1.7725 -1.53299,-4.4598 -3.321,-5.7155c-2.914,-3.3266 -6.255,-5.373 -10.11099,-6.6568c-1.597,-0.53202 -3.90901,0.3973 -5.313,-0.53796zm31.069,3.89996c-0.51801,0.518 -0.04001,2.073 0.44299,2.5551c0.59401,-0.5393 0.58701,-0.5364 1.181,-1.0758c-0.81,-0.7552 -0.814,-0.7241 -1.62399,-1.4793zm169.59099,32.8134c-0.06598,-0.0933 -0.11899,-0.0515 -0.36899,0.269c-3.02399,3.873 -9.27301,5.6305 -11.36499,9.9516c-1.98001,4.0902 -0.08902,8.8709 0,13.3137c0.00299,0.1385 0.81699,-0.2187 1.328,-0.3362c-0.51602,0.18629 -1.11301,0.3808 -1.328,0.5379c-3.617,2.6444 -5.68402,4.5582 -6.93701,8.40511c-1.36801,4.1998 0.77399,8.4589 3.98499,11.4981c-0.31699,-0.3409 -0.62997,-0.6944 -0.88599,-0.94131c-0.49301,0.43291 -1.34601,-0.6554 -1.845,-0.8742c-1.21301,-0.5321 -3.10199,-1.4683 -4.42801,-1.6137c-5.552,-0.60889 -9.94699,0.65411 -13.79999,4.0344c-3.28201,2.8788 -4.74899,8.2416 -3.39499,12.1031c0.34698,0.99 1.077,2.506 1.91898,3.429c0.26801,0.294 0.81201,0.498 0.81201,0.875c0,0.095 -0.08801,0.122 -0.14801,0.201c0.20001,0.176 0.38901,0.362 0.591,0.538c-2.646,-2.051 -5.42599,-2.995 -10.03699,-3.295c-7.96402,0.499 -13.34702,5.38499 -13.948,12.238c-0.15201,1.732 0.00998,4.018 1.03299,5.514c0.733,1.072 1.496,2.102 2.435,3.093c-0.12,-0.11301 -0.24799,-0.222 -0.36899,-0.33601c-0.09,0.079 -0.05701,0.122 -0.147,0.202c-1.733,-0.76 -3.16699,-2.015 -5.01901,-2.421c-5.72198,-1.255 -10.884,0.435 -14.83298,3.89999c-1.06702,0.936 -1.51401,2.143 -2.28802,3.16c-0.54099,0.71201 -1.09598,1.92001 -1.25497,2.757c-0.43503,2.293 -0.36301,5.334 0.81198,7.397c0.32602,0.57201 2.10501,2.868 1.771,3.16c0.14502,0.127 0.517,0.407 0.88602,0.672c-3.617,-2.745 -7.92502,-3.875 -12.767,-3.026c-1.30402,0.229 -2.67902,0.509 -3.76401,1.144c-1.521,0.88901 -2.845,1.83101 -4.207,3.02501c-0.70499,0.61899 -1.08899,1.38399 -1.69699,1.95c-0.02502,-0.017 -0.039,-0.06601 -0.07401,-0.067c-5.03302,-0.13 -10.09302,-0.026 -15.129,0c-0.06702,0 -0.10001,0.026 -0.147,0.067c-3.694,3.21399 -7.377,6.46899 -11.07001,9.683c-0.048,0.04199 -0.129,0.00999 -0.14799,0.067c-0.138,0.425 -0.09601,0.46199 0.14799,0.673c2.472,2.142 4.87799,4.271 7.38,6.38799c0.043,0.03601 0.17801,0.037 0.22101,0c2.71298,-2.32799 5.34598,-4.71999 8.04398,-7.06099c0.048,-0.041 0.08002,-0.06601 0.14801,-0.067c3.05099,-0.026 6.17401,0.049 9.22501,0c0.29999,0.388 0.306,0.711 0.59,1.20999c0.69299,1.21701 1.367,2.61601 2.509,3.63101c4.267,3.79599 8.56,7.58099 12.841,11.364c4.14899,3.666 8.30899,7.308 12.47299,10.95999c1.35602,1.19 3.702,2.52701 5.534,2.757c0.25101,0.032 0.439,0.276 0.66501,0.40401c-0.05899,2.72299 1.31201,5.66699 0,8.136c-1.62201,3.05099 -5.508,4.78799 -8.19202,7.19398c-0.04199,0.03801 -0.04199,0.097 0,0.13501c2.41202,2.168 4.95203,4.3 7.38,6.455c0.30099,0.267 0.05402,0.373 0.73801,0.202c0.065,-0.017 0.026,-0.093 0.07401,-0.13499c3.724,-3.293 9.14401,-5.617 11.21701,-9.884c1.974,-4.064 0.14697,-8.83101 0,-13.24701c-0.00201,-0.05199 -0.104,-0.013 -0.147,-0.06699c1.564,-1.35501 3.58499,-2.49901 4.944,-4.16901c3.72498,-4.57401 2.76498,-10.79001 -1.03302,-14.927c0.117,0.11501 0.25101,0.22101 0.36902,0.336c0.46298,-0.40599 2.853,1.20401 3.69,1.479c2.07098,0.68199 4.61499,0.89099 6.93698,0.74001c5.16501,-0.33601 9.51001,-3.69601 11.73401,-7.59801c1.11401,-1.95399 1.10699,-4.791 1.10699,-6.79199c0,-2.02 -1.40201,-4.62701 -3.026,-6.05101c0.20901,-0.183 0.21802,-0.117 0.36902,-0.202c1.76199,1.28101 3.89297,2.312 6.12598,2.42101c0.72302,0.03499 1.539,0.323 2.14001,-0.067c-0.091,0.07899 -0.13101,0.12199 -0.22202,0.20099c0.38501,0.33701 1.617,0.19501 1.99301,-0.13399c-0.09,-0.08 -0.05701,-0.05501 -0.14801,-0.13501c0.061,-0.05299 0.14801,-0.05899 0.14801,-0.134c0.436,0.664 2.43799,0.242 3.173,0c3.022,-0.99399 5.612,-2.76399 7.67599,-5.17799c2.53601,-2.966 2.944,-7.955 1.62299,-11.431c-0.46698,-1.23 -1.491,-2.162 -2.435,-3.16c0.25803,-0.226 0.14102,-0.103 0.36902,-0.403c5.289,4.63901 15.87399,3.095 20.147,-2.15199c0.539,-0.662 1.582,-1.548 1.845,-2.354c0.16299,-0.499 0.56998,-1.031 0.73798,-1.546c1.349,-4.14201 0.53302,-8.19901 -2.28799,-11.498c0.14502,-0.127 0.19702,-0.183 0.29501,-0.269c0.267,0.182 0.48199,0.445 0.73801,0.605c4.96899,3.113 12.24799,2.254 16.89999,-0.807c1.53598,-1.01 2.37799,-2.945 3.69,-3.765c0.03299,0.044 0.017,0.133 0.07401,0.134c5.064,0.104 10.13699,0.026 15.20297,0c0.06702,0 0.173,-0.02499 0.22101,-0.06699c3.694,-3.214 7.30301,-6.469 10.996,-9.6828c0.048,-0.0416 0.203,-0.07761 0.22202,-0.13451c0.138,-0.42419 0.022,-0.394 -0.22202,-0.60509c-2.47198,-2.1428 -4.948,-4.3126 -7.60098,-6.4551c-2.71402,2.3805 -5.36002,4.8535 -8.11801,7.1947c-0.065,0.0552 -0.20502,-0.0008 -0.29501,0c-2.86499,0.0257 -5.69598,0.0412 -8.56097,0.0673c-0.12003,0.0011 -0.26501,-0.0545 -0.36902,0c-0.715,0.3764 -0.02301,1.3395 0,1.7485c0.035,0.627 0.008,1.254 0,1.882c-0.05399,-3.3802 -0.91501,-6.6101 -3.69,-9.077c-4.20801,-3.7413 -8.47198,-7.4325 -12.69299,-11.162c-0.03201,0.02821 -0.052,0.04111 -0.07401,0.06731c-4.138,-3.7835 -8.40799,-7.44141 -12.62,-11.162c-1.625,-1.4359 -3.599,-2.573 -5.608,-2.8913c0.08801,-2.67039 -1.29901,-5.585 0,-8.0017c1.63501,-3.0454 5.508,-4.721 8.19101,-7.1275c0.151,-0.1352 -0.22702,-0.4118 -0.29501,-0.4707c-2.35098,-2.037 -4.74799,-4.0688 -7.08499,-6.1189c-0.211,-0.185 -0.229,-0.3773 -0.29501,-0.4707zm-188.77899,109.8045c-0.668,-0.08 -1.213,-0.03799 -1.476,0.47c0.326,0.315 0.66701,0.367 1.034,0.47099c-3.01799,0.56401 -6.211,1.42 -7.45399,2.62201c0.084,0.16199 0.13699,0.174 0.22099,0.33699c-1.123,-0.85199 -3.996,0.43001 -5.092,1.27701c-1.79199,1.386 -4.866,1.8 -6.86301,2.959c-1.90999,1.10699 -4.21899,3.38499 -6.347,3.89999c-2.14,0.517 -5.33299,3.66701 -7.01099,5.177c-1.12801,1.01601 -2.25601,2.088 -3.395,3.093c-7.248,6.39799 -11.715,14.59599 -14.612,22.99699c-0.39801,1.155 -1.222,2.901 -1.328,4.03401c-0.355,3.76799 -0.29601,7.57999 -0.29601,11.364c0,3.55099 1.08101,8.409 2.51001,11.63199c0.38199,0.862 1.209,2.229 1.328,3.093c0.93799,6.80301 1.41399,13.608 0,20.442c-0.34901,1.686 -0.09401,3.817 -0.81201,5.379c-1.509,3.282 -1.883,8.032 -4.20599,11.02699c-2.095,2.70001 -2.633,6.517 -4.724,9.21201c-1.157,1.49301 -1.79401,3.586 -2.509,5.31201c-3.403,8.22598 -6.436,15.84399 -6.715,25.01401c-0.099,3.224 -0.626,7.41498 0.221,10.69098c1.913,7.39902 4.2,15.853 9.37201,21.853c7.92799,9.19601 17.12399,18.36401 17.786,30.52701c0.84,15.431 -6.959,27.24301 -11.07001,41.15201c-0.403,1.36499 -0.832,4.246 -0.88499,5.51401c-0.108,2.53699 -0.108,5.06 0,7.59799c0.006,0.15201 0.343,0.185 0.369,0.336c0.36099,2.095 -0.02501,4.362 0.51599,6.45499c2.295,8.875 5.85301,17.23502 11.218,25.01401c0.034,-0.02899 0.041,-0.10501 0.07401,-0.13501c0.565,1.02802 5.037,6.74902 5.534,7.26202c-6.52,0.11697 -13.035,0.134 -19.556,0.13498c-4.91901,0 -9.844,0.16 -14.76,0c-0.16499,-0.00598 -0.195,-0.189 -0.295,-0.33701c0.038,-0.05899 0.11,-0.08099 0.147,-0.13397c1.136,-1.647 3.122,-8.414 3.174,-10.22101c0.108,-3.78101 0.16,-7.58401 0,-11.36301c-0.045,-1.05701 -0.879,-2.867 -1.181,-4.035c-0.914,-3.53299 -1.99,-7.69901 -4.354,-10.55701c-3.045,-3.67899 -5.961,-7.603 -8.045,-11.63199c-0.834,-1.61301 -1.954,-3.13699 -2.361,-4.909c-0.359,-1.56201 -0.007,-3.39902 -0.29501,-4.97601c-0.16,-0.87698 -0.841,0.35901 -0.369,-1.008c1.069,-3.10098 0.825,-6.48401 2.066,-9.68298c5.09299,-13.12802 10.759,-28.39502 0.44299,-41.21802c-5.266,-6.54599 -12.3087,-10.229 -20.295,-11.633c-4.3168,-0.759 -9.2678,-0.59201 -13.3577,-2.28601c-4.9809,-2.064 -9.4058,-4.573 -13.579,-8.60699c-5.2144,-5.04099 -6.8571,-12.10098 -10.4057,-17.819c-2.763,-4.452 -7.4212,-7.92499 -11.4389,-11.16199c-1.5394,-1.23999 -3.7465,-3.297 -5.6826,-3.76501c-0.8945,-0.216 -1.7008,-1.14499 -2.5092,-1.61398c-1.667,-0.96701 -3.5378,-1.47601 -5.1659,-2.42102c-0.3896,-0.22598 -2.1388,-1.53497 -2.583,-1.27698c-2.4486,-2.142 -6.5017,-1.75 -9.0035,-3.564c-0.4682,-0.33902 -3.1351,-1.29102 -3.3948,-0.53802c-0.218,0.63202 2.509,3.06403 2.8782,3.56403c2.2093,2.98999 4.391,6.849 5.3873,10.21997c0.5578,1.888 1.3383,4.45602 1.476,6.18701c0.1118,1.40399 -0.6617,3.23901 0.369,4.23599c-0.5803,1.83301 -0.1035,4.11801 0,6.11902c0.131,2.53198 0.4149,6.17599 1.476,8.741c0.8669,2.095 0.7599,4.54199 1.6974,6.65698c3.0871,6.96301 7.1191,12.88 13.0625,18.625c7.9415,7.67801 18.5186,10.44601 26.3463,18.35703c6.8354,6.90799 4.1083,18.715 1.9926,26.896c-0.5237,2.02499 -0.9536,3.811 -1.3284,5.98499c-0.0556,0.32199 -0.6412,0.78702 -0.6642,1.008c-0.3561,3.44302 -0.3689,6.896 -0.369,10.35501c0,1.46799 0.4993,3.85999 1.1808,5.17801c1.1737,2.26898 2.6737,4.40598 3.8376,6.65698c0.8365,1.617 2.6826,2.888 4.2066,4.034c7.12431,5.35703 16.31651,5.603 23.68961,10.35501c3.0919,1.99301 6.596,5.237 8.339,8.60699c0.674,1.302 1.603,3.077 2.657,4.23599c-0.075,0.08701 -0.06499,0.25702 -0.14799,0.336c1.311,2.53403 1.238,5.81201 2.50999,8.27103c-15.1823,0.53098 -30.4164,0.284 -45.6084,0.336c-6.1662,0.022 -13.8257,6.90399 -14.3908,12.642c-0.1167,1.18399 -0.1066,2.37399 -0.1476,3.56299c-0.1062,3.07901 -0.1656,6.13199 -0.2214,9.21201c102.7862,0.08099 102.8182,0.05399 205.6052,0.13501c0.06401,-3.54501 0.382,-8.21902 0,-12.104c-0.222,-2.25302 -1.366,-4.18002 -2.657,-6.05099c-6.45799,-9.36603 -14.959,-7.733 -26.19901,-7.733c-11.793,0 -23.556,0.18799 -35.34999,0.13498c-0.158,-0.00098 -0.257,-0.228 -0.369,-0.33701c0.679,-0.86099 2.98199,-6.694 3.543,-7.59799c4.8,-7.73401 11.104,-15.987 19.409,-20.57599c7.024,-3.88 15.091,-6.59201 22.804,-9.077c4.42101,-1.42502 9.52,-2.85901 13.431,-5.379c3.17101,-2.04401 6.84001,-3.63901 9.89,-5.85001c17.29901,-12.543 32.74701,-30.811 33.578,-51.70801c0.01501,-0.36301 0.65701,-0.84399 0.664,-1.07599c0.26001,-7.771 -0.70401,-14.13501 -2.509,-21.11401c-0.38501,-1.48898 -0.30899,-3.30798 -1.03299,-4.707c-1.86099,-3.59799 -1.66501,-7.897 -3.32101,-11.63199c-0.776,-1.75 -0.651,-3.63699 -1.181,-5.51401c-0.21698,-0.76901 -0.573,0.198 -0.664,-0.80701c-0.40601,-4.51801 -0.603,-8.827 -0.51599,-13.64999c0.01999,-1.15698 0.48499,-3.168 0.95898,-4.23599c0.32501,-0.733 0.09601,-1.89801 0.36902,-2.689c1.27499,-3.698 1.746,-7.85602 3.026,-11.56601c0.38,-1.103 0.20401,-3.36099 0.29498,-4.37c0.72501,-8.05801 -0.04398,-16.69601 -2.65698,-24.27402c-1.02499,-2.97198 -2.02002,-9.37399 -4.354,-11.83499c-2.19299,-4.23999 -4.948,-8.879 -8.561,-12.37199c-0.53299,-0.51601 -3.33899,-3.87201 -4.354,-2.89101c0.42502,0.82001 0.336,3.06201 0.36902,3.429c0.05499,0.61 0.62598,1.621 0.664,2.084c0.31799,3.84401 0.25198,7.647 0.664,11.49901c0.02197,0.19699 0.10599,0.54399 0.14798,0.806c-0.23801,0.759 -0.46799,1.724 -0.517,2.287c-0.10199,1.185 -0.04498,2.377 -0.147,3.56299c-0.034,0.39401 -0.603,0.64601 -0.664,0.942c-1.05698,5.10899 -3.035,10.321 -6.716,14.59102c-4.836,5.60999 -10.59198,10.37 -15.79298,15.39798c-6.007,5.80701 -13.241,10.48102 -17.71201,17.68399c-2.35699,3.79703 -4.619,7.04102 -5.38699,11.49902c-0.01601,0.091 -0.66301,1.42798 -0.66501,1.479c-0.10699,3.02399 -0.15799,6.05499 0,9.077c0.05901,1.112 0.903,4.267 1.476,5.51398c3.10101,6.74301 7.96501,13.31403 10.11101,20.57602c0.461,1.55899 1.674,3.16599 1.993,4.707c1.147,5.54498 0.218,11.276 -1.55,16.40601c-2.37199,6.87997 -7.638,13.16299 -12.54599,18.96198c-9.15401,10.81601 -20.99001,21.17401 -28.339,33.01501c-2.658,4.28299 -5.745,8.10001 -7.38,12.84299c-0.411,1.19101 -1.403,2.77301 -1.10699,4.16901c-0.058,-0.186 -0.125,-0.36899 -0.369,-0.60498c-0.93199,0.901 -0.839,2.81 -1.40199,3.89999c-1.90201,3.67798 -2.412,8.97 -2.509,13.112c-0.043,1.81699 -0.312,4.26898 0.22099,6.186c-5.754,0.10898 -13.03,0.33099 -18.819,0.13498c-0.123,-0.005 -0.14499,-0.16098 -0.22099,-0.26898c0.013,-0.03 0.064,-0.03799 0.07401,-0.06802c0.86699,-2.79498 -0.14801,-5.823 -0.14801,-8.741c0,-6.01797 1.207,-11.681 2.509,-17.34799c0.22,-0.957 -0.067,-1.92801 0.295,-2.89099c2.034,-5.40601 3.35201,-12.47101 6.716,-17.34799c5.215,-7.56201 10.452,-15.453 15.793,-23.19901c1.601,-2.32101 4.166,-6.01401 4.871,-8.741c0.16299,-0.629 0.439,-1.88 0.812,-2.42001c1.881,-2.728 2.23801,-6.14099 3.321,-9.28c8.202,-23.78699 -9.58699,-37.81299 -12.694,-58.83499c-1.19299,-8.07602 0.826,-16.48901 5.314,-22.99701c3.46101,-5.01901 7.48601,-10.28299 9.74101,-15.73401c0.53099,-1.28299 0.521,-2.71399 1.03299,-4.034c0.43201,-1.112 1.15001,-3.28699 1.181,-4.371c0.25101,-8.84698 -0.22299,-20.28099 -5.38699,-27.76999c-5.744,-8.32899 -12.435,-15.937 -15.27701,-25.552c-2.207,-7.46899 -2.47899,-16.89 -1.32799,-24.677c0.23099,-1.563 0.87999,-3.554 1.03299,-5.17799c0.162,-1.72501 2.82901,-8.87201 2.436,-10.22c0.033,-0.03801 0.03999,-0.097 0.073,-0.13501c0.168,0.08101 0.12801,0.054 0.29601,0.13501c1.44899,-1.40201 1.82899,-3.82401 2.87799,-5.51401c2.15701,-3.476 4.30301,-7.026 6.19901,-10.69099c-0.64,-0.04401 -1.972,0.26801 -3.026,0.403c0.27299,-0.142 0.561,-0.161 0.812,-0.403c-0.58699,-0.02901 -1.325,-0.257 -1.993,-0.336zm301.02802,73.29199c-0.07101,0.033 0.04398,0.14301 0,0.20201c-2.07901,2.77199 -4.22702,5.521 -6.34702,8.26999c-0.04498,0.058 -0.07001,0.12001 -0.147,0.13501c-15.56198,2.948 -31.15298,5.86 -46.715,8.808c-2.16199,0.41 -5.17801,1.394 -6.79001,2.69c-6.285,5.052 -9.198,9.83099 -7.74899,17.21298c0.371,1.888 0.68301,3.83801 1.10699,5.716c0.04102,0.18201 0.02802,0.38602 0.14801,0.53799c0.02798,0.035 0.427,0.09302 0.51599,0.134c-4.79999,-1.22198 -10.702,-0.45599 -15.42398,0.80701c-1.73401,0.46402 -7.01901,1.784 -8.11801,3.228c-0.30099,-0.172 -0.23999,-0.005 -0.29501,-0.26898c-0.38998,-1.884 -0.68298,-3.83801 -1.10699,-5.716c-0.203,-0.89999 -0.61301,-2.56302 -1.181,-3.42902c-0.92398,-1.40799 -1.78299,-3.11899 -3.099,-4.371c-4.522,-4.29898 -11.34198,-6.44 -17.78598,-5.24399c-15.61002,2.89499 -31.17203,5.80899 -46.789,8.67401c-1.621,0.297 -9.53702,-6.49402 -10.332,-5.51401c-2.311,2.849 -4.37601,5.82199 -6.56802,8.741c-0.15799,0.211 -0.53098,0.603 -0.29498,0.73999c4.681,2.72101 9.34601,5.439 14.09601,8.069c0.08899,0.04901 0.18997,-0.048 0.29498,-0.06699c17.38699,-3.228 34.78299,-6.48502 52.17599,-9.68301c1.927,-0.354 5.34302,1.11301 5.978,2.689c0.18402,0.45801 0.414,1.052 0.51602,1.48001c1.18399,4.923 2.38898,9.85001 3.46899,14.793c0.08701,0.397 -0.96899,2.16901 -1.181,2.55499c-0.043,0.07901 -0.04901,0.25 -0.147,0.26901c-9.147,1.77701 -18.29999,3.36301 -27.45401,5.10999c-0.078,0.01501 -0.177,0.07703 -0.22098,0.13501c-4.19202,5.47299 -8.32202,10.97699 -12.47202,16.474c-0.125,0.16501 -0.11301,0.42999 0.07401,0.53799c3.36099,1.94202 6.72101,3.87601 10.10999,5.78201c0.06601,0.03699 0.21902,0.04999 0.29501,0.06699c3.20499,-4.21399 6.409,-8.474 9.668,-12.64099c0.08301,-0.10599 0.22601,-0.10599 0.36899,-0.134c5.83801,-1.15698 11.70602,-2.36301 17.56403,-3.42999c0.099,-0.01801 0.15997,0.06699 0.22198,0.13501c0.17499,0.19498 0.23999,0.495 0.29501,0.73999c2.29099,10.14499 4.45898,20.30798 6.71597,30.45999c1.56201,7.03 3.17502,14.02701 4.79703,21.04602c0.58899,2.55298 3.66098,5.93698 6.56799,6.85797c1.16901,0.371 2.569,0.95401 3.83701,1.07602c0.28198,0.02701 1.39499,-0.37799 1.54999,0.06799c1.20999,3.47202 2.94501,6.91602 6.125,9.27899c0.73901,0.54901 1.61401,0.87201 2.362,1.41202c0.96899,0.69998 0.45499,5.181 1.62399,6.65698c0.59802,0.75601 2.07901,2.23602 2.28702,3.16c0.07898,0.349 -0.33902,0.88101 -0.44202,1.20999c-0.336,1.06403 -0.31198,2.63101 -0.29599,3.63101c0.02798,1.755 0.74399,4.71301 2.06699,6.186c0.44702,0.49799 1.34201,1.15799 1.62302,1.74899c0.27399,0.57501 -0.366,1.02402 -0.44299,1.54599c-0.17502,1.194 -0.31302,2.46701 -0.29501,3.63101c0.06601,4.09201 2.328,6.19202 4.797,8.94299c-0.60699,0.79901 -3.64398,1.10101 -4.64899,1.61401c-2.31,1.17999 -4.70602,2.69699 -6.79001,4.30301c-4.58701,3.53598 -8.23801,10.97198 -8.33899,16.07098c-0.01202,0.59201 0.017,1.17001 0.14798,1.74802c0.03601,0.15997 0.11102,0.31097 0.147,0.47098c-0.117,0.85901 0.14401,2.69202 0.29501,3.362c0.42899,-0.03299 0.45798,-0.035 0.88599,-0.06699c3.98401,-0.68399 7.91101,-1.47501 11.88202,-2.21899c-0.69101,-4.319 0.51797,-8.73203 4.72299,-11.633c0.70099,-0.48401 1.22501,-1.17401 1.992,-1.479c2.56299,-1.02002 4.90799,-1.60703 8.04498,-2.08502c0.099,-0.01498 0.27402,0.04901 0.29501,0.13501c0.944,3.86301 1.707,7.75601 2.58301,11.63199c6.38397,-1.14899 6.383,-1.13599 12.767,-2.28598c-0.84702,-3.91299 -1.73001,-7.84201 -2.509,-11.767c-0.017,-0.086 0.04999,-0.18002 0.147,-0.202c1.69299,-0.37701 3.37399,-0.67902 5.09299,-0.94101c0.746,-0.11401 2.612,-0.159 3.54199,0c6.22202,1.06299 9.84399,4.29099 11.36502,9.48099c6.38397,-1.14899 6.383,-1.13699 12.767,-2.28598c-1.12003,-7.17401 -8.27402,-14.95801 -16.38303,-17.21402c-1.32098,-0.367 -2.991,-0.48798 -4.28,-0.87399c-1.94699,-0.582 -3.58798,-0.28699 -5.60898,-0.40298c-0.405,-0.02402 -2.57202,-0.26001 -3.10001,0.13397c-1.133,0.84601 -1.733,2.22101 -2.65701,3.22803c-0.495,0.53998 -1.15198,0.85699 -1.771,1.20999c3.67102,-3.061 6.259,-6.565 5.60901,-11.16202c-0.245,-1.73499 -0.64801,-3.15399 -1.255,-4.707c-0.27301,-0.69998 -2.36301,-2.547 -2.36099,-3.09299c0.00299,-0.75101 0.504,-1.61099 0.664,-2.353c0.366,-1.69601 -0.01801,-3.88901 -0.517,-5.51401c-0.46201,-1.50699 -1.29102,-2.72299 -2.06601,-4.034c-0.202,-0.34201 -1.06,-0.68298 -1.03299,-1.14401c0.09799,-1.66699 0.80499,-3.396 0.81198,-5.10999c0.00702,-1.724 -1.03299,-3.20401 -1.40298,-4.841c-0.08099,-0.35999 1.896,-2.86801 2.21399,-3.698c0.87701,-2.28299 1.99402,-7.19501 0.73801,-9.48099c3.74899,-1.36801 7.27701,-5.53 7.74899,-8.742c0.14001,-0.952 0.14099,-1.854 -0.073,-2.82401c-1.526,-6.91101 -3.05099,-13.79901 -4.57599,-20.70999c-0.013,-0.06 -0.06,-0.14102 -0.07401,-0.202c-2.147,-9.509 -4.245,-18.99301 -6.642,-28.64401c-0.02301,0.004 -0.05002,-0.005 -0.07401,0c0.70599,-0.60101 -1.06799,-2.76801 -0.147,-2.95901c3.155,-0.65298 6.27701,-1.22098 9.44601,-1.81497c2.647,-0.496 5.31699,-1.013 7.97098,-1.48001c5.582,-0.98001 9.40601,8.276 14.90701,8.20401c0.07901,-0.00101 0.177,-0.07703 0.22101,-0.13501c2.28799,-2.97 4.543,-5.94901 6.78998,-8.94299c0.065,-0.086 0.11301,-0.405 0,-0.47c-6.20798,-3.61801 -12.46698,-7.16501 -18.745,-10.69202c-0.05899,-0.03299 -0.15198,-0.01199 -0.22098,0c-9.16702,1.68701 -18.34802,3.48401 -27.52802,5.11099c-0.133,0.02301 -0.306,-0.267 -0.36899,-0.336c-0.673,-0.75 -1.53702,-1.258 -2.36102,-1.81598c0.08401,-0.11002 0.24701,-0.207 0.22101,-0.336c-0.99799,-4.89401 -2.215,-9.77002 -3.24701,-14.659c-0.39297,-1.86002 1.04401,-4.38901 2.95203,-5.44601c0.31,-0.172 1.40698,-0.564 1.62399,-0.60501c17.22598,-3.29199 34.49899,-6.42099 51.733,-9.68298c0.85199,-0.16101 4.117,-5.06 4.871,-6.052c1.35699,-1.785 2.77499,-3.526 4.13199,-5.312c0.211,-0.27701 0.77399,-0.92101 0.88599,-1.27701c0.082,-0.261 -0.41599,-0.41299 -0.517,-0.47099c-3.21597,-1.858 -6.46597,-3.70401 -9.66699,-5.58101c-0.34601,-0.203 0.08099,-0.47899 -0.81198,-0.067z',
        bird = 'path://m438.16,457.97501c-10.96201,-0.40601 -20.79001,-5.285 -27.59399,-13.823c-2.26801,-2.84601 -5.29202,-4.47202 -8.694,-4.47202c-3.40201,0 -6.42599,1.62601 -8.694,4.47202c-6.80502,8.944 -17.38901,13.823 -28.729,13.823c-3.02402,0 -5.67001,-0.40601 -8.31601,-0.81302l-65.77301,-97.983c-7.18198,-10.56998 -17.00998,-17.48199 -28.34998,-20.32797l0,-44.72202l26.45999,0c32.508,0 62.74899,-19.922 77.491,-50.821c27.97299,-15.45 47.25101,-47.162 47.25101,-83.34599c0,-6.912 -4.914,-12.19701 -11.34,-12.19701l-37.80099,0l-102.061,0l0,-69.1166c0,-29.2728 -21.925,-52.8537 -49.14101,-52.8537c-27.21701,0 -49.14101,23.5809 -49.14101,52.8537l0,8.1313l-45.361,0c-6.42599,0 -11.34,5.2854 -11.34,12.197l0,4.0653c0,6.912 4.914,12.197 11.34,12.197c3.402,0 6.426,-1.626 8.316,-4.06499l37.045,0l0,89.44399c0,47.569 32.886,86.59901 75.601,92.69801l0,45.12799c-11.34,2.84601 -21.54599,10.16501 -28.34999,20.32901l-66.151,98.38898c-1.89,0.40701 -3.78,0.40701 -5.67,0.40701c-11.341,0 -21.925,-4.879 -28.729,-13.82401c-2.268,-2.84601 -5.292,-4.47198 -8.694,-4.47198c-3.4021,0 -6.4261,1.62598 -8.6941,4.47198c-6.8041,8.94501 -17.3883,13.82401 -28.7285,13.82401c-11.3402,0 -21.9243,-4.879 -28.7284,-13.82401c-4.1581,-5.285 -11.3402,-5.69199 -15.8763,-1.21899c-4.9141,4.47198 -5.2921,12.19699 -1.134,17.07501c11.3402,14.22998 27.9724,22.362 46.1167,22.362c13.9862,0 26.8384,-4.879 37.4226,-13.41702c10.584,8.944 23.436,13.41702 37.423,13.41702c13.98601,0 26.838,-4.879 37.422,-13.41702c10.58401,8.944 23.43701,13.41702 37.423,13.41702c13.608,0 26.838,-4.879 37.04401,-13.41702c10.58501,8.944 23.81499,14.23001 37.80101,14.23001c0.37799,0 0.37799,0 0.75598,0c13.98599,0 27.59399,-5.28601 38.17902,-14.23001c0,0 0.37799,0 0.37799,0.40601c0.37799,0.40701 0.75601,0.40701 1.134,0.814c1.134,0.81302 2.646,2.03201 3.78,2.845c0.37799,0.40701 1.134,0.814 1.51199,1.22c1.134,0.81302 2.646,1.62601 3.78,2.03302c0.37799,0.40698 1.134,0.40698 1.51199,0.81299c1.89001,0.81299 3.40201,1.62601 5.29202,2.44c0.37799,0 0.75598,0 0.75598,0.40601c1.51199,0.40698 3.02402,0.81299 4.914,1.22c0.75601,0 1.134,0.40598 1.89001,0.40598c1.51199,0.40701 2.646,0.40701 4.15799,0.81403c0.75601,0 1.134,0 1.89001,0.40598c1.88998,0.40701 4.15799,0.40701 6.04797,0.40701c13.98602,0 26.83902,-4.879 37.423,-13.41699c10.20602,8.53799 22.68002,13.41699 35.91,13.41699l0.37799,0c6.048,0 11.34003,-5.28601 11.34003,-11.79102c-0.75601,-7.31799 -5.67001,-13.00998 -12.09601,-13.00998zm-74.08899,-285.81601l0,0l0,28.459c0,5.692 -0.37802,10.978 -1.51202,16.263c-10.20599,7.72501 -22.67999,12.19701 -36.28799,12.19701c-31.75299,0 -57.83499,-24.80101 -63.12698,-56.91901l100.927,0zm-177.66301,28.459l0,-121.9696c0,-15.8561 11.71899,-28.4597 26.461,-28.4597c14.74199,0 26.45999,12.6036 26.45999,28.4597l0,93.5106c0,51.634 38.93501,93.51001 86.942,93.51001c1.134,0 2.26801,-12.19701 3.78,-12.19701c-11.341,10.16399 -26.08301,16.26299 -41.58099,16.26299l-37.80099,0c-35.53201,0 -64.261,-31.30598 -64.261,-69.11699zm102.43999,258.17c-10.96201,0 -21.54599,-5.285 -28.35098,-13.823l-0.75601,-0.81299c-2.26801,-2.84601 -5.29199,-4.47202 -8.694,-4.47202l0,0c-3.40199,0 -6.42599,1.62601 -8.694,4.47202c-6.804,8.53799 -17.388,13.823 -28.34999,13.823c-11.34001,0 -21.925,-4.879 -28.729,-13.823c-0.756,-0.81302 -1.134,-1.22 -1.89,-2.03302l45.739,-67.897c3.78,-5.69199 9.07201,-9.75699 15.12,-11.78998c0,0 0,0 0.37801,0c7.938,-2.03302 15.87601,2.84601 18.901,10.97699l30.996,84.97299c-1.51199,0 -3.02402,0.40601 -4.53601,0.40601c-1.134,0 -1.134,0 -1.134,0z',
        reptile = 'path://m399.78601,82.5471c-40.26001,26.6179 -32.591,77.63589 -57.51401,110.90889c-53.681,77.63602 -155.289,117.56302 -258.8152,128.65399c-21.0886,2.21802 -47.9287,19.96402 -57.5144,44.36401c19.1715,-6.655 49.8458,-2.21899 65.183,8.87201c0,13.30899 -38.3429,26.61798 -21.0886,51.01801c13.42001,8.87299 32.5912,8.87299 51.76321,2.21799c17.254,-13.30899 19.17099,-22.181 26.84,-39.927c82.437,19.96399 139.951,-2.21799 139.951,-2.21799c0,0 5.75198,26.61798 23.00598,39.927c19.17203,11.09097 44.095,8.87299 61.34903,0c17.254,-19.96301 -21.08902,-31.05402 -21.08902,-70.98102c0,-59.89099 15.33801,-102.036 57.51501,-146.39999c13.41998,26.618 51.763,22.18199 67.09998,-2.218c5.75101,-11.091 9.58603,-22.18201 9.58603,-35.491c0,-79.8542 -61.349,-104.2542 -86.272,-88.7269zm47.92899,77.63589c-7.66901,0 -13.41998,-6.65399 -13.41998,-15.52699c0,-8.873 5.75098,-15.52701 13.41998,-15.52701c7.668,0 13.42001,6.65401 13.42001,15.52701c0,8.873 -5.75201,15.52699 -13.42001,15.52699zm-159.12399,-2.218c-15.33701,-33.27299 -57.51401,-77.63609 -147.62001,-48.8c-99.69139,35.491 -97.77429,128.654 -82.43709,150.83601c0,0 -23.0058,11.091 -9.5857,33.27298c11.5028,15.52701 72.8518,4.436 126.5318,-15.52698c53.68001,-17.746 99.69099,-46.58202 124.614,-68.76401c23.00601,-19.964 13.42001,-55.45399 -11.50299,-51.01801z',
        detritus = 'path://m421.38,72.426c-46.56,-46.64 -108.52002,-72.356 -174.64401,-72.42c-135.93199,0 -246.61999,110.572 -246.73599,246.5c-0.064,65.916 25.548,127.90401 72.1,174.55998c46.568,46.62802 108.284,72.436 174.19601,72.436l0.57199,0l0,-0.02399c134.95601,0 246.53999,-110.59601 246.64,-246.51602c0.064,-65.91197 -25.58398,-127.89198 -72.12799,-174.53597zm-163.67999,304.7c-2.836,2.86401 -6.8,4.504 -10.87201,4.504c-4.088,-0.008 -8.064,-1.65601 -10.93199,-4.56c-2.84801,-2.82401 -4.48401,-6.79199 -4.48,-10.87601c0.008,-4.07199 1.664,-8.064 4.532,-10.92398c2.856,-2.84802 7.064,-4.48801 10.92,-4.48801c4.06,0 8.028,1.64801 10.85999,4.504c2.89603,2.92001 4.556,6.91599 4.548,10.93201c-0.004,4.03198 -1.672,8.00397 -4.57599,10.90799zm7.42398,-94.452c-1.76001,0.388 -3.01999,1.948 -3.02402,3.75198l-0.01999,18.12003c-0.008,8.48798 -6.916,15.40799 -15.43599,15.40799c-8.51201,-0.008 -15.412,-6.94 -15.40401,-15.436l0.036,-34.96399c0.00801,-8.48401 6.916,-15.08 15.416,-15.08l0.06801,0c29.48799,0 53.49998,-24.32001 53.532,-53.808c0.01199,-14.28801 -5.53601,-27.884 -15.64001,-38.024c-10.13998,-10.132 -23.56799,-15.78801 -37.88397,-15.804c-29.49202,0 -53.51201,23.95599 -53.54401,53.464c-0.008,8.49199 -6.924,15.38 -15.44,15.38c-4.12,0 -7.996,-1.62401 -10.89999,-4.54401c-2.916,-2.912 -4.508,-6.78799 -4.504,-10.90401c0.04399,-46.492 37.896,-84.32399 84.448,-84.32399c46.53198,0.048 84.34399,37.936 84.29999,84.46001c-0.03198,39.17198 -27.78,73.78796 -66.004,82.30399z',
        unidentified = 'path://m421.38,72.426c-46.56,-46.64 -108.52002,-72.356 -174.64401,-72.42c-135.93199,0 -246.61999,110.572 -246.73599,246.5c-0.064,65.916 25.548,127.90401 72.1,174.55998c46.568,46.62802 108.284,72.436 174.19601,72.436l0.57199,0l0,-0.02399c134.95601,0 246.53999,-110.59601 246.64,-246.51602c0.064,-65.91197 -25.58398,-127.89198 -72.12799,-174.53597zm-163.67999,304.7c-2.836,2.86401 -6.8,4.504 -10.87201,4.504c-4.088,-0.008 -8.064,-1.65601 -10.93199,-4.56c-2.84801,-2.82401 -4.48401,-6.79199 -4.48,-10.87601c0.008,-4.07199 1.664,-8.064 4.532,-10.92398c2.856,-2.84802 7.064,-4.48801 10.92,-4.48801c4.06,0 8.028,1.64801 10.85999,4.504c2.89603,2.92001 4.556,6.91599 4.548,10.93201c-0.004,4.03198 -1.672,8.00397 -4.57599,10.90799zm7.42398,-94.452c-1.76001,0.388 -3.01999,1.948 -3.02402,3.75198l-0.01999,18.12003c-0.008,8.48798 -6.916,15.40799 -15.43599,15.40799c-8.51201,-0.008 -15.412,-6.94 -15.40401,-15.436l0.036,-34.96399c0.00801,-8.48401 6.916,-15.08 15.416,-15.08l0.06801,0c29.48799,0 53.49998,-24.32001 53.532,-53.808c0.01199,-14.28801 -5.53601,-27.884 -15.64001,-38.024c-10.13998,-10.132 -23.56799,-15.78801 -37.88397,-15.804c-29.49202,0 -53.51201,23.95599 -53.54401,53.464c-0.008,8.49199 -6.924,15.38 -15.44,15.38c-4.12,0 -7.996,-1.62401 -10.89999,-4.54401c-2.916,-2.912 -4.508,-6.78799 -4.504,-10.90401c0.04399,-46.492 37.896,-84.32399 84.448,-84.32399c46.53198,0.048 84.34399,37.936 84.29999,84.46001c-0.03198,39.17198 -27.78,73.78796 -66.004,82.30399z',
        invertebrate = 'path://m76.6852,324.99301c0,-102.28601 54.3028,-144.78801 78.6318,-144.78801c13.90199,0 17.92799,94.744 177.425,94.744c34.42499,0 53.12399,-18.94901 58.47101,-18.94901c5.77197,0 15.72699,19.59299 15.72699,62.45499c0,115.19 -148.61499,120.32501 -172.09401,120.57101c-49.03499,0.53101 -47.85599,44.35999 -76.17899,44.35999c-14.53101,0 -81.9818,-74.33698 -81.9818,-158.39297zm110.0848,-163.73701c0,11.123 37.649,75.795 131.45699,75.795c36.89401,0 88.71301,-24.93599 88.71301,-59.53699c0,-15.67101 -3.38199,-25.73201 -7.974,-25.73201c-3.271,0 -20.177,9.474 -41.832,9.474c-67.35599,0 -71.93301,-56.84599 -76.00601,-56.84599c-38.78099,0 -94.35799,45.72299 -94.35799,56.84599zm220.17,-113.69279c0,-7.8448 -4.45099,-18.9488 -15.72699,-18.9488c-11.276,0 -14.24802,19.6878 -19.61102,27.4c-8.052,-1.6486 -16.76398,3.6571 -20.41299,12.4683c-0.534,1.3075 -1.022,2.72861 -2.013,3.5624c-1.336,1.118 -3.11301,0.7769 -4.733,0.56841c-11.52798,-1.4401 -31.862,7.5038 -31.862,12.8473c0,5.3436 1.62,37.8972 59.17902,37.8972c13.634,0 35.17999,-5.229 35.17999,-13.832c0,-4.794 0,-54.118 0,-61.9628z',
        inverte = 'path://m207.38499,292.164c-10.894,0 -16.70399,27.79901 -38.491,27.79901c28.323,0 45.75301,-2.08502 50.83701,-6.95001c-1.453,-7.64499 -6.536,-16.67999 -12.34601,-20.849l0,0zm-76.98199,0c-5.81,4.16901 -10.168,13.20401 -12.346,20.849c5.083,4.86499 22.51301,6.95001 50.837,6.95001c-21.78799,0 -27.59799,-27.79901 -38.491,-27.79901l0,0zm122.009,-57.683l-58.826,25.019l55.194,-33.35899c-5.08299,-12.509 -13.07201,-26.40901 -24.692,-36.834l-39.217,61.853l30.502,-69.49701c-10.16701,-7.64499 -23.966,-13.205 -39.94301,-14.595l-6.536,83.397l-6.536,-83.397c-15.978,1.39 -29.776,6.95001 -40.67,13.90001l30.502,69.49699l-39.217,-62.54799c-11.62,11.12 -19.6086,25.01999 -24.6923,37.52899l55.9203,33.35899l-58.8253,-25.019c-0.7262,2.78 -2.1787,6.255 -2.9049,9.03401c-2.905,10.42499 3.6312,21.54498 15.2511,25.01898c12.3461,3.47501 29.0501,10.42502 42.12209,20.85001c13.79901,11.814 16.70401,24.32401 29.776,24.32401c13.07201,0 15.97701,-14.595 29.05,-24.32401c13.798,-10.42499 29.049,-16.67999 41.396,-20.155c11.619,-3.474 18.15599,-14.59399 15.25101,-25.71399c-0.72701,-2.77901 -2.179,-5.55901 -2.905,-8.339zm47.976,-60.964c-1.207,-1.785 -2.33099,-3.653 -3.32999,-5.605c-2.87201,4.02699 -6.992,7.01599 -11.94501,8.386c-5.16202,1.411 -10.36502,0.91299 -15.60901,0.789c-7.95001,-0.20801 -20.27,-0.623 -23.101,8.05299c4.87,0 9.82301,0.08301 14.61,0.83c2.87201,0.457 5.453,1.37 7.992,2.69901c2.37201,1.20399 4.745,2.65599 7.40799,3.155c3.33002,0.62199 6.61801,-0.125 9.61502,-1.744c2.16498,-1.162 4.70398,-2.491 6.452,-4.276c2.91299,-2.94701 5.66098,-7.26401 10.23898,-7.513c0.58301,-0.04201 1.082,0.12399 1.457,0.41499c-1.29001,-1.661 -2.58099,-3.40399 -3.78799,-5.189zm34.38101,33.87401c-0.25,-0.41501 -0.33301,-0.83 -0.33301,-1.20401c-5.703,-2.823 -11.405,-6.435 -15.77499,-10.959c-0.70801,-0.748 -1.41501,-1.495 -2.08102,-2.242c-9.32397,1.494 -13.06998,14.48801 -15.19299,22.20901c-1.62299,5.812 -4.66199,11.084 -9.73999,14.52899c-2.62201,1.785 -5.61899,3.23801 -8.19901,5.02299c4.66101,-2.2 9.28201,-4.48299 14.651,-4.98099c2.74701,-0.24901 5.61899,-0.41501 8.28299,-1.121c1.37302,-0.37401 4.87003,-1.07901 4.91101,-3.03c0.08401,-1.82701 1.87299,-2.65701 3.164,-2.283c2.039,-7.265 5.03601,-14.239 7.65799,-21.29601c1.04102,-2.73999 5.12,-0.70599 4.121,2.03401c-3.20499,8.63399 -7.034,17.103 -8.741,26.194c-0.832,4.39999 -1.41501,9.299 -0.08301,13.65799c0.79102,2.65601 2.20602,4.774 4.16202,6.351c-0.66602,-7.804 2.58099,-15.567 6.16098,-22.45799c0.99802,-1.951 2.49701,-3.985 3.16302,-6.019c0.58298,-1.744 1.28998,-3.446 1.95599,-5.14801c0.70801,-1.827 1.457,-3.653 1.87299,-5.56299c0.29202,-1.12001 0.66602,-2.65601 0.04202,-3.694zm50.82098,-121.2579c-2.87201,-1.2454 -5.91,-2.1587 -8.98999,-2.7813c-6.077,-1.2454 -12.237,-1.9096 -18.439,-1.1209c-11.36301,1.453 -22.06,5.8118 -33.00702,9.00819c1.082,3.9852 1.95599,8.05341 3.16299,12.0389c1.207,3.943 2.58102,8.302 5.49402,11.416c7.16,-4.484 14.319,-8.884 21.728,-12.952c5.66,-3.11369 11.44598,-6.1026 17.35599,-8.7594c4.74503,-2.1586 9.61502,-4.4418 14.73502,-5.68719c-0.66602,-0.4566 -1.332,-0.8717 -2.04001,-1.1623zm-75.58701,99.3389c-1.70599,-1.951 -3.41299,-3.90199 -5.078,-5.895c0.62402,1.32901 0.08301,3.19701 -1.78998,3.28c-2.12201,0.12401 -3.70401,2.20001 -5.03601,3.69501c-1.41501,1.577 -2.87201,3.44499 -4.745,4.44099c-2.87201,1.53601 -5.36902,3.57001 -8.491,4.608c-0.33301,0.08301 -0.62399,0.20801 -0.957,0.291c-0.08401,0.74701 -0.54199,1.453 -1.41602,1.785c-2.08099,0.83 -3.07999,3.73599 -3.995,5.604c-1.20801,2.44899 -2.62299,4.93999 -4.32901,7.05699c-2.12299,2.657 -4.745,4.608 -7.534,6.435c9.19901,-0.25 18.48102,-0.457 27.34601,2.07501c0.375,0.08299 0.66602,0.24899 0.91602,0.45699c0.04199,-0.125 0.125,-0.20799 0.16599,-0.33199c1.20801,-2.45001 1.832,-5.02301 2.62302,-7.63901c2.53897,-8.136 6.74298,-19.13699 15.39999,-22.209c-0.957,-1.245 -2.039,-2.44901 -3.08002,-3.653zm97.73102,-89.7911c-4.20401,-6.0193 -12.94501,-5.6456 -19.272,-3.9436c-5.61902,1.4944 -10.98801,4.0267 -16.233,6.5174c-5.99301,2.8233 -11.862,5.9363 -17.64801,9.2153c-10.86301,6.186 -21.311,12.994 -31.883,19.594c-8.616,5.397 -17.73099,10.835 -24.30798,18.68099c0.08398,0.29001 0.08398,0.664 -0.04102,1.03801c-1.12399,4.27499 -0.91599,8.427 0.16602,12.412c1.20697,0.16599 2.16498,1.07899 1.70697,2.532c-0.125,0.41499 -0.29199,0.789 -0.41599,1.20399c1.62299,3.90199 3.95401,7.597 6.57599,11.04201c3.08002,4.069 6.45203,7.84599 9.86502,11.66499c0.832,0.914 1.62299,1.868 2.45499,2.782c0.75,0.29001 1.24899,0.91299 1.41602,1.619c1.03998,1.203 2.164,2.32401 3.371,3.40399c5.702,5.02301 12.65298,9.091 19.85397,11.582c4.246,1.45201 9.44901,2.53201 13.73602,1.07901c-0.33301,-0.332 -0.625,-0.74701 -0.99902,-1.20401c-1.49899,-1.827 0.66602,-3.819 2.49701,-3.362c5.203,-8.261 11.73801,-15.56799 17.98102,-22.998c3.37198,-4.02699 6.702,-8.09499 9.65698,-12.41299c2.99701,-4.39999 5.49402,-9.174 7.90799,-13.948c5.078,-10.08701 9.69803,-20.59 12.69501,-31.508c1.37399,-4.89799 2.664,-10.004 3.039,-15.069c0.20801,-3.362 -0.125,-7.0982 -2.12299,-9.9211zm16.77399,63.38911c-1.082,-2.03401 -2.62201,-4.10901 -3.20499,-6.39301c-1.37402,-5.106 -1.12402,-10.25301 -1.582,-15.442c-0.29102,-3.487 -0.37402,-7.01601 -0.582,-10.544c-0.375,-5.355 -0.625,-13.658 -5.12,-17.68501c-0.29102,2.159 -0.70801,4.276 -1.16501,6.31001c-2.62302,11.873 -7.16,23.32999 -12.40399,34.24799c-2.16501,4.483 -4.371,9.05 -6.91,13.367c4.32898,1.827 8.53299,4.442 13.19498,5.189c3.621,0.58101 7.70001,0.04201 11.32101,-0.37399c2.24799,-0.24901 6.49399,-0.58101 7.409,-3.11301c0.625,-1.65999 -0.16599,-4.06799 -0.957,-5.56299zm4.37,-1.453c-1.12299,-2.44901 -2.74698,-4.56601 -3.45398,-7.22301c-0.87402,-3.27899 -0.91602,-6.808 -0.91602,-10.17c-0.04199,-3.778 -0.45801,-7.597 -0.66599,-11.375c-0.375,-7.721 -0.832,-16.729 -6.327,-22.748c-0.832,-0.95499 -1.914,-1.661 -3.03802,-2.284c-0.04199,0 -0.04199,-0.041 -0.08298,-0.041c-0.04202,-4.691 -1.16602,-9.2159 -4.70401,-12.869c-3.746,-3.8606 -9.11499,-4.93999 -14.401,-4.7324c-0.29199,-0.3321 -0.75,-0.5812 -1.332,-0.6227c-2.62299,-0.2075 -4.57901,-2.7813 -6.91,-3.8191c-3.03799,-1.3284 -6.285,-2.2002 -9.53101,-2.8644c-6.202,-1.3284 -12.65399,-1.9095 -18.97998,-1.2869c-12.737,1.3284 -24.68301,6.55901 -36.92001,9.9215c-1.24899,0.3321 -1.74799,1.785 -1.41501,2.9059c2.62201,8.6761 3.53802,19.5521 9.698,26.6921c-2.33099,1.453 -4.66199,2.94801 -6.99298,4.401c-9.24002,5.811 -18.81302,11.416 -26.34702,19.386c-0.99899,1.03799 -1.87299,2.159 -2.74698,3.27901c-0.66602,0.91399 -0.58301,1.90999 -0.125,2.657c-1.24902,5.521 -0.54102,10.918 1.28998,16.024c-2.78799,5.76999 -8.82397,9.25699 -15.19199,9.797c-4.745,0.41499 -9.65701,-0.20801 -14.40201,-0.24901c-10.15599,0 -22.80899,2.283 -23.84999,14.52901c-0.125,1.536 0.83299,2.698 2.414,2.698c5.661,0 11.364,0 16.98299,0.87199c5.53601,0.87201 9.90601,4.85701 15.44202,5.85301c0.25,0.04199 0.54099,0.08299 0.79099,0.125c-0.41699,0.58099 -0.83301,1.20399 -1.207,1.868c-1.37399,2.40799 -2.62299,4.85699 -3.996,7.265c-3.164,5.562 -9.48999,8.136 -14.48499,11.623c-1.998,1.37 -0.79102,4.19299 1.457,4.151c11.11301,-0.041 22.60098,-1.24501 33.465,1.57799c-1.12399,1.20401 -2.37302,2.283 -3.78799,3.19601c-5.702,3.86099 -12.19601,6.31 -15.06802,13.077c-0.78998,1.868 0.83301,3.73599 2.789,3.155c4.74503,-1.37 8.99103,-3.90201 13.444,-5.854c3.62201,-1.619 7.16,-2.2 11.03,-2.573c3.62201,-0.37399 8.74103,-0.914 11.98801,-3.19701c-0.83298,5.02301 -0.99899,10.33701 0.58301,15.27701c1.62299,5.02299 5.577,8.759 10.44699,10.58499c1.83102,0.70599 3.871,-0.74699 3.16299,-2.78099c-3.24597,-9.755 2.58102,-19.884 7.07602,-28.27c1.74799,-3.27899 3.07999,-7.05699 4.28699,-10.58499c0.70801,-2.076 1.37399,-4.35901 1.29102,-6.51801c6.202,2.44901 13.36099,4.06799 19.68698,1.661c2.33102,-0.914 4.41202,-2.491 5.95203,-4.442c1.29099,-1.61899 -0.04102,-3.612 -1.58102,-3.819c5.452,-8.22 12.237,-15.48399 18.48001,-23.03999c3.20499,-3.86 6.202,-7.804 8.94901,-11.99701c4.70398,1.91 9.116,4.48401 14.11099,5.604c4.07901,0.955 8.61499,0.291 12.73599,-0.12399c3.45502,-0.332 7.534,-0.955 10.11502,-3.52901c2.996,-2.90599 2.414,-7.638 0.78998,-11.16699zm-100.60199,-54.339c-1.207,-3.9855 -2.082,-8.0122 -3.164,-12.0389c10.94699,-3.1964 21.64401,-7.5552 33.00699,-9.00819c6.20203,-0.7887 12.362,-0.1245 18.43903,1.1209c3.07999,0.6226 6.11899,1.4944 8.991,2.7813c0.707,0.2906 1.37299,0.7057 1.95599,1.1623c-5.11902,1.2454 -9.98901,3.52859 -14.73401,5.68719c-5.91101,2.6983 -11.655,5.64571 -17.35699,8.7594c-7.409,4.068 -14.56799,8.468 -21.72699,12.952c-2.789,-3.114 -4.20401,-7.473 -5.41101,-11.416zm-51.77899,88.54601c-2.664,-0.49901 -5.03702,-1.91 -7.409,-3.155c-2.58102,-1.32901 -5.16101,-2.242 -7.992,-2.69901c-4.828,-0.74699 -9.74001,-0.83 -14.61002,-0.83c2.83101,-8.717 15.151,-8.302 23.10101,-8.05299c5.28598,0.12399 10.448,0.664 15.60901,-0.789c4.91098,-1.37001 9.07397,-4.40001 11.94598,-8.386c0.99899,1.91 2.12201,3.778 3.32901,5.605c1.20798,1.785 2.49799,3.528 3.871,5.23c-0.37402,-0.28999 -0.87402,-0.45599 -1.45602,-0.41499c-4.57898,0.24899 -7.32599,4.56599 -10.23999,7.51399c-1.74799,1.785 -4.245,3.11301 -6.45099,4.276c-3.08002,1.57701 -6.36902,2.32401 -9.698,1.70201zm-9.823,24.94899c2.78799,-1.78499 5.41098,-3.778 7.53299,-6.435c1.707,-2.117 3.12201,-4.608 4.32901,-7.05699c0.91599,-1.86801 1.87299,-4.774 3.996,-5.604c0.91599,-0.332 1.332,-1.03799 1.41498,-1.785c0.33301,-0.08299 0.62402,-0.166 0.957,-0.291c3.164,-1.03799 5.66101,-3.03 8.492,-4.608c1.87302,-1.037 3.32901,-2.905 4.745,-4.44099c1.332,-1.453 2.87201,-3.571 5.03601,-3.69501c1.87299,-0.08299 2.414,-1.993 1.79001,-3.28c1.62299,1.99301 3.371,3.98601 5.078,5.895c1.03998,1.20399 2.12299,2.408 3.16299,3.612c-8.65701,3.07201 -12.90302,14.03101 -15.39999,22.209c-0.79102,2.61501 -1.41602,5.189 -2.62302,7.638c-0.04099,0.125 -0.125,0.20801 -0.16599,0.332c-0.25,-0.207 -0.54102,-0.373 -0.91602,-0.45599c-8.94901,-2.533 -18.23099,-2.28401 -27.42899,-2.03401zm68.095,-5.72899c-0.41602,1.909 -1.16602,3.73599 -1.87302,5.56299c-0.66599,1.70201 -1.41501,3.40401 -1.957,5.147c-0.66501,2.076 -2.164,4.11 -3.16299,6.019c-3.57901,6.89101 -6.82599,14.696 -6.16,22.459c-1.95599,-1.57799 -3.37201,-3.69499 -4.16199,-6.35199c-1.332,-4.35901 -0.75,-9.257 0.08298,-13.657c1.70602,-9.13301 5.53601,-17.56001 8.74103,-26.19501c0.99899,-2.74001 -3.08002,-4.774 -4.121,-2.034c-2.62201,7.099 -5.61902,14.03099 -7.65903,21.29599c-1.332,-0.332 -3.12097,0.498 -3.16299,2.283c-0.08298,1.951 -3.53799,2.698 -4.91098,3.03101c-2.70602,0.705 -5.53601,0.871 -8.28302,1.12c-5.37,0.49901 -9.98999,2.782 -14.65198,4.98199c2.62299,-1.827 5.57797,-3.23799 8.19998,-5.02299c5.12,-3.446 8.15799,-8.718 9.73999,-14.52899c2.12302,-7.722 5.86902,-20.71501 15.19202,-22.21001c0.70801,0.748 1.37399,1.495 2.08099,2.242c4.371,4.52499 10.03101,8.13699 15.77499,10.959c0,0.37399 0.08401,0.789 0.33301,1.20399c0.58301,1.08 0.20901,2.616 -0.04099,3.69501zm51.44598,-44.95801c-2.95499,4.35901 -6.285,8.427 -9.65698,12.412c-6.285,7.472 -12.82001,14.737 -17.98102,22.998c-1.87299,-0.457 -3.996,1.536 -2.49701,3.36299c0.37402,0.45601 0.66602,0.871 0.99902,1.203c-4.28702,1.453 -9.49002,0.37401 -13.73602,-1.07899c-7.20099,-2.491 -14.15198,-6.55901 -19.85397,-11.582c-1.207,-1.03799 -2.289,-2.2 -3.371,-3.40401c-0.16702,-0.70599 -0.66602,-1.37 -1.41602,-1.61899c-0.79001,-0.91301 -1.62299,-1.86801 -2.45499,-2.78101c-3.41299,-3.778 -6.785,-7.597 -9.86502,-11.66499c-2.58099,-3.40401 -4.953,-7.14 -6.57599,-11.043c0.16599,-0.41501 0.29099,-0.78801 0.41599,-1.203c0.45801,-1.453 -0.5,-2.367 -1.70697,-2.533c-1.082,-3.985 -1.29001,-8.136 -0.16602,-12.412c0.08301,-0.373 0.125,-0.74699 0.04102,-1.03799c6.577,-7.88701 15.69199,-13.325 24.30798,-18.68c10.57199,-6.60101 21.061,-13.409 31.883,-19.594c5.78601,-3.28 11.655,-6.351 17.64801,-9.2158c5.245,-2.4907 10.61398,-4.98151 16.233,-6.5174c6.327,-1.7021 15.06799,-2.0757 19.272,3.9436c1.95599,2.82291 2.33099,6.5586 2.08099,9.8796c-0.375,5.065 -1.66501,10.21201 -3.03799,15.069c-3.039,10.918 -7.617,21.42101 -12.69501,31.508c-2.41501,4.81601 -4.87,9.548 -7.867,13.99001zm39.25,-1.411c-0.957,2.573 -5.16101,2.864 -7.409,3.11299c-3.621,0.41501 -7.70001,0.955 -11.32101,0.37401c-4.66199,-0.748 -8.866,-3.321 -13.19498,-5.189c2.539,-4.31801 4.745,-8.843 6.91,-13.367c5.24399,-10.918 9.73999,-22.376 12.40399,-34.248c0.457,-2.034 0.87399,-4.193 1.16501,-6.31001c4.45398,4.027 4.745,12.288 5.12,17.68401c0.24899,3.48699 0.29099,7.016 0.582,10.544c0.45798,5.231 0.20798,10.33701 1.582,15.44299c0.62399,2.242 2.12299,4.35901 3.20499,6.39301c0.79102,1.453 1.582,3.86101 0.957,5.563zm-21.54599,102.21098c8.29999,-22.96199 14.207,-7.50998 20.66098,-16.22598c2.40601,-3.13501 0.68701,-7.66301 -3.095,-9.75301c-7.45099,-3.922 -16.18698,4.73 -22.41397,24.56099c1.668,0.36603 3.28699,0.836 4.84799,1.418zm-16.823,-2.013c-3.229,-24.72198 9.15601,-14.02399 11.009,-24.66298c0.68799,-4.18001 -2.75101,-7.315 -7.22,-7.315c-8.06302,0 -11.966,12.35899 -8.35501,32.946c1.461,-0.42502 2.97,-0.76599 4.56601,-0.96802zm-54.31799,72.87201c0,-19.56299 -14.39301,-24.73199 -22.005,-24.73199c-8.55103,0 -12.37802,5.24899 -12.37802,10.45001c0,4.47998 2.565,11.14697 9.62701,11.14697c1.89801,0 3.439,1.56003 3.439,3.483c0,1.923 -1.54099,3.483 -3.439,3.483c-10.72,0 -16.50299,-9.33499 -16.50299,-18.11298c0,-8.65302 6.61499,-17.41702 19.254,-17.41702c11.60699,0 28.88098,8.44 28.88098,31.69901c0,16.13101 -3.54498,18.05099 -7.629,21.75c0,0.08301 0.034,0.129 0.03799,0.21201c7.66702,-0.59201 14.15201,-3.323 19.31601,-8.172c6.21301,-5.83401 11.48401,-13.703 12.34,-22.80499c0,-0.01401 0.00299,-0.04202 0.00299,-0.04202c1.29001,-27.53998 -22.655,-50.509 -51.57397,-50.509c-14.427,0 -28.31702,5.83801 -38.10602,16.01703c-9.01898,9.37299 -13.80099,21.65598 -13.46799,34.62399c0.561,15.069 6.95898,28.905 17.28799,38.43201c7.392,1.422 13.069,1.34799 13.16101,1.34799c9.077,-0.58801 20.358,-1.62302 25.77399,-4.36401c4.20099,-2.00299 15.98102,-11.08398 15.98102,-26.491zm58.44998,-66.18399c-16.53799,0 -24.06799,14.62601 -24.06799,28.215c0,2.26801 -0.07501,4.849 -0.22299,7.55899c2.66498,6.72302 3.94,13.90601 3.655,21.23502c0,0.04099 0.00699,0.07599 0.00699,0.11798c0,0.03101 -0.004,0.06601 -0.004,0.09402c-0.00299,0.04898 0.004,0.09097 0,0.13898l0,0.13602l-0.013,0.13599l-0.004,0.091l-0.01999,0.14902c-1.17603,12.332 -8.53403,21.60098 -14.50702,27.20898c-0.83499,0.78699 -1.70499,1.522 -2.599,2.215c-0.00299,0.004 -0.00299,0.004 -0.00699,0.00702c-0.38101,0.29999 -0.78702,0.56497 -1.17599,0.84698c-0.03101,0.021 -0.065,0.04501 -0.09201,0.06601c-0.478,0.341 -0.94601,0.68298 -1.43799,1c-0.00702,0.00299 -0.01001,0.00699 -0.01703,0.00998c-0.52197,0.33502 -1.06598,0.64102 -1.60199,0.948c-0.00699,0.00302 -0.017,0.01001 -0.02798,0.01401c-1.901,1.08301 -3.89902,1.992 -5.996,2.72702c-0.12,0.04199 -0.237,0.09097 -0.358,0.13199l-0.00302,0c-2.54099,0.86099 -5.23297,1.45001 -8.05197,1.80099c-0.43701,0.06 -0.87701,0.108 -1.32101,0.15399c-0.26401,0.02402 -0.51501,0.069 -0.784,0.08701l-7.09302,0.547l-0.017,-0.42899c-2.19699,1.798 -4.198,3.03101 -5.59698,3.69998c-0.64301,0.32703 -1.35901,0.61603 -2.10101,0.89502c-0.375,0.146 -0.75699,0.289 -1.15198,0.42499c-3.823,1.36902 -7.02103,1.76199 -7.17902,1.79401c-0.07599,0.01401 -0.16199,0.02798 -0.237,0.04099c-0.03101,0.00702 -0.06198,0.01102 -0.09,0.01401c-0.90799,0.164 -1.815,0.32101 -2.75699,0.45999c-0.004,0 -0.01102,0.00403 -0.01401,0.00403c-0.14099,0.021 -0.285,0.03799 -0.42599,0.05899c-4.65601,0.66501 -9.66202,1.09 -14.448,1.397l-0.21002,0.01401l-0.19598,0l-0.185,0l-0.02402,0c-0.258,0 -0.66098,-0.00702 -1.12799,-0.01801c0,0 -0.004,0 -0.00699,0c-0.20001,-0.00302 -0.40601,-0.01001 -0.63602,-0.017c-0.004,0 -0.00699,0 -0.00998,0c-0.58502,-0.021 -1.29001,-0.05902 -2.07001,-0.10501c-0.01801,-0.00299 -0.02802,-0.00299 -0.04501,-0.00299c-0.07199,-0.00702 -0.14798,-0.01102 -0.22,-0.01801c-1.616,-0.104 -3.57898,-0.29199 -5.811,-0.599c-0.00699,0 -0.013,-0.00299 -0.01999,-0.00299c-0.073,-0.01102 -0.14499,-0.02103 -0.21701,-0.03201c-1.29999,-0.18399 -2.66498,-0.397 -4.112,-0.67499l-1.905,-0.37003l-0.04099,-0.03799c-3.42801,-0.75598 -7.117,-1.811 -10.814,-3.28799c-6.862,0.91602 -10.11801,2.54599 -10.11801,6.353c0,15.91299 71.60501,16.37201 79.767,16.37201c69.19202,0 71.43701,-51.884 71.513,-74.14999c8.19699,-4.66101 13.75699,-13.55402 13.75699,-22.33902c0,-13.82898 -12.34,-25.07999 -27.50699,-25.07999z',
        inver = 'path://m76.6852,324.99301c0,-102.28601 54.3028,-144.78801 78.6318,-144.78801c13.90199,0 17.92799,94.744 177.425,94.744c34.42499,0 53.12399,-18.94901 58.47101,-18.94901c5.77197,0 15.72699,19.59299 15.72699,62.45499c0,115.19 -148.61499,120.32501 -172.09401,120.57101c-49.03499,0.53101 -47.85599,44.35999 -76.17899,44.35999c-14.53101,0 -81.9818,-74.33698 -81.9818,-158.39297zm110.0848,-163.73701c0,11.123 37.649,75.795 131.45699,75.795c36.89401,0 88.71301,-24.93599 88.71301,-59.53699c0,-15.67101 -3.38199,-25.73201 -7.974,-25.73201c-3.271,0 -20.177,9.474 -41.832,9.474c-67.35599,0 -71.93301,-56.84599 -76.00601,-56.84599c-38.78099,0 -94.35799,45.72299 -94.35799,56.84599zm220.17,-113.69279c0,-7.8448 -4.45099,-18.9488 -15.72699,-18.9488c-11.276,0 -14.24802,19.6878 -19.61102,27.4c-8.052,-1.6486 -16.76398,3.6571 -20.41299,12.4683c-0.534,1.3075 -1.022,2.72861 -2.013,3.5624c-1.336,1.118 -3.11301,0.7769 -4.733,0.56841c-11.52798,-1.4401 -31.862,7.5038 -31.862,12.8473c0,5.3436 1.62,37.8972 59.17902,37.8972c13.634,0 35.17999,-5.229 35.17999,-13.832c0,-4.794 0,-54.118 0,-61.9628z'
      )

      # Clean up 'category' values by removing leading/trailing white spaces and convert to lowercase
      data$category <- tolower(trimws(data$category))

      # Map 'category' values to their corresponding symbols
      data$symbol <- sapply(data$category, function(cat) {
        symbol <- classification_list[[cat]]
        if (is.null(symbol)) {
          # If 'cat' doesn't match any entry in the classification_list, return NA
          NA
        } else {
          symbol
        }
      })
      #emoji
      classification_list2 <- list(
        mammal =  'path://m115.089,80.352c-19.93079,-0.4459 -42.68719,8.2031 -42.68719,20.219c0,21.361 35.9702,10.67 47.9692,32.03101c0.268,0.478 0.544,0.72 0.812,1.125c2.614,23.23399 11.959,52.28099 23.188,52.28099c11.233,0 20.60899,-29.073 23.218,-52.312c0.25999,-0.394 0.521,-0.631 0.782,-1.09399c11.998,-21.36101 48,-10.67001 48,-32.03101c0,-21.3614 -72,-32.042 -72,0c0,-14.0185 -13.78,-19.8722 -29.28201,-20.219zm360.93801,34.40601c-8.43701,0.501 -28.69101,20.521 -55.68802,28.531c-35.995,10.681 -83.96698,-21.361 -71.96799,0c11.064,19.69901 32.36801,48.42101 73.25,52.782c-3.27301,19.08 2.28201,42.03799 -25.28201,64.718c-24.09299,19.83398 -36.25198,13.96799 -95.96799,-21.40601c-35.996,-21.31799 -84.009,-42.687 -156,-42.687c-86.1498,0 -95.9692,52.61501 -95.9692,117.50002c0,28.41699 1.8916,54.46298 11.25,74.78098c0.0355,0.077 0.0893,0.142 0.125,0.21902c1.3751,2.961 2.9128,5.79498 4.625,8.5c0.6395,1.01099 1.40369,1.93298 2.0937,2.90598c1.2682,1.78802 2.553,3.564 4,5.21902c0.8195,0.93698 1.7453,1.79398 2.625,2.68698c1.4597,1.48199 2.9609,2.927 4.5938,4.28101c1.09019,0.905 2.26649,1.74799 3.4375,2.59399c1.7047,1.23199 3.492,2.397 5.375,3.5c1.2331,0.72299 2.4998,1.42801 3.8125,2.09399c2.0739,1.052 4.28239,2.00101 6.5625,2.90601c1.4617,0.58002 2.9191,1.17001 4.4692,1.68802c2.388,0.79797 4.958,1.47897 7.562,2.125c1.626,0.40198 3.193,0.84598 4.906,1.18698c3.011,0.60101 6.273,1.03201 9.563,1.43802c1.618,0.19897 3.125,0.474 4.812,0.625c5.08499,0.45499 10.41299,0.71799 16.157,0.71799c35.647,0.00101 127.55099,-0.31201 156,-0.31201c23.99701,0 62.888,-7.09998 95.96799,-31.71899c3.83301,-2.85199 7.38702,-5.92801 10.81302,-9.09399c1.272,-1.16501 2.49799,-2.358 3.71899,-3.56201c1.802,-1.798 3.53299,-3.65198 5.21799,-5.53098c22.86301,-25.108 35.854,-57.039 40.28201,-88.625c-0.02899,0.06299 -0.06601,0.12399 -0.09399,0.18698c6.84198,-39.457 2.97998,-77.679 -4.625,-99.937c29.62,-12.205 28.68698,-53.05499 28.68698,-71.125c0,-5.341 -1.5,-7.355 -4.31198,-7.188zm-374.90601,184.87499c9.118,0 16.5,7.802 16.5,17.43802c0,9.63599 -7.382,17.43698 -16.5,17.43698c-9.1191,0 -16.5317,-7.80099 -16.5317,-17.43698c0,-9.63602 7.4125,-17.43802 16.5317,-17.43802z',
        # Whale emoji: 🐋
        fish = 'path://m205.188,80.7812c-16.78,0.00011 -33.24001,30.4448 -36.84401,64.40681c-73.35699,19.08099 -110.96899,81.035 -111.09399,129.812c3.2441,3.03201 11.5988,8.65201 21.6875,15.18799c27.0765,17.539 68.1205,42.75803 67.59351,50.46802c-0.72301,10.58301 -28.394,-1.121 -38.687,-3.56201c-13.1782,-3.11301 -19.5259,-5.58798 -24.0002,-6.46899c-1.8088,-0.35599 -3.397,-0.51501 -4.875,-0.25c-10.4677,4.103 -6.9193,15.35199 -3.0313,21.78101c18.6673,33.35901 90.79449,59.59399 151.53149,59.59399c7.91901,0 15.81601,-0.73801 23.68701,-1.78101c19.91,12.02402 45.789,21.25 71.81299,21.25c22.51501,0 4.733,-18.909 -9.375,-39.31299c26.276,-11.57901 50.367,-27.004 70.125,-43.375c24.564,37.49298 63.78302,66.25 91.09302,66.25c18.97897,0 37.948,-17.92801 18.96899,-37.40601c-18.979,-19.453 -37.96899,-70.25 -37.96899,-95.81299c0,-12.78101 18.978,-79.40901 37.96899,-98.87401c18.96698,-19.466 0.00998,-40.46901 -18.96899,-40.46901c-25.48203,0 -61.345,31.856 -86,68.343c-3.70502,-3.093 -7.504,-6.166 -11.53101,-9.218c-35.54901,-74.81599 -123.078,-120.56269 -172.093,-120.5628zm-62.813,111.3128c13.757,0 24.938,11.42601 24.937,25.56201c0,14.123 -11.17999,25.56299 -24.937,25.56299c-13.77,0 -24.937,-11.452 -24.937,-25.56299c0,-14.136 11.16699,-25.56201 24.937,-25.56201z',
        # Fish emoji: 🐟
        'primary producer' = 'path://m159.25,40.6562c-24.94501,21.2956 -35.47,49.4967 -34.125,77.1558c0.126,2.633 0.598,5.228 0.937,7.844c0.26,1.989 0.339,3.99599 0.719,5.969c0.868,4.50999 2.04501,8.996 3.531,13.375c1.424,4.198 3.076,8.019 4.907,11.625c0.063,0.12399 0.09201,0.282 0.15601,0.40601c0.02699,0.05299 0.06599,0.10399 0.09399,0.157c0.931,1.797 1.92601,3.545 2.96901,5.218c0.043,0.071 0.08,0.14899 0.12399,0.21899c1.035,1.647 2.134,3.241 3.282,4.78101c2.071,2.78099 4.442,5.31499 6.90601,7.81299c0.392,0.39801 0.69099,0.858 1.09399,1.25c1.748,1.701 3.80101,3.26801 5.75,4.875c1.39801,1.15201 2.651,2.38301 4.15601,3.5c1.40199,1.039 3.065,2.01401 4.562,3.03101c2.30901,1.56799 4.55,3.179 7.09401,4.71899c2.69499,1.62901 5.74599,3.272 8.71899,4.90601c1.41,0.77499 2.651,1.562 4.125,2.34399c5.771,3.061 13.097,6.52701 19.90601,9.84401c4.381,2.133 7.946,4.026 12.782,6.343l0,-0.03101c0.383,0.18401 0.644,0.315 1.03099,0.5c-28.61899,25.597 -51.97299,49.418 -71,71.375c3.01901,-29.38699 3.09801,-46.612 -13.25,-64.53101c-18.298,-20.05299 -47.74369,-31.87599 -79.18779,-25.43799c-0.247,0.49699 -0.3609,1.002 -0.5937,1.5c-0.0053,-0.00401 -0.0259,0.00499 -0.0313,0c-0.1405,0.30099 -0.2083,0.605 -0.3437,0.90599c-1.3185,2.93201 -2.4697,5.858 -3.3125,8.813c-0.0777,0.271 -0.1136,0.541 -0.1875,0.813c-0.8244,3.04399 -1.4639,6.086 -1.8125,9.12399c-0.0024,0.021 0.0024,0.04201 0,0.063c-1.1121,9.782 0.1117,19.466 3.3438,28.53101c0.2314,0.653 0.5922,1.25999 0.8437,1.90599c0.9142,2.338 1.8339,4.66501 3,6.907c0.6007,1.159 1.366,2.245 2.0313,3.375c1.0156,1.72101 1.9671,3.478 3.125,5.125c1.8886,2.69 3.9429,5.25601 6.1874,7.71899c9.15591,10.026 18.8129,15.50201 31.25,18.90601c3.1098,0.85101 6.38181,1.55301 9.8748,2.18701c8.62,1.565 19.165,2.59 30.87501,3.65698c-58.5201,70.431 -72.36211,120.69302 -76.93721,147.53101c-1.2299,7.18802 9.3944,16.25702 17.375,17.375c7.99419,1.08099 24.28719,-4.84299 25.5312,-12.03198c2.92,-17.18402 10.168,-47.13202 30.812,-86.46802c32.181,33.46201 48.39801,50.207 83.157,52.5c34.87401,2.24802 70.96802,-11.142 90.90601,-41.34399c-0.01599,-0.034 -0.047,-0.06 -0.06299,-0.09399c-0.892,-1.939 -1.85202,-3.82101 -2.87402,-5.65601c-0.04498,-0.08099 -0.07999,-0.16901 -0.12598,-0.25c-1.05801,-1.88599 -2.186,-3.72501 -3.37402,-5.5c-0.017,-0.02399 -0.047,-0.03799 -0.06299,-0.06201c-1.19,-1.77399 -2.439,-3.526 -3.75,-5.18799c-0.01801,-0.02301 -0.04401,-0.039 -0.06299,-0.06201c-1.311,-1.65997 -2.668,-3.26498 -4.09302,-4.81299c-0.01999,-0.022 -0.043,-0.04099 -0.06299,-0.06299c-2.87701,-3.11801 -5.96402,-5.996 -9.25,-8.65601c-6.62201,-5.358 -14.03201,-9.78302 -21.90601,-13.25c-11.783,-5.18802 -24.65601,-8.241 -37.71899,-9.09399c-4.27,-0.27402 -8.304,-0.289 -12.15601,-0.06201c-1.62399,0.095 -3.12199,0.41101 -4.687,0.59399c-2.243,0.263 -4.541,0.43201 -6.688,0.875c-1.466,0.30099 -2.849,0.83401 -4.28101,1.21899c-2.01599,0.54102 -4.06099,1.01401 -6.03099,1.71802c-1.82401,0.65201 -3.632,1.52298 -5.438,2.31299c-1.612,0.70502 -3.231,1.311 -4.84399,2.125c-1.86101,0.94 -3.77301,2.103 -5.65601,3.18701c-1.513,0.871 -3.024,1.63199 -4.562,2.59399c-2.942,1.841 -5.996,3.952 -9.09401,6.125c-0.41199,0.289 -0.804,0.51801 -1.21899,0.81201c-5.35699,3.79999 -11.58501,8.65298 -17.75,13.40698c-2.229,1.71899 -4.037,2.97202 -6.40601,4.81201c0.017,-0.00101 0.04501,0.00198 0.06201,0c-0.61601,0.479 -1.061,0.79498 -1.68701,1.28101c16.718,-31.733 42.283,-69.54602 81.59401,-111.96802c30.33699,34.79501 47.01399,52.76001 82.718,56.68701c36.87799,4.01498 75.965,-8.423 99,-39.40601c0.082,-0.12299 0.19998,-0.22101 0.28198,-0.34399c-13.97998,-35.30101 -48.68597,-55.983 -85.71899,-60.06201c-4.474,-0.48999 -8.711,-0.679 -12.78101,-0.625c-1.57397,0.01901 -3.03699,0.24501 -4.56299,0.34401c-2.47198,0.162 -4.96899,0.257 -7.34399,0.62399c-1.668,0.257 -3.27301,0.73801 -4.90601,1.09401c-2.05301,0.45 -4.13901,0.83299 -6.15601,1.43799c-2.01401,0.60301 -4.03101,1.40001 -6.03101,2.15601c-1.59,0.601 -3.189,1.149 -4.78198,1.84399c-2.19699,0.959 -4.457,2.11301 -6.68701,3.25c-1.44098,0.73401 -2.88,1.44301 -4.34399,2.25c-2.325,1.283 -4.77699,2.72301 -7.187,4.18701c-1.30301,0.791 -2.63501,1.595 -3.96901,2.43799c-3.77699,2.388 -8.29599,5.483 -12.407,8.28101c25.15401,-25.59399 55.058,-52.614 91.157,-80.875c2.784,-2.18401 5.44,-4.649 7.125,-7.21899c1.58401,0.573 3.06302,1.07999 4.59399,1.625c4.979,1.77499 10.54602,3.82999 15.03101,5.28099c1.785,0.57701 3.46701,1.04201 5.18701,1.563c2.81598,0.854 5.67801,1.744 8.34399,2.437c0.61099,0.159 1.177,0.257 1.78101,0.407c7.68799,1.91 14.89099,3.175 21.90698,3.5c0.02002,0.00101 0.04202,-0.00099 0.06201,0c7.52399,0.34201 14.91901,-0.314 22.625,-2.157c3.854,-0.91899 7.79401,-2.12 11.875,-3.65599c4.16299,-1.57501 8.21399,-3.37401 12.125,-5.40601c27.32101,-14.17599 47.71201,-39.192 50.03101,-70.8438c-30.52802,-23.616 -70.73801,-25.9827 -104,-13.43739c-31.07901,11.7597 -41.742,31.7836 -58.75,68.9692c-3.24301,0.744 -6.621,2.767 -9.78101,5.093c-35.27399,25.85599 -65.123,50.22099 -91.09399,73.28099c25.95399,-43.84999 38.905,-66.912 27.25,-101.312c-11.97101,-35.3012 -43.576,-65.2006 -88.78101,-72.0938z',
        # Herb emoji: 🌿
        'bird' = 'path://m146.88901,185.386c-1.33301,20.91 21.23499,39.567 -8.552,37.453c-29.786,-2.114 -94.11541,-32.061 -93.29871,-44.68001c0.8168,-12.62 44.5357,-34.897 74.3227,-32.78299c29.786,2.101 28.87299,19.08699 27.52801,40.00999zm241.67899,203.13899c-2.42599,-0.405 -4.70801,0.19 -6.77399,1.202c-27.92502,2.93701 -38.73401,-23.85898 -38.73401,-23.85898c-5.27301,-4.25302 -11.78299,-25.42902 -19.08499,-15.379l2.246,17.74597c2.246,17.746 30.867,40.80701 30.867,40.80701l-14.59302,20.11301c-4.035,5.55701 -3.026,13.49301 2.246,17.746c5.27301,4.25299 12.80402,3.189 16.83899,-2.367l8.08301,-11.13901l-0.46799,3.15201c-1.04501,6.91101 3.423,13.392 9.98099,14.49301c6.55801,1.10098 12.707,-3.608 13.75201,-10.51901l5.64499,-37.50299c1.021,-6.91101 -3.44699,-13.392 -10.005,-14.49301zm-75.40298,7.88501c-2.354,-0.73401 -4.68402,-0.46802 -6.87,0.228c-28.04501,-1.03799 -35.35901,-29.112 -35.35901,-29.112c-4.685,-4.96201 -8.444,-26.87201 -16.96001,-17.935l-0.036,17.897c-0.036,17.89798 25.40298,44.79498 25.40298,44.79498l-17.01898,17.87201c-4.70801,4.936 -4.72,12.94901 -0.03601,17.89801c4.68399,4.961 12.28702,4.974 16.983,0.03799l9.42801,-9.89902l-0.87601,3.06403c-1.91,6.69498 1.69299,13.746 8.047,15.771c6.353,2.01199 13.05499,-1.785 14.965,-8.48102l10.353,-36.36499c1.94601,-6.70801 -1.65698,-13.758 -8.02298,-15.771zm147.11899,-288.88c-4.60001,-2.152 -9.104,-0.721 -12.61099,3.089c-0.64902,0.708 -50.745,79.817 -174.539,62.578c-4.08401,-0.57001 37.70099,151.48399 38.422,151.408c1.48901,-0.177 36.87299,-4.65802 73.745,-32.315c33.84702,-25.37802 75.47601,-75.83 81.63699,-172.11501c0.336,-5.291 -2.05399,-10.48 -6.65399,-12.645zm-6.38901,182.00101c-2.45099,-4.25299 -7.08698,-7.08801 -11.759,-5.96201c-15.53,3.73401 -38.39798,6.87299 -54.40799,5.73401c-76.35199,-5.41702 -112.43298,-52.26201 -112.80499,-52.65501c-3.30301,-3.569 5.59698,146.21901 9.80099,146.52299c110.42599,7.84702 166.492,-76.28699 168.83401,-79.86899c2.66699,-4.12601 2.79898,-9.505 0.33698,-13.771zm-118.798,-26.479c-4.45599,69.742 15.80603,124.815 -50.37299,120.10599c-66.179,-4.69598 -121.849,-62.27399 -117.39301,-132.02899c4.45601,-69.756 172.23401,-57.81999 167.76599,11.923zm-15.96298,-83.59c-4.23901,66.26199 -47.10501,117.16998 -109.96901,112.702c-62.87599,-4.46799 -110.41479,-61.79401 -106.175,-128.05501c4.24001,-66.2618 58.036,-106.87949 120.91199,-102.41139c48.054,3.4048 98.968,59.2744 95.23201,117.7644zm-175.2,-43.326c0,-13.981 10.75499,-25.315 24.02199,-25.315c13.26601,0 24.02101,11.334 24.02101,25.315c0,13.981 -10.755,25.315 -24.02101,25.315c-13.267,0 -24.02199,-11.334 -24.02199,-25.315zm114.21001,96.905c0,0 91.642,71.489 148.77698,-56.439c4.75601,-10.658 20.23801,10.037 1.189,52.67999c-19.04898,42.64299 -98.18799,81.51399 -144.60898,19.442c-9.789,-13.101 -5.35699,-15.683 -5.35699,-15.683zm-34.25401,-171.3561c0,0 75.01799,3.215 93.65901,-6.0375c18.64099,-9.2526 1.634,37.1115 -39.17902,47.9586c-40.812,10.848 -54.48,-41.9211 -54.48,-41.9211zm25.23399,33.9346c0,0 54.06,1.7214 72.71301,-7.5185c18.65298,-9.2399 1.633,37.112 -39.17902,47.959c-40.82399,10.847 -33.534,-40.4405 -33.534,-40.4405z',
        # Bird emoji: 🐦
        'reptile' = 'path://m175.714,126.065c-8.83501,0 -28.20201,25.733 -43.83301,11.806c-5.407,-4.808 22.341,-14.663 21.222,-23.141c-0.92099,-6.964 -34.923,-17.43871 -23.03999,-24.0815c11.882,-6.6312 29.713,9.6485 43.16899,9.9355c29.27101,0.631 51.759,-9.7863 52.078,-9.9355c6.649,-3.1435 14.685,-0.5965 17.991,5.6905c3.31801,6.276 0.627,13.917 -5.99699,17.049c-1.61,0.757 -27.342,12.677 -61.59,12.677zm196.34499,325.43701c-48.74799,0 -100.54398,-33.40903 -100.54398,-95.31601c0,-15.76401 -10.93701,-19.056 -20.11601,-19.056c-9.16701,0 -20.104,3.29199 -20.104,19.056c0,61.90698 -51.808,95.31601 -100.54399,95.31601c-48.7364,0 -100.53241,-31.78003 -100.53241,-95.31601c0,-152.496 174.2754,-173.54901 174.2754,-152.496c0,21.052 -93.83501,-12.701 -93.83501,139.79599c0,25.41202 10.937,31.76801 20.104,31.76801c9.179,0 20.116,-3.293 20.116,-19.056c0,-61.896 51.79601,-95.31601 100.545,-95.31601c48.73601,0 100.54399,33.40802 100.54399,95.31601c0,15.763 10.93701,19.056 20.11603,19.056c9.17999,0 20.10397,-3.293 20.10397,-19.056l0,-190.632c0,-44.228 -41.98999,-50.83599 -67.021,-50.83599c0,0 -40.20798,12.712 -80.42799,12.712c-40.22099,0 -53.627,-29.7836 -53.627,-50.8361c-0.02499,-21.0526 53.60201,-38.1241 134.03,-38.1241c80.44,0 147.46201,51.0654 147.46201,127.08419l0,190.62001c0,61.90698 -51.80801,95.31601 -100.54501,95.31601zm-120.64799,-378.60191c0,-6.3362 5.502,-11.4727 12.28902,-11.4727c6.78598,0 12.28799,5.13651 12.28799,11.4727c0,6.3363 -5.50201,11.4728 -12.28799,11.4728c-6.78702,0 -12.28902,-5.13651 -12.28902,-11.4728z',
        'detritus' = 'path://m452.76999,302.44199c4.13501,-17.08398 2.76001,-35.35797 -5.203,-53.54599c-7.70297,-17.592 -20.98297,-31.504 -37.15997,-40.847c3.61298,-12.905 2.65799,-26.795 -3.681,-40.59799c-9.55402,-20.78601 -30.21802,-34.65401 -53.52902,-38.563c2.82901,-6.192 3.737,-13.954 0.409,-23.46c-11.35999,-32.4782 -56.802,-10.8259 -90.88199,-54.1196c-27.71899,15.8495 -33.74001,39.4071 -32.69499,59.4026c-27.50301,4.461 -43.16901,10.134 -43.16901,10.134l0,0.021c-15.45,5.955 -26.379,20.386 -26.379,37.26401c0,9.51599 3.61299,18.144 9.40599,25.03l-7.86099,2.793l0.01199,0.032c-26.47,9.42999 -45.158,32.21899 -45.158,58.884c0,11.33501 3.409,21.94398 9.316,31.157c-32.0702,13.73901 -54.4613,43.55399 -54.4613,78.40298c0,47.83002 41.9303,86.60901 93.6543,86.60901c37.13699,0 74.51199,-7.61099 108.27499,-18.02499c25.48099,11.259 64.69598,18.02499 123.73599,18.02499c46.009,0 83.30499,-35.54199 83.30499,-79.388c0,-23.55798 -10.827,-44.65799 -27.935,-59.20801zm-267.43298,-83.33899c0,-26.90599 17.802,-48.718 39.761,-48.718c21.95999,0 39.761,21.81201 39.761,48.718c0,26.905 -17.80101,48.71701 -39.761,48.71701c-21.959,0 -39.761,-21.81201 -39.761,-48.71701zm113.603,0c0,-26.90599 17.802,-48.718 39.76099,-48.718c21.95901,0 39.76102,21.81201 39.76102,48.718c0,26.905 -17.802,48.71701 -39.76102,48.71701c-21.95898,0 -39.76099,-21.81201 -39.76099,-48.71701zm-90.882,0c0,-14.948 10.172,-27.06599 22.72101,-27.06599c12.54799,0 22.71999,12.118 22.71999,27.06599c0,14.94701 -10.172,27.065 -22.71999,27.065c-12.54901,0 -22.72101,-12.118 -22.72101,-27.065zm102.24199,0c0,-14.948 10.173,-27.06599 22.72101,-27.06599c12.548,0 22.72101,12.118 22.72101,27.06599c0,14.94701 -10.173,27.065 -22.72101,27.065c-12.548,0 -22.72101,-12.118 -22.72101,-27.065zm-131.245,101.711c-2.79399,-5.33701 0.03401,-9.689 6.28201,-9.689l204.48499,0c6.24802,0 9.077,4.35199 6.28302,9.689c0,0 -29.00302,55.267 -108.52502,55.267c-79.52199,0 -108.52499,-55.267 -108.52499,-55.267zm108.52499,11.96301c-31.47897,0 -58.58499,9.98099 -71.47899,24.42398c16.95,10.33801 40.27199,18.88 71.47899,18.88c31.207,0 54.54102,-8.54199 71.479,-18.88c-12.89398,-14.44299 -40,-24.42398 -71.479,-24.42398z',
        # Leaf emoji: 🍂
        'unidentified' = 'path://m258.09399,90.625c-77.72499,0 -143.40599,44.38 -143.40599,96.90601c0,17.84299 19.237,32.28099 43,32.28099c23.76199,0 43.03099,-14.438 43.03099,-32.28099c0,-10.76801 22.37001,-32.31201 57.375,-32.31201c43.021,0 71.68701,21.526 71.68701,43.06201c0,43.07199 -77.384,53.77899 -86.03101,53.84399c-23.76199,0 -43.03101,14.47 -43.03101,32.31299l0,43.06201c0,17.84201 19.26901,32.31201 43.03101,32.31201c23.76199,0.00098 43,-14.47 43,-32.31201l0,-14.34399c11.42899,-1.72299 24.18701,-4.28302 37.09399,-8.06201c59.31201,-17.30399 91.96802,-51.39899 91.96802,-96.032c0.00098,-54.03299 -42.99503,-118.437 -157.71802,-118.437zm-14.34399,290.71899c-23.75999,0 -43.03101,14.47101 -43.03101,32.31201c0,17.841 19.27101,32.28198 43.03101,32.28198c23.76001,-0.00098 43,-14.44098 43,-32.28198c0,-17.841 -19.23999,-32.31201 -43,-32.31201z',
        # Question mark emoji: ❓
        'invertebrates' = 'path://m100.844,109.563c-15.63461,-0.87 -21.8029,26.993 -11.969,26.993c13.521,0 20.639,13.31 17.125,34.457c-27.0613,6.286 -54.9375,28.226 -54.9375,43.379c0,21.10901 12.106,21.097 36.3125,31.651c24.207,10.55399 -12.1033,84.44199 0,126.659c8.8112,30.71201 36.296,63.32901 96.813,63.32901l278.37401,0c12.10397,0 24.21899,0.004 24.21899,-10.55002c0,-7.759 -32.716,-21.207 -64.46899,-31.987c20.86899,-14.332 35.672,-34.51398 42.12598,-57.88599c18.51801,-67.15601 -26.70499,-135.457 -100.81299,-152.24901c-89.48001,-20.29599 -180.55901,29.22701 -202.937,110.356c-1.127,4.08301 -0.826,8.16101 0.562,11.86902c-4.354,-6.263 -4.99899,-14.77802 -1.25,-27.86203c6.756,-23.56598 16.39,-57.51599 2.53101,-82.40999c5.45999,-32.88499 16.72699,-63.063 -2.53101,-79.856c-24.207,-21.1084 -36.322,21.1 -24.21899,21.1c15.556,0 22.644,17.548 14.75,44.502c-4.104,-3.336 -8.94,-6.362 -14.75,-8.895c-4.66,-2.032 -9.90001,-2.82899 -15.37501,-2.862c4.315,-22.16699 6.649,-41.671 -7.312,-53.84499c-4.539,-3.958 -8.642,-5.692 -12.25,-5.893z',
        # Snail emoji: 🐌
        'inverte' = 'path://m100.844,109.563c-15.63461,-0.87 -21.8029,26.993 -11.969,26.993c13.521,0 20.639,13.31 17.125,34.457c-27.0613,6.286 -54.9375,28.226 -54.9375,43.379c0,21.10901 12.106,21.097 36.3125,31.651c24.207,10.55399 -12.1033,84.44199 0,126.659c8.8112,30.71201 36.296,63.32901 96.813,63.32901l278.37401,0c12.10397,0 24.21899,0.004 24.21899,-10.55002c0,-7.759 -32.716,-21.207 -64.46899,-31.987c20.86899,-14.332 35.672,-34.51398 42.12598,-57.88599c18.51801,-67.15601 -26.70499,-135.457 -100.81299,-152.24901c-89.48001,-20.29599 -180.55901,29.22701 -202.937,110.356c-1.127,4.08301 -0.826,8.16101 0.562,11.86902c-4.354,-6.263 -4.99899,-14.77802 -1.25,-27.86203c6.756,-23.56598 16.39,-57.51599 2.53101,-82.40999c5.45999,-32.88499 16.72699,-63.063 -2.53101,-79.856c-24.207,-21.1084 -36.322,21.1 -24.21899,21.1c15.556,0 22.644,17.548 14.75,44.502c-4.104,-3.336 -8.94,-6.362 -14.75,-8.895c-4.66,-2.032 -9.90001,-2.82899 -15.37501,-2.862c4.315,-22.16699 6.649,-41.671 -7.312,-53.84499c-4.539,-3.958 -8.642,-5.692 -12.25,-5.893z',
        # Snail emoji: 🐌
        'inver' = 'path://m100.844,109.563c-15.63461,-0.87 -21.8029,26.993 -11.969,26.993c13.521,0 20.639,13.31 17.125,34.457c-27.0613,6.286 -54.9375,28.226 -54.9375,43.379c0,21.10901 12.106,21.097 36.3125,31.651c24.207,10.55399 -12.1033,84.44199 0,126.659c8.8112,30.71201 36.296,63.32901 96.813,63.32901l278.37401,0c12.10397,0 24.21899,0.004 24.21899,-10.55002c0,-7.759 -32.716,-21.207 -64.46899,-31.987c20.86899,-14.332 35.672,-34.51398 42.12598,-57.88599c18.51801,-67.15601 -26.70499,-135.457 -100.81299,-152.24901c-89.48001,-20.29599 -180.55901,29.22701 -202.937,110.356c-1.127,4.08301 -0.826,8.16101 0.562,11.86902c-4.354,-6.263 -4.99899,-14.77802 -1.25,-27.86203c6.756,-23.56598 16.39,-57.51599 2.53101,-82.40999c5.45999,-32.88499 16.72699,-63.063 -2.53101,-79.856c-24.207,-21.1084 -36.322,21.1 -24.21899,21.1c15.556,0 22.644,17.548 14.75,44.502c-4.104,-3.336 -8.94,-6.362 -14.75,-8.895c-4.66,-2.032 -9.90001,-2.82899 -15.37501,-2.862c4.315,-22.16699 6.649,-41.671 -7.312,-53.84499c-4.539,-3.958 -8.642,-5.692 -12.25,-5.893z'              # Snail emoji: 🐌
      )


      # Map 'category' values to their corresponding symbols
      data$symbol2 <- sapply(data$category, function(cat) {
        symbol2 <- classification_list2[[cat]]
        if (is.null(symbol2)) {
          # If 'cat' doesn't match any entry in the classification_list, return NA
          NA
        } else {
          symbol2
        }
      })





      table_data3(data)
    } else {
      if (input$ch1 == 'Conservation Status') {
        data <- hot_to_r(input$editableTable3)

        classification_list <- list(
          extinct = 'path://m282.31201,93.7812c-10.91901,0.00011 -21.94501,2.5816 -33.12401,7.7808c-11.96001,5.46001 -17.562,11.177 -16.782,17.15701c0.51999,3.12 2.78299,5.471 6.81299,7.031c4.03,1.56 6.43901,2.981 7.21901,4.28101l63.187,105.31299l-66.313,116.59399c-1.039,1.55902 -3.245,3.242 -6.62399,5.06201c-3.38,1.82001 -5.586,4.02499 -6.62601,6.625c-0.77899,1.82001 -1.15599,3.534 -1.15599,5.09399c0,6.759 5.04799,12.47601 15.18799,17.15601c9.35901,4.67999 19.37201,7 30.03101,7c9.099,0 15.74701,-1.798 19.90601,-5.43701c3.12,-2.85999 4.16501,-6.37198 3.125,-10.53198c-1.04001,-5.71899 -0.77802,-10.16101 0.78198,-13.28101l44.43701,-82.65601l46.81299,72.125c0.77902,1.30002 1.15601,2.60602 1.15601,3.90601c0,1.56 -0.72699,3.76501 -2.15601,6.625c-1.42999,2.85999 -2.12598,5.211 -2.12598,7.03101c0.00098,2.60001 1.04599,5.18201 3.12598,7.78198c3.379,4.159 9.09601,7.93201 17.15601,11.31201c8.05902,3.38 16.09601,5.09399 24.15601,5.09399c20.01901,0 30.70001,-9.89798 32,-29.65601c0.26001,-4.41998 -1.94501,-7.93198 -6.625,-10.53198c-6.23999,-3.64001 -9.75101,-6.22101 -10.53101,-7.78101l-74.09399,-111.53101l50.68799,-94c1.039,-2.07999 4.66602,-4.43199 10.90601,-7.032c4.939,-2.33899 7.814,-6.604 8.59399,-12.84299c0.77902,-7.28 -3.25497,-13.519 -12.09399,-18.719c-8.06,-4.4197 -17.173,-6.625 -27.31299,-6.625c-8.57901,0 -14.93402,1.6827 -19.09302,5.063c-2.85999,2.599 -4.80399,6.487 -5.84399,11.687c-1.29999,6.5 -2.492,10.795 -3.53198,12.875l-31.96802,63.96899c-25.99899,-46.797 -39.784,-74.25299 -41.34399,-82.313c-1.04001,-5.979 -3.62201,-9.8674 -7.78101,-11.68719c-2.60001,-1.3 -5.99701,-1.93761 -10.15698,-1.93761zm-104.50002,0.375c-4.41899,0 -8.30699,0.8989 -11.687,2.7188c-4.94,2.5998 -7.929,4.053 -8.96899,4.313l-46.812,13.25c-3.12,-1.3 -6.37,-2.722 -9.75,-4.28201c-5.19991,-2.08 -9.4955,-3.00999 -12.8752,-2.75c-15.8591,2.34 -23.7813,7.304 -23.7813,14.844c0,2.34 0.8989,4.66 2.7187,7c-1.81979,76.955 -1.29729,149.509 1.56261,217.625c-2.8599,8.83899 -4.2813,13.51099 -4.2813,14.03101c0,1.82001 0.3763,3.242 1.1563,4.28198c11.1793,15.599 23.65829,25.35001 37.43719,29.25c1.3,0.26001 2.492,0.40601 3.531,0.40601c3.12,0 6.632,-1.56799 10.53201,-4.68799c5.199,-3.89999 8.56499,-6.25101 10.125,-7.03101l36.656,-16.375c14.039,0.78 24.052,-0.323 30.03101,-3.31201c5.98,-2.98999 8.96899,-7.60498 8.96899,-13.84399c0,-7.28 -3.888,-14.418 -11.687,-21.43799c-7.8,-7.01901 -15.34601,-10.79199 -22.62601,-11.31201c-6.759,-0.51999 -11.431,0.52499 -14.03099,3.125c-1.3,1.30002 -2.606,2.836 -3.90601,4.65601c-7.28,3.12 -16.39301,5.84799 -27.313,8.18701c-1.559,-5.979 -2.34299,-19.47202 -2.34299,-40.53101c8.579,-3.63901 15.86399,-6.77499 21.84299,-9.375c2.08,-0.78 6.89801,-0.89502 14.438,-0.375c7.53999,0.51999 13.256,0.259 17.15601,-0.78101c6.5,-1.82001 11.31799,-6.26199 14.43799,-13.28101c0.78,-1.82001 1.15601,-3.50299 1.15601,-5.06299c0,-6.23901 -4.991,-12.683 -15,-19.31201c-10.009,-6.62999 -18.804,-9.93799 -26.34399,-9.93799c-7.539,0 -12.849,2.467 -15.968,7.40599c-6.24001,1.04001 -10.159,1.97101 -11.719,2.75c-1.56001,-31.198 -1.56001,-59.03 0,-83.468c4.679,-3.37999 14.316,-7.52899 28.87499,-12.46899c5.979,-2.08 12.74101,-4.17 20.28101,-6.25c5.2,0.52 9.756,0.78101 13.65601,0.78101c9.36,0 17.021,-2.205 23,-6.625c2.86,-2.08 4.28099,-5.069 4.28099,-8.96901c0,-6.239 -2.785,-12.944 -8.37399,-20.09299c-5.59,-7.15 -11.25,-11.2416 -16.96901,-12.2815c-2.86,-0.52 -5.327,-0.7813 -7.407,-0.7813z',
          endangered = 'path://m399.90601,93c-5.979,0 -10.39001,1.2752 -13.25,3.875c-5.19901,4.68 -7.81201,8.599 -7.81201,11.719c0,1.56 0.89902,3.561 2.71802,6.031c1.81998,2.47 2.75,4.764 2.75,6.844l4.65698,171.59301c-49.397,-76.43501 -76.67599,-126.61201 -81.875,-150.53101c-0.25998,-0.52 -0.40601,-1.18901 -0.40601,-1.96901c-0.00098,-1.039 0.26102,-2.722 0.78101,-5.062c0.52002,-2.34 0.78101,-4.16901 0.78101,-5.46899c0,-3.38 -1.16,-6.22201 -3.5,-8.562c-8.319,-9.1 -22.22,-13.65701 -41.71899,-13.65701c-7.27901,0 -12.93901,1.103 -16.96901,3.313c-4.02899,2.21 -6.062,4.995 -6.062,8.375c0,1.3 0.261,3.129 0.78101,5.469c0.51999,2.34 0.78099,4.022 0.78099,5.062l11.71901,214.875c0.25999,2.34 -1.71501,5.00998 -5.875,8c-4.15901,2.98999 -5.84201,7.34299 -5.06201,13.06299c1.04001,7.01901 6.06201,13.14401 15.03101,18.34302c8.96899,5.19998 18.10901,7.78198 27.46899,7.78198c8.83902,0 15.48599,-2.46698 19.90601,-7.40601c3.12,-3.63998 4.68799,-7.52798 4.68799,-11.68799c0,-3.38 -1.30698,-7.56 -3.90698,-12.5c-2.60001,-4.94 -3.90601,-8.04401 -3.90601,-9.34399c-5.20001,-66.03601 -7.29001,-111.01901 -6.25,-134.93701c9.35901,20.27901 23.92899,45.383 43.68701,75.28101c8.06,12.479 16.91199,25.33499 26.53198,38.59399c2.08002,3.63901 3.35501,8.19601 3.875,13.65601c0.26001,6.23999 1.04401,10.79599 2.34302,13.65601c8.06,18.19901 23.15198,27.94998 45.25,29.25c8.84,0.51999 16.23999,-2.09302 22.21899,-7.81201c5.97998,-5.72 9.22998,-12.858 9.75,-21.43799c0.25998,-3.38 -1.48001,-7.61801 -5.25,-12.68701c-3.77002,-5.07001 -5.65601,-9.30798 -5.65601,-12.68799l-5.46899,-192.25c0,-2.60001 2.14798,-5.12401 6.43799,-7.593c4.29001,-2.47 6.29102,-6.04 6.03101,-10.719c-0.26001,-7.02 -5.45401,-13.521 -15.59399,-19.5c-10.13901,-5.9799 -20.005,-8.969 -29.625,-8.969zm-213.31201,1.1562c-4.42,0 -8.33899,0.8989 -11.71899,2.7188c-4.94,2.5998 -7.929,4.053 -8.96899,4.313l-46.78101,13.25c-3.12,-1.3 -6.37,-2.722 -9.75,-4.28201c-5.2,-2.08 -9.4952,-3.00999 -12.875,-2.75c-15.859,2.34 -23.7812,7.304 -23.7812,14.844c-0.00011,2.34 0.8988,4.66 2.7187,7c-1.8199,76.955 -1.2973,149.509 1.5625,217.625c-2.8598,8.83899 -4.2812,13.51099 -4.2812,14.03101c-0.00011,1.82001 0.3762,3.242 1.1562,4.28198c11.1793,15.599 23.6583,25.35001 37.437,29.25c1.3,0.26001 2.492,0.40601 3.53201,0.40601c3.12,0 6.6,-1.56799 10.5,-4.68799c5.199,-3.89999 8.596,-6.25101 10.156,-7.03101l36.65601,-16.375c14.039,0.78 24.05199,-0.323 30.032,-3.31201c5.979,-2.98999 8.968,-7.60498 8.968,-13.84399c0,-7.28 -3.888,-14.418 -11.68701,-21.43799c-7.79999,-7.01901 -15.34599,-10.79199 -22.625,-11.31201c-6.75999,-0.51999 -11.463,0.52499 -14.06299,3.125c-1.3,1.30002 -2.57501,2.836 -3.875,4.65601c-7.27901,3.12 -16.39301,5.84799 -27.31201,8.18701c-1.56,-5.979 -2.34399,-19.47202 -2.34399,-40.53101c8.57899,-3.63901 15.864,-6.77499 21.84399,-9.375c2.08,-0.78 6.89801,-0.89502 14.43701,-0.375c7.53999,0.51999 13.25699,0.259 17.157,-0.78101c6.49899,-1.82001 11.317,-6.26199 14.437,-13.28101c0.78,-1.82001 1.15601,-3.50299 1.15601,-5.06299c0,-6.23901 -4.99001,-12.683 -15,-19.31201c-10.009,-6.62999 -18.804,-9.93799 -26.343,-9.93799c-7.54001,0 -12.849,2.467 -15.96901,7.40599c-6.23999,1.04001 -10.159,1.97101 -11.71899,2.75c-1.56,-31.198 -1.56,-59.03 0,-83.468c4.67999,-3.37999 14.31599,-7.52899 28.875,-12.46899c5.98,-2.08 12.742,-4.17 20.28101,-6.25c5.2,0.52 9.72499,0.78101 13.625,0.78101c9.36,0 17.05199,-2.205 23.03099,-6.625c2.86,-2.08 4.282,-5.069 4.282,-8.96901c0,-6.239 -2.786,-12.944 -8.375,-20.09299c-5.59,-7.15 -11.24899,-11.2416 -16.96899,-12.2815c-2.86,-0.52 -5.326,-0.7813 -7.40601,-0.7813z',
          vulnerable = 'path://m209.21899,106.781c-6.75999,0 -12.50899,1.191 -17.18799,3.531c-7.28,4.42001 -10.90601,10.25301 -10.90601,17.53201c0,0.77999 0,2.143 0,4.094c0,1.95 0,3.57399 0,4.87399c0,2.85901 -0.261,5.32701 -0.78101,7.407l-39.782,140.40601l-28.062,-132.21899c-0.519,-2.34001 0.264,-5.50101 2.344,-9.53101c2.08,-4.03 3.094,-7.108 3.094,-9.187c-0.00101,-1.56 -0.262,-2.98201 -0.78201,-4.282c-1.82,-4.94 -6.695,-8.77 -14.625,-11.50001c-7.9292,-2.73 -16.69279,-4.094 -26.31219,-4.094c-22.09871,0 -33.1563,5.19501 -33.1563,15.59401c0,3.89999 2.5554,7.616 7.625,11.125c5.0697,3.50999 7.74,6.14899 8,7.96899l44.4375,200.06201c0.52,2.07999 0.259,4.547 -0.781,7.40698c-1.3,3.89999 -1.938,6.51199 -1.938,7.81201c0,8.57898 5.717,17.48999 17.156,26.71899c11.43901,9.23001 21.97501,13.84399 31.59401,13.84399c6.5,0 12.01399,-2.20599 16.56299,-6.625c4.55,-4.41998 6.81201,-10.138 6.81201,-17.15698c0,-2.34003 -0.31801,-5.59003 -0.96901,-9.75c-0.64999,-4.15802 -0.968,-7.03302 -0.968,-8.59302c0,-1.29999 0.14601,-2.345 0.40601,-3.125l63.15601,-206.68799c0.78,-2.34001 3.45,-4.748 8,-7.218c4.549,-2.47101 7.33499,-4.79001 8.375,-7c1.03999,-2.21001 1.56299,-4.358 1.56299,-6.438c0,-6.76 -4.55699,-12.622 -13.65599,-17.562c-9.10001,-4.941 -18.82001,-7.40701 -29.21901,-7.40701zm219.53101,0c-14.55899,0 -24.57101,3.511 -30.03101,10.531c-3.63998,4.68 -5.43799,9.091 -5.43799,13.25c0,3.901 2.20499,8.776 6.625,14.62601c4.41998,5.849 6.36398,10.34799 5.84399,13.468c0.51999,2.86 0.78101,7.532 0.78101,14.032c0,33.27699 -3.13501,69.554 -9.375,108.812c-7.79901,48.617 -17.51901,73.168 -29.21802,73.68799c-6.76099,0.26001 -12.884,-15.84598 -18.34399,-48.34399c-4.16,-24.95801 -7.526,-55.78 -10.125,-92.43799c-2.07999,-32.75801 -2.603,-50.692 -1.56299,-53.81201c-0.52002,-3.12 0.698,-6.89299 3.68799,-11.31299c2.98901,-4.42001 4.353,-8.57001 4.09399,-12.46901c-0.51999,-7.799 -5.453,-14.154 -14.81299,-19.09299c-8.05899,-4.16 -17.173,-6.25 -27.31299,-6.25c-8.319,0 -14.151,1.682 -17.53101,5.062c-5.20001,4.94 -7.81201,11.064 -7.81201,18.344c0,4.939 1.306,11.032 3.90601,18.313c-1.04001,9.618 -1.56299,24.30299 -1.56299,44.062c0.00098,53.55701 5.341,98.017 16,133.375c15.34,51.47699 40.81998,76.32001 76.43799,74.5c30.418,-1.29999 53.43201,-22.108 69.03101,-62.40601c11.17999,-29.11798 18.17099,-67.97699 21.03101,-116.59399c0.51999,-26.258 0.92798,-52.638 1.18799,-79.15601l4.68799,-12.5c-0.00098,-3.12 -1.453,-7.008 -4.31299,-11.688c-6.23999,-10.659 -18.19601,-16 -35.875,-16z',
          'least concern' = 'path://m118.344,94.5625c-10.14,0 -17.947,2.2053 -23.4065,6.6255c-3.8998,3.119 -5.8437,6.37 -5.8437,9.75c-0.00011,2.339 1.3639,5.182 4.0937,8.562c2.7298,3.38 4.0937,5.47 4.0937,6.25l16.3748,212.93799c0.26,2.599 -1.48,5.76102 -5.25,9.53101c-3.77,3.77002 -5.656,7.224 -5.656,10.34302c0,1.29999 0.261,2.86798 0.781,4.68799c2.86,8.05899 8.169,14.879 15.969,20.46899c7.8,5.58902 15.492,7.99802 23.03101,7.21899c12.22,-1.81998 20.77899,-5.07098 25.71899,-9.75c5.72,-6.23999 10.799,-9.95599 15.21899,-11.12598c4.41901,-1.16901 11.558,-1.75 21.43701,-1.75c9.87999,0.00098 17.483,-0.841 22.81299,-2.53101c5.32901,-1.69 10.03201,-5.259 14.06201,-10.71899c4.03,-5.45901 6.03099,-11.061 6.03099,-16.78101c0,-3.64001 -0.78299,-6.89001 -2.343,-9.75c-8.57999,-14.819 -17.547,-22.21899 -26.907,-22.21899c-3.379,0.00098 -7.61699,0.957 -12.687,2.90698c-5.07001,1.95001 -10.06,3.98199 -15,6.06201l-23.40601,8.56299l-14.03099,-193.81299c-0.26001,-1.82001 0.785,-3.76401 3.12399,-5.843c2.34,-2.08 3.5,-4.17101 3.5,-6.25c0.00101,-2.08 -0.63699,-4.401 -1.937,-7c-2.08,-4.42001 -7.10201,-8.25101 -15.03101,-11.5005c-7.92999,-3.2498 -16.171,-4.875 -24.74999,-4.875zm226.96801,3.5c-3.11902,0 -6.37003,0.115 -9.75,0.375c-23.138,2.3395 -41.48001,22.3645 -55,60.0625c-11.69901,32.23801 -17.41602,67.992 -17.15601,107.25c0.25998,34.83801 5.716,63.04599 16.375,84.625c13.77899,28.078 35.633,41.979 65.53101,41.71899c24.69897,-0.25998 49.396,-28.061 74.09399,-83.43799c7.28,-5.45901 10.90601,-11.95999 10.90601,-19.5c0,-9.099 -6.354,-14.81601 -19.09302,-17.15601c-4.16,-0.78 -8.341,-1.18799 -12.5,-1.18799c-18.71899,0.00098 -28.06299,6.909 -28.06299,20.68799c0,2.07999 0.26199,4.285 0.78198,6.625c-4.15997,14.039 -9.35498,26.25699 -15.59399,36.65601c-6.5,11.17999 -12.10199,16.37399 -16.78198,15.59399c-7.79901,-1.29999 -13.63101,-12.09601 -17.53101,-32.375c-3.38,-17.939 -4.686,-37.29501 -3.90601,-58.09399c1.04001,-27.558 3.883,-52.77701 8.56299,-75.65601c5.45901,-27.81799 11.845,-40.82001 19.12402,-39c4.67999,0.78 8.82898,5.771 12.46899,15c3.63998,9.229 5.72998,19.069 6.25,29.46899c-3.63901,8.319 -5.46899,12.845 -5.46899,13.625c0.00098,6.239 5.341,11.841 16,16.78101c9.09998,4.42 17.39798,6.625 24.93799,6.625c3.12,0 5.84799,-0.37601 8.18799,-1.15601c10.659,-4.15999 15.99902,-10.138 16,-17.93799c0,-2.60001 -2.20599,-9.623 -6.62598,-21.06201c-5.979,-28.599 -13.26401,-49.407 -21.84302,-62.40599c-11.69901,-17.41901 -28.328,-26.1255 -49.90698,-26.1255z',
          'not evaluated' = 'path://m227.53101,104.438c-5.979,-0.00101 -10.39,1.306 -13.25,3.906c-5.19901,4.679 -7.81201,8.567 -7.81201,11.687c0,1.56001 0.899,3.562 2.71901,6.031c1.819,2.47 2.75,4.76401 2.75,6.84401l4.687,171.59399c-49.397,-76.435 -76.707,-126.61301 -81.90601,-150.53101c-0.25999,-0.51999 -0.407,-1.189 -0.407,-1.96899c0,-1.03999 0.26201,-2.72301 0.782,-5.062c0.52,-2.34 0.78101,-4.16901 0.78101,-5.46901c0,-3.37999 -1.16,-6.22299 -3.5,-8.56299c-8.32,-9.09901 -22.22,-13.65601 -41.7188,-13.65601c-7.2795,0 -12.9389,1.103 -16.9687,3.312c-4.0298,2.21001 -6.0313,4.996 -6.0313,8.37601c0.00011,1.299 0.2301,3.12799 0.75,5.468c0.52,2.34 0.7813,4.02299 0.7813,5.06299l11.7187,214.875c0.26,2.34 -1.684,5.01001 -5.8437,8c-4.1597,2.99002 -5.8737,7.34302 -5.0937,13.06201c1.03989,7.01999 6.0617,13.14398 15.0312,18.34399c8.9695,5.20001 18.141,7.78101 27.5,7.78101c8.839,0 15.455,-2.466 19.875,-7.40601c3.12,-3.64001 4.687,-7.52802 4.687,-11.68701c0.00101,-3.37997 -1.306,-7.53 -3.90599,-12.46899c-2.60001,-4.94 -3.90601,-8.07498 -3.90601,-9.375c-5.2,-66.03598 -7.259,-111.019 -6.219,-134.93799c9.36001,20.27899 23.898,45.383 43.65701,75.28198c8.05899,12.479 16.911,25.33401 26.53099,38.59302c2.08,3.63998 3.386,8.19699 3.90601,13.65698c0.25999,6.23901 1.04401,10.79602 2.34399,13.65601c8.05901,18.19901 23.12001,27.95001 45.21901,29.25c8.83899,0.52002 16.239,-2.09299 22.218,-7.81299c5.97998,-5.71899 9.22998,-12.858 9.75,-21.43701c0.25998,-3.38 -1.48001,-7.61798 -5.25,-12.68799c-3.77002,-5.069 -5.65601,-9.276 -5.65601,-12.65601l-5.46899,-192.28101c0,-2.59999 2.14798,-5.12399 6.43799,-7.59399c4.289,-2.47 6.32199,-6.039 6.06201,-10.71899c-0.26001,-7.019 -5.48502,-13.52 -15.625,-19.50001c-10.13901,-5.979 -20.005,-8.96799 -29.625,-8.96799zm197.71899,1.156c-4.42001,0 -8.30801,0.93 -11.68799,2.75c-4.93903,2.6 -7.92801,4.021 -8.96802,4.281l-46.81299,13.25c-3.12,-1.3 -6.37,-2.721 -9.75,-4.281c-5.19901,-2.08 -9.495,-2.979 -12.875,-2.719c-15.85901,2.34 -23.78101,7.273 -23.78101,14.813c0,2.33899 0.89899,4.66 2.71899,7c-1.82001,76.955 -1.298,149.50899 1.56201,217.62401c-2.86002,8.84 -4.28101,13.51199 -4.28101,14.03198c0,1.82001 0.37601,3.241 1.15601,4.28101c11.17999,15.599 23.659,25.35001 37.43799,29.25c1.30002,0.26001 2.491,0.40601 3.53101,0.40601c3.12,0 6.63101,-1.56702 10.53101,-4.68701c5.19998,-3.89999 8.565,-6.25198 10.125,-7.03198l36.65601,-16.37402c14.03998,0.78 24.052,-0.323 30.03198,-3.31299c5.979,-2.98999 8.96802,-7.604 8.96802,-13.84399c0,-7.27899 -3.88702,-14.418 -11.68701,-21.43701c-7.79901,-7.01999 -15.345,-10.793 -22.625,-11.31299c-6.76001,-0.52002 -11.431,0.52499 -14.03101,3.125c-1.29999,1.29999 -2.60699,2.83701 -3.90698,4.65601c-7.27902,3.12 -16.39301,5.879 -27.31201,8.21899c-1.56,-5.979 -2.31201,-19.504 -2.31201,-40.56201c8.57901,-3.63998 15.832,-6.77499 21.81201,-9.375c2.07999,-0.78 6.89801,-0.89499 14.43799,-0.375c7.539,0.52002 13.25601,0.258 17.15601,-0.78101c6.49899,-1.81998 11.31702,-6.26199 14.43701,-13.28198c0.78,-1.82001 1.15698,-3.50201 1.15698,-5.06201c0,-6.23999 -4.991,-12.65201 -15,-19.282c-10.00998,-6.629 -18.77298,-9.968 -26.31299,-9.968c-7.539,0 -12.88,2.466 -16,7.40601c-6.23999,1.03999 -10.12799,1.97 -11.68701,2.75c-1.56,-31.198 -1.56,-59.03 0,-83.46899c4.67902,-3.38 14.284,-7.52901 28.84302,-12.46901c5.97998,-2.07899 12.742,-4.17 20.28101,-6.25c5.19998,0.52 9.75699,0.782 13.65698,0.782c9.35901,0 17.02002,-2.20599 23,-6.625c2.86002,-2.07999 4.28101,-5.069 4.28101,-8.96899c0,-6.24001 -2.785,-12.944 -8.375,-20.094c-5.59,-7.14899 -11.24899,-11.241 -16.96899,-12.281c-2.86002,-0.52 -5.32602,-0.781 -7.40601,-0.781z'

        )


        # Clean up 'category' values by removing leading/trailing white spaces and convert to lowercase
        data$category <- tolower(trimws(data$category))

        # Map 'category' values to their corresponding symbols
        data$symbol <- sapply(data$category, function(cat) {
          symbol <- classification_list[[cat]]
          if (is.null(symbol)) {
            # If 'cat' doesn't match any entry in the classification_list, return NA
            NA
          } else {
            symbol
          }
        })
        table_data3(data)
      }
      if (input$ch1 == 'Nocturnal or Diurnal') {
        data <- hot_to_r(input$editableTable3)

        classification_list <- list(
          nocturnal = 'path://m58.7766,224.431l12.8893,-7.85899l12.7605,8.12599l-2.3201,-16.95999l10.4565,-11.89401l-14.3072,-2.638l-6.3158,-15.47l-6.50909,15.37401l-14.3555,2.27499l10.2954,12.123l-2.594,16.923zm261.20341,25.144c-34.914,-71.76199 -32.41702,-156.7948 0.07999,-223.7769c-32.09399,-0.0574 -64.62399,9.3885 -94.431,29.8293c-64.22099,44.0365 -98.184,126.02861 -93.802,208.28859c15.226,0.59302 29.629,7.01801 41.23001,18.52902c10.972,-7.24701 23.12,-10.97601 35.784,-10.97601c33.722,0 62.884,26.94202 71.987,64.61099c23.78101,8.70102 40.55301,34.66702 40.55301,65.28101c0,31.97101 -18.64102,58.702 -43.66202,66.293c44.871,12.25702 93.59201,5.37402 136.62701,-24.09198c29.80701,-20.422 52.95898,-49.12302 68.974,-82.16501c-65.12302,-0.134 -128.42599,-40.078 -163.34,-111.82201zm-14.40402,151.74699c0,-25.94699 -16.77298,-47.01898 -38.08798,-49.371c-3.69,-34.763 -28.38901,-61.74298 -58.647,-61.74298c-14.468,0 -27.519,6.32898 -37.83,16.483c-9.683,-14.685 -24.58701,-24.30301 -41.504,-24.30301c-25.27901,0 -46.32121,21.052 -51.58971,49.142c-27.4866,2.27499 -49.2374,29.16 -49.2374,62.37302c0,34.64798 23.6842,62.73798 52.8947,62.73798c6.203,0 12.0999,-1.492 17.6263,-3.82498c9.6351,15.67999 25.1181,25.98599 42.7121,25.98599c10.763,0 20.752,-3.862 29.114,-10.42099c9.53801,10.97598 22.492,17.82098 36.847,17.82098c21.123,0 39.20001,-14.819 47.675,-36.082c2.59401,0.59302 5.252,0.995 8.007,0.995c23.20099,0.01901 42.01999,-22.29599 42.01999,-49.793zm115.311,-123.96298l7.54102,-19.69501l17.93198,-3.767l-13.43698,-14.62801l2.49701,-21.435l-15.83801,10.689l-16.38501,-9.446l3.65701,21.205l-12.63202,15.565l18.09402,2.44801l8.57098,19.064zm-69.345,-91.24701l5.88101,13.05901l5.172,-13.51801l12.293,-2.563l-9.216,-10.019l1.724,-14.685l-10.875,7.304l-11.246,-6.48201l2.513,14.55101l-8.668,10.651l12.422,1.702zm59.22702,-38.817l3.60898,8.03101l3.17401,-8.27901l7.556,-1.60699l-5.655,-6.157l1.03101,-8.987l-6.67001,4.513l-6.84698,-3.996l1.49799,8.91l-5.31699,6.53999l7.621,1.032zm-271.91701,-54.0177l3.60899,8.0307l3.174,-8.2984l7.556,-1.6062l-5.655,-6.157l1.047,-8.9871l-6.67,4.4935l-6.87999,-3.9772l1.53099,8.8914l-5.33299,6.5587l7.621,1.0516z',
          diurnal = 'path://m426.62701,415.82101c0,0 -104.83502,-32.737 -163.07703,-32.737c-58.24098,0 -163.07599,32.737 -163.07599,32.737c0,0 34.94501,-109.12201 34.94501,-152.77103c0,-43.64899 -34.94501,-152.77099 -34.94501,-152.77099c0,0 104.83501,32.73701 163.07599,32.73701c58.242,0 163.07703,-32.73701 163.07703,-32.73701c0,0 -34.94501,109.122 -34.94501,152.77099c0,43.64902 34.94501,152.77103 34.94501,152.77103zm-163.09003,-360.11041c0,0 -55.63699,89.73239 -90.59399,122.4684c-34.95599,32.737 -130.71839,84.87498 -130.71839,84.87498c-0.0001,0 89.94939,46.68301 130.71839,84.875c40.76901,38.19302 90.59399,122.43802 90.59399,122.43802c0,0 55.68002,-89.70102 90.625,-122.43802c34.94501,-32.73599 130.71902,-84.875 130.71902,-84.875c0,0 -95.78601,-52.13799 -130.71902,-84.87498c-34.93298,-32.73601 -90.625,-122.4684 -90.625,-122.4684zm0,98.2184c64.33401,0 116.5,48.84599 116.5,109.12498c0,60.27902 -52.16599,109.125 -116.5,109.125c-64.33398,0 -116.46899,-48.84598 -116.46899,-109.125c0,-60.27899 52.13501,-109.12498 116.46899,-109.12498z',
          unidentified = 'path://m421.38,72.426c-46.56,-46.64 -108.52002,-72.356 -174.64401,-72.42c-135.93199,0 -246.61999,110.572 -246.73599,246.5c-0.064,65.916 25.548,127.90401 72.1,174.55998c46.568,46.62802 108.284,72.436 174.19601,72.436l0.57199,0l0,-0.02399c134.95601,0 246.53999,-110.59601 246.64,-246.51602c0.064,-65.91197 -25.58398,-127.89198 -72.12799,-174.53597zm-163.67999,304.7c-2.836,2.86401 -6.8,4.504 -10.87201,4.504c-4.088,-0.008 -8.064,-1.65601 -10.93199,-4.56c-2.84801,-2.82401 -4.48401,-6.79199 -4.48,-10.87601c0.008,-4.07199 1.664,-8.064 4.532,-10.92398c2.856,-2.84802 7.064,-4.48801 10.92,-4.48801c4.06,0 8.028,1.64801 10.85999,4.504c2.89603,2.92001 4.556,6.91599 4.548,10.93201c-0.004,4.03198 -1.672,8.00397 -4.57599,10.90799zm7.42398,-94.452c-1.76001,0.388 -3.01999,1.948 -3.02402,3.75198l-0.01999,18.12003c-0.008,8.48798 -6.916,15.40799 -15.43599,15.40799c-8.51201,-0.008 -15.412,-6.94 -15.40401,-15.436l0.036,-34.96399c0.00801,-8.48401 6.916,-15.08 15.416,-15.08l0.06801,0c29.48799,0 53.49998,-24.32001 53.532,-53.808c0.01199,-14.28801 -5.53601,-27.884 -15.64001,-38.024c-10.13998,-10.132 -23.56799,-15.78801 -37.88397,-15.804c-29.49202,0 -53.51201,23.95599 -53.54401,53.464c-0.008,8.49199 -6.924,15.38 -15.44,15.38c-4.12,0 -7.996,-1.62401 -10.89999,-4.54401c-2.916,-2.912 -4.508,-6.78799 -4.504,-10.90401c0.04399,-46.492 37.896,-84.32399 84.448,-84.32399c46.53198,0.048 84.34399,37.936 84.29999,84.46001c-0.03198,39.17198 -27.78,73.78796 -66.004,82.30399z'
        )


        # Clean up 'category' values by removing leading/trailing white spaces and convert to lowercase
        data$category <- tolower(trimws(data$category))

        # Map 'category' values to their corresponding symbols
        data$symbol <- sapply(data$category, function(cat) {
          symbol <- classification_list[[cat]]
          if (is.null(symbol)) {
            # If 'cat' doesn't match any entry in the classification_list, return NA
            NA
          } else {
            symbol
          }
        })
        table_data3(data)
      }
      if (input$ch1 != 'Conservation Status' &&
          input$ch1 != 'Groups' && input$ch1 != 'Nocturnal or Diurnal') {
        table_data3(hot_to_r(input$editableTable3))
      }
    }
  })







  observe({
    if (input$ch1 == 'Groups') {
      updateSelectInput(
        inputId = 'ch3',
        label = "Nodes Format",
        choices = c(
          'Icons',
          'Emoji',
          "circle",
          'roundRect',
          'pin',
          'triangle'
        )
      )
    } else {
      if (input$ch1 == 'Nocturnal or Diurnal' ||
          input$ch1 == 'Conservation Status') {
        updateSelectInput(
          inputId = 'ch3',
          label = "Nodes Format",
          choices = c('Icons', "circle", 'roundRect', 'pin', 'triangle')
        )
      } else {
        updateSelectInput(
          inputId = 'ch3',
          label = "Nodes Format",
          choices = c("circle", 'roundRect', 'pin', 'triangle')
        )
      }

    }
  })



}
